# Каталог персонажей Verity — 48 групп × 12 кадров

Исходная пользовательская таблица сохранена без изменения в `app/src/main/assets/character_catalog/source_table.jpg`. Папка `panels/` содержит 48 увеличенных отдельных панелей; папка `sprites/NN/` — по 12 отдельных PNG в каждой категории (576 файлов всего).

## Настроения и номера кадров

| Кадр | Состояние |
|---:|---|
| 01 | Радость (`happy`) |
| 02 | Нейтральное (`normal`) |
| 03 | Злость (`angry`) |
| 04 | Грусть (`sad`) |
| 05 | Речь (`talking`) |
| 06 | Удивление/боль (`ouch`) |
| 07 | Страшный образ (`scary`) |
| 08 | Любопытство (`curious`) |
| 09 | Сонливость (`sleepy`) |
| 10 | Смех (`laughing`) |
| 11 | Удивление (`surprised`) |
| 12 | Симпатия (`love`) |

Это примерная привязка: исходная таблица не содержит легенды для каждого кадра. Набор анимирует кадры при ответах AI; один выбранный PNG остаётся статичным.

## Группы персонажей

01. **Желтик** — Жёлтый шар  
   Панель: `character_catalog/panels/01.png`; кадры: `character_catalog/sprites/01/` (`12 PNG`).
02. **Пинкси** — Розовый персонаж  
   Панель: `character_catalog/panels/02.png`; кадры: `character_catalog/sprites/02/` (`12 PNG`).
03. **Облачко** — Синий воздушный шар  
   Панель: `character_catalog/panels/03.png`; кадры: `character_catalog/sprites/03/` (`12 PNG`).
04. **Пухлик** — Коричневые пушистики  
   Панель: `character_catalog/panels/04.png`; кадры: `character_catalog/sprites/04/` (`12 PNG`).
05. **Смарагд** — Зелёный стеклянный куб  
   Панель: `character_catalog/panels/05.png`; кадры: `character_catalog/sprites/05/` (`12 PNG`).
06. **Пружик** — Красная пружина  
   Панель: `character_catalog/panels/06.png`; кадры: `character_catalog/sprites/06/` (`12 PNG`).
07. **Кубикс** — Зелёный куб  
   Панель: `character_catalog/panels/07.png`; кадры: `character_catalog/sprites/07/` (`12 PNG`).
08. **Золотик** — Жёлтый куб  
   Панель: `character_catalog/panels/08.png`; кадры: `character_catalog/sprites/08/` (`12 PNG`).
09. **Краснолик** — Красные круглые лица  
   Панель: `character_catalog/panels/09.png`; кадры: `character_catalog/sprites/09/` (`12 PNG`).
10. **Солныш** — Жёлтые шарики  
   Панель: `character_catalog/panels/10.png`; кадры: `character_catalog/sprites/10/` (`12 PNG`).
11. **Апельсик** — Оранжевые смайлики  
   Панель: `character_catalog/panels/11.png`; кадры: `character_catalog/sprites/11/` (`12 PNG`).
12. **Иней** — Голубые пушистые лица  
   Панель: `character_catalog/panels/12.png`; кадры: `character_catalog/sprites/12/` (`12 PNG`).
13. **Камеш** — Коричневые круглые лица  
   Панель: `character_catalog/panels/13.png`; кадры: `character_catalog/sprites/13/` (`12 PNG`).
14. **Дудлик** — Жёлтые нарисованные лица  
   Панель: `character_catalog/panels/14.png`; кадры: `character_catalog/sprites/14/` (`12 PNG`).
15. **Какао** — Коричневые кубики  
   Панель: `character_catalog/panels/15.png`; кадры: `character_catalog/sprites/15/` (`12 PNG`).
16. **Нотик** — Чёрный музыкальный персонаж  
   Панель: `character_catalog/panels/16.png`; кадры: `character_catalog/sprites/16/` (`12 PNG`).
17. **Румяш** — Коричневый румяный шар  
   Панель: `character_catalog/panels/17.png`; кадры: `character_catalog/sprites/17/` (`12 PNG`).
18. **Колечко** — Кольцевые змеи  
   Панель: `character_catalog/panels/18.png`; кадры: `character_catalog/sprites/18/` (`12 PNG`).
19. **Трикси** — Жёлтые треугольные лица  
   Панель: `character_catalog/panels/19.png`; кадры: `character_catalog/sprites/19/` (`12 PNG`).
20. **Слаймик** — Зелёный слизистый куб  
   Панель: `character_catalog/panels/20.png`; кадры: `character_catalog/sprites/20/` (`12 PNG`).
21. **Звездар** — Звезда в очках  
   Панель: `character_catalog/panels/21.png`; кадры: `character_catalog/sprites/21/` (`12 PNG`).
22. **Лунар** — Голубая луна  
   Панель: `character_catalog/panels/22.png`; кадры: `character_catalog/sprites/22/` (`12 PNG`).
23. **Улыбчик** — Жёлтые круглые лица  
   Панель: `character_catalog/panels/23.png`; кадры: `character_catalog/sprites/23/` (`12 PNG`).
24. **Крош** — Маленькая фигурка  
   Панель: `character_catalog/panels/24.png`; кадры: `character_catalog/sprites/24/` (`12 PNG`).
25. **Ночик** — Чёрный смайлик  
   Панель: `character_catalog/panels/25.png`; кадры: `character_catalog/sprites/25/` (`12 PNG`).
26. **Клик** — Красная кнопка  
   Панель: `character_catalog/panels/26.png`; кадры: `character_catalog/sprites/26/` (`12 PNG`).
27. **Зубастик** — Красная зубастая голова  
   Панель: `character_catalog/panels/27.png`; кадры: `character_catalog/sprites/27/` (`12 PNG`).
28. **Синезуб** — Синяя зубастая голова  
   Панель: `character_catalog/panels/28.png`; кадры: `character_catalog/sprites/28/` (`12 PNG`).
29. **Хмурик** — Жёлтое лицо  
   Панель: `character_catalog/panels/29.png`; кадры: `character_catalog/sprites/29/` (`12 PNG`).
30. **Треугольчик** — Жёлтый треугольник  
   Панель: `character_catalog/panels/30.png`; кадры: `character_catalog/sprites/30/` (`12 PNG`).
31. **Утёнок** — Жёлтая уточка  
   Панель: `character_catalog/panels/31.png`; кадры: `character_catalog/sprites/31/` (`12 PNG`).
32. **Магента** — Розовый смайлик  
   Панель: `character_catalog/panels/32.png`; кадры: `character_catalog/sprites/32/` (`12 PNG`).
33. **Радужик** — Радужный смайлик  
   Панель: `character_catalog/panels/33.png`; кадры: `character_catalog/sprites/33/` (`12 PNG`).
34. **Снежок** — Белый смайлик  
   Панель: `character_catalog/panels/34.png`; кадры: `character_catalog/sprites/34/` (`12 PNG`).
35. **Синик** — Синий смайлик  
   Панель: `character_catalog/panels/35.png`; кадры: `character_catalog/sprites/35/` (`12 PNG`).
36. **Апгрейд** — Чёрный апгрейдер  
   Панель: `character_catalog/panels/36.png`; кадры: `character_catalog/sprites/36/` (`12 PNG`).
37. **Глазастик** — Розовый персонаж с глазами  
   Панель: `character_catalog/panels/37.png`; кадры: `character_catalog/sprites/37/` (`12 PNG`).
38. **Вайлет** — Фиолетовый персонаж  
   Панель: `character_catalog/panels/38.png`; кадры: `character_catalog/sprites/38/` (`12 PNG`).
39. **Рэдик** — Красная улыбка  
   Панель: `character_catalog/panels/39.png`; кадры: `character_catalog/sprites/39/` (`12 PNG`).
40. **Мимик** — Жёлтые нижние смайлики  
   Панель: `character_catalog/panels/40.png`; кадры: `character_catalog/sprites/40/` (`12 PNG`).
41. **Курочка** — Курочки  
   Панель: `character_catalog/panels/41.png`; кадры: `character_catalog/sprites/41/` (`12 PNG`).
42. **Поросёнок** — Зелёный поросёнок  
   Панель: `character_catalog/panels/42.png`; кадры: `character_catalog/sprites/42/` (`12 PNG`).
43. **Очкарик** — Фиолетовый персонаж в очках  
   Панель: `character_catalog/panels/43.png`; кадры: `character_catalog/sprites/43/` (`12 PNG`).
44. **Лапыч** — Голубой персонаж с руками  
   Панель: `character_catalog/panels/44.png`; кадры: `character_catalog/sprites/44/` (`12 PNG`).
45. **Плами** — Огненный персонаж  
   Панель: `character_catalog/panels/45.png`; кадры: `character_catalog/sprites/45/` (`12 PNG`).
46. **Планетик** — Оранжевая планета  
   Панель: `character_catalog/panels/46.png`; кадры: `character_catalog/sprites/46/` (`12 PNG`).
47. **Сердитик** — Красный сердитый персонаж  
   Панель: `character_catalog/panels/47.png`; кадры: `character_catalog/sprites/47/` (`12 PNG`).
48. **Розик** — Розовый смайлик (название неразборчиво)  
   Панель: `character_catalog/panels/48.png`; кадры: `character_catalog/sprites/48/` (`12 PNG`).

## Где использовать

- В приложении: `Настройки → Ассистент на экране → Выбрать` напротив нужного слота.
- Для каждого из пяти слотов можно выбрать собственную группу или статичный кадр.
- При активном Verity+ история выбранного главного персонажа добавляется к стилю ответа AI.
- Все авторские истории — выдуманные истории проекта Verity. Они не являются официальным сюжетом Minecraft, Brawl Stars или иных франшиз.


## Собственные персонажи (Verity 4.9.0)

Открой Настройки → Ассистент на экране → «Выбрать» у нужного слота. Вверху каталога находится блок «Мои персонажи». Нажми «Добавить персонажа из фото», выбери изображение и задай имя. Verity скопирует изображение в приватную папку приложения, центрирует квадратную область и обрежет её в круг с прозрачным фоном. Затем персонажа можно выбрать для любого из пяти слотов, переименовать или удалить.

Пользовательские персонажи пока статичные: у них нет набора из 12 эмоций и отдельной AI-предыстории. Встроенные 48 групп и 576 PNG-кадров не затрагиваются пользовательским удалением. Если удалить собственный образ, все слоты, в которых он использовался, сбрасываются на стандартный образ.
