plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.plugin.compose")
}

val admobAppId = providers.gradleProperty("ADMOB_APP_ID")
    .getOrElse("ca-app-pub-3940256099942544~3347511713")
val admobBannerId = providers.gradleProperty("ADMOB_BANNER_ID")
    .getOrElse("ca-app-pub-3940256099942544/9214589741")
val testAdMobAppId = "ca-app-pub-3940256099942544~3347511713"
val testAdMobBannerId = "ca-app-pub-3940256099942544/9214589741"

android {
    namespace = "dev.veriti.app"
    compileSdk = 37

    defaultConfig {
        applicationId = "dev.veriti.app"
        minSdk = 29
        targetSdk = 35
        versionCode = 50100
        versionName = "5.0.1"
    }

    buildTypes {
        getByName("debug") {
            manifestPlaceholders["admobAppId"] = testAdMobAppId
            buildConfigField("String", "ADMOB_BANNER_ID", "\"$testAdMobBannerId\"")
            buildConfigField("boolean", "ADMOB_TEST_MODE", "true")
        }
        getByName("release") {
            manifestPlaceholders["admobAppId"] = admobAppId
            buildConfigField("String", "ADMOB_BANNER_ID", "\"$admobBannerId\"")
            buildConfigField("boolean", "ADMOB_TEST_MODE", "false")
        }
        create("live") {
            initWith(getByName("release"))
            signingConfig = signingConfigs.getByName("debug")
            matchingFallbacks += listOf("release")
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging.resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
}

androidComponents {
    onVariants(selector().all()) { variant ->
        val adMode = if (variant.buildType == "debug") "AdMob-Test" else "RealAds"
        variant.outputs.forEach { output ->
            output.outputFileName.set("Verity-5.0.1-$adMode-${variant.name}.apk")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.18.0")
    implementation("androidx.activity:activity-compose:1.13.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.11.0")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.11.0")
    implementation("androidx.compose.ui:ui:1.12.0-rc01")
    implementation("androidx.compose.ui:ui-tooling-preview:1.12.0-rc01")
    implementation("androidx.compose.foundation:foundation:1.12.0-rc01")
    implementation("androidx.compose.material3:material3:1.5.0-alpha22")
    implementation("androidx.compose.material:material-icons-extended:1.7.8")
    implementation("zone.ien.hig:hig:1.3.1")
    implementation("zone.ien.hig:hig-adaptive:1.3.1")
    implementation("com.google.android.gms:play-services-ads:25.4.0")
    implementation("com.google.android.ump:user-messaging-platform:4.0.0")
    debugImplementation("androidx.compose.ui:ui-tooling:1.12.0-rc01")
    testImplementation("junit:junit:4.13.2")
}
