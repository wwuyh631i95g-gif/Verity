package dev.veriti.app.network

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.SecureRandom

/** Firebase Authentication + Realtime Database REST client. All calls are HTTPS. */
object FriendChatClient {
    data class Session(val idToken: String, val refreshToken: String, val uid: String)
    data class Message(
        val id: String,
        val senderUid: String,
        val senderName: String,
        val text: String,
        val imageBase64: String,
        val mimeType: String,
        val sentAt: Long
    )
    data class Result<T>(val value: T? = null, val error: String? = null) {
        val ok: Boolean get() = value != null && error == null
    }

    fun newRoomCode(): String {
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val random = SecureRandom()
        return buildString(10) { repeat(10) { append(alphabet[random.nextInt(alphabet.length)]) } }
    }

    private fun request(url: String, method: String, body: String? = null, contentType: String = "application/json"): String {
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = method
            connection.connectTimeout = 10_000
            connection.readTimeout = 15_000
            connection.setRequestProperty("Accept", "application/json")
            if (body != null) {
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", contentType)
                connection.outputStream.bufferedWriter(Charsets.UTF_8).use { it.write(body) }
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val reason = runCatching { JSONObject(response).optJSONObject("error")?.optString("message") }.getOrNull()
                throw IllegalStateException("HTTP $code${reason?.takeIf { it.isNotBlank() }?.let { ": $it" } ?: ""}")
            }
            return response
        } finally {
            connection.disconnect()
        }
    }

    private fun databaseBase(raw: String): String {
        val value = raw.trim().trimEnd('/')
        require(value.startsWith("https://", true)) { "Укажи HTTPS URL Firebase Realtime Database." }
        val parsed = URL(value)
        require(parsed.host == "firebasedatabase.app" || parsed.host.endsWith(".firebasedatabase.app") ||
            parsed.host == "firebaseio.com" || parsed.host.endsWith(".firebaseio.com")) {
            "Это не похоже на URL Firebase Realtime Database. Скопируй URL из Firebase Console."
        }
        require(parsed.userInfo == null) { "В URL не должно быть логина или пароля." }
        return value
    }

    private fun authUrl(apiKey: String, method: String): String {
        require(apiKey.trim().length >= 20) { "Проверь Firebase Web API Key." }
        return "https://identitytoolkit.googleapis.com/v1/accounts:$method?key=${enc(apiKey.trim())}"
    }

    fun signIn(apiKey: String, email: String, password: String, createAccount: Boolean): Result<Session> = runCatching {
        require(email.contains('@') && email.length <= 254) { "Укажи корректный email." }
        require(password.length >= 6) { "Пароль Firebase должен быть не короче 6 символов." }
        val method = if (createAccount) "signUp" else "signInWithPassword"
        val body = JSONObject().put("email", email.trim()).put("password", password).put("returnSecureToken", true).toString()
        val json = JSONObject(request(authUrl(apiKey, method), "POST", body))
        Session(json.getString("idToken"), json.getString("refreshToken"), json.getString("localId"))
    }.fold({ Result(value = it) }, { Result(error = friendly(it)) })

    fun refresh(apiKey: String, refreshToken: String): Result<Session> = runCatching {
        require(refreshToken.isNotBlank()) { "Сначала войди в Firebase." }
        require(apiKey.isNotBlank()) { "Добавь Firebase Web API Key." }
        val url = "https://securetoken.googleapis.com/v1/token?key=${enc(apiKey.trim())}"
        val body = "grant_type=refresh_token&refresh_token=${enc(refreshToken)}"
        val json = JSONObject(request(url, "POST", body, "application/x-www-form-urlencoded"))
        Session(json.getString("id_token"), json.optString("refresh_token", refreshToken), json.getString("user_id"))
    }.fold({ Result(value = it) }, { Result(error = friendly(it)) })

    fun joinRoom(databaseUrl: String, roomCode: String, session: Session, displayName: String): Result<Boolean> = runCatching {
        val room = checkedRoom(roomCode)
        val base = databaseBase(databaseUrl)
        val body = JSONObject().put("displayName", displayName.trim().ifBlank { "Друг Verity" }.take(28)).put("joinedAt", System.currentTimeMillis()).toString()
        request("$base/rooms/$room/members/${enc(session.uid)}.json?auth=${enc(session.idToken)}", "PUT", body)
        true
    }.fold({ Result(value = it) }, { Result(error = friendly(it)) })

    fun sendText(databaseUrl: String, roomCode: String, session: Session, displayName: String, text: String): Result<Boolean> = send(
        databaseUrl, roomCode, session, displayName, text, "", ""
    )

    fun sendImage(databaseUrl: String, roomCode: String, session: Session, displayName: String, base64: String, mimeType: String): Result<Boolean> {
        if (base64.length > 520_000) return Result(error = "Изображение слишком большое. Выбери фото поменьше.")
        return send(databaseUrl, roomCode, session, displayName, "", base64, mimeType)
    }

    private fun send(
        databaseUrl: String, roomCode: String, session: Session, displayName: String,
        text: String, imageBase64: String, mimeType: String
    ): Result<Boolean> = runCatching {
        val room = checkedRoom(roomCode)
        val base = databaseBase(databaseUrl)
        require(text.length <= 4000) { "Сообщение слишком длинное (максимум 4000 символов)." }
        require(text.isNotBlank() || imageBase64.isNotBlank()) { "Добавь текст или изображение." }
        val body = JSONObject()
            .put("senderUid", session.uid)
            .put("senderName", displayName.trim().ifBlank { "Друг Verity" }.take(28))
            .put("text", text)
            .put("imageBase64", imageBase64)
            .put("mimeType", mimeType)
            .put("sentAt", System.currentTimeMillis())
            .toString()
        request("$base/rooms/$room/messages.json?auth=${enc(session.idToken)}", "POST", body)
        true
    }.fold({ Result(value = it) }, { Result(error = friendly(it)) })

    fun readMessages(databaseUrl: String, roomCode: String, session: Session): Result<List<Message>> = runCatching {
        val room = checkedRoom(roomCode)
        val base = databaseBase(databaseUrl)
        val response = request("$base/rooms/$room/messages.json?orderBy=%22sentAt%22&limitToLast=40&auth=${enc(session.idToken)}", "GET")
        if (response == "null" || response.isBlank()) return@runCatching emptyList()
        val root = JSONObject(response)
        val all = mutableListOf<Message>()
        val keys = root.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val item = root.optJSONObject(key) ?: continue
            all += Message(
                id = key,
                senderUid = item.optString("senderUid"),
                senderName = item.optString("senderName", "Друг Verity"),
                text = item.optString("text"),
                imageBase64 = item.optString("imageBase64"),
                mimeType = item.optString("mimeType", "image/jpeg"),
                sentAt = item.optLong("sentAt")
            )
        }
        all.sortedBy { it.sentAt }.takeLast(40)
    }.fold({ Result(value = it) }, { Result(error = friendly(it)) })

    private fun checkedRoom(value: String): String {
        val room = value.trim().uppercase()
        require(Regex("^[A-Z0-9]{10}$").matches(room)) { "Код комнаты должен содержать 10 букв или цифр." }
        return room
    }

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")

    private fun friendly(error: Throwable): String {
        val text = error.message.orEmpty()
        return when {
            text.contains("EMAIL_NOT_FOUND") || text.contains("INVALID_PASSWORD") || text.contains("INVALID_LOGIN_CREDENTIALS") -> "Не получилось войти: проверь email и пароль."
            text.contains("EMAIL_EXISTS") -> "Аккаунт с таким email уже есть. Выбери вход, а не регистрацию."
            text.contains("WEAK_PASSWORD") -> "Firebase требует пароль не короче 6 символов."
            text.contains("INVALID_API_KEY") -> "Firebase не принял Web API Key. Проверь настройки проекта."
            text.contains("Permission denied") || text.contains("PERMISSION_DENIED") -> "Firebase отклонил доступ. Проверь правила Realtime Database из инструкции."
            text.contains("UnknownHost") || text.contains("Unable to resolve host") -> "Нет подключения к интернету или сервер недоступен."
            else -> text.take(260).ifBlank { "Не удалось связаться с Firebase." }
        }
    }
}
