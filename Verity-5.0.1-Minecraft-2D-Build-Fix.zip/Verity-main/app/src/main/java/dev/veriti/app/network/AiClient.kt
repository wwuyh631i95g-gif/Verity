package dev.veriti.app.network

import dev.veriti.app.data.AppSettings
import dev.veriti.app.data.DEFAULT_SYSTEM_PROMPT
import dev.veriti.app.data.Message
import dev.veriti.app.data.CharacterLore
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.File

data class AiReply(val text: String, val mood: String)
data class RemoteModel(val id: String, val created: Long = 0L)

class AiClient {
    fun generateVideo(settings: AppSettings, prompt: String, outputFile: File): File {
        val endpoint = settings.baseUrl.trimEnd('/') + "/videos"
        val create = URL(endpoint).openConnection() as HttpURLConnection
        val videoId = try {
            create.requestMethod = "POST"
            create.connectTimeout = 25_000
            create.readTimeout = 120_000
            create.doOutput = true
            create.setRequestProperty("Content-Type", "application/json")
            if (settings.apiKey.isNotBlank()) create.setRequestProperty("Authorization", "Bearer ${settings.apiKey.trim()}")
            val body = JSONObject()
                .put("model", "sora-2")
                .put("prompt", prompt.take(32_000))
                .put("seconds", "4")
                .put("size", "720x1280")
            create.outputStream.bufferedWriter().use { it.write(body.toString()) }
            val code = create.responseCode
            val response = (if (code in 200..299) create.inputStream else create.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) error(apiError(code, response))
            JSONObject(response).getString("id")
        } finally {
            create.disconnect()
        }

        var completed = false
        for (attempt in 0 until 180) {
            val statusConnection = URL("$endpoint/$videoId").openConnection() as HttpURLConnection
            val status = try {
                statusConnection.requestMethod = "GET"
                statusConnection.connectTimeout = 20_000
                statusConnection.readTimeout = 30_000
                if (settings.apiKey.isNotBlank()) statusConnection.setRequestProperty("Authorization", "Bearer ${settings.apiKey.trim()}")
                val code = statusConnection.responseCode
                val response = (if (code in 200..299) statusConnection.inputStream else statusConnection.errorStream)
                    ?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (code !in 200..299) error(apiError(code, response))
                JSONObject(response)
            } finally {
                statusConnection.disconnect()
            }
            when (status.optString("status")) {
                "completed" -> { completed = true; break }
                "failed" -> error(status.optJSONObject("error")?.optString("message").orEmpty().ifBlank { "Генерация видео завершилась ошибкой" })
            }
            Thread.sleep(2_000L)
        }
        if (!completed) error("Видео не успело сгенерироваться. Попробуйте ещё раз позже.")

        val download = URL("$endpoint/$videoId/content").openConnection() as HttpURLConnection
        try {
            download.requestMethod = "GET"
            download.connectTimeout = 25_000
            download.readTimeout = 180_000
            if (settings.apiKey.isNotBlank()) download.setRequestProperty("Authorization", "Bearer ${settings.apiKey.trim()}")
            val code = download.responseCode
            if (code !in 200..299) {
                val response = download.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                error(apiError(code, response))
            }
            outputFile.parentFile?.mkdirs()
            download.inputStream.use { input -> outputFile.outputStream().use(input::copyTo) }
            return outputFile
        } finally {
            download.disconnect()
        }
    }

    private fun apiError(code: Int, response: String): String {
        val detail = runCatching { JSONObject(response).optJSONObject("error")?.optString("message") }.getOrNull().orEmpty()
        return "API $code${if (detail.isNotBlank()) ": $detail" else ""}"
    }

    fun complete(settings: AppSettings, history: List<Message>): AiReply {
        val endpoint = settings.baseUrl.trimEnd('/') + "/chat/completions"
        val connection = URL(endpoint).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 25_000
            connection.readTimeout = 120_000
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json")
            if (settings.apiKey.isNotBlank()) {
                connection.setRequestProperty("Authorization", "Bearer ${settings.apiKey.trim()}")
            }

            val skinPersona = if (settings.verityPlus) when (settings.skinStyle) {
                "pink" -> "\n\nТы сейчас Ловити — девочка Verity. Представляйся как Ловити и сохраняй дружелюбный женский характер."
                else -> ""
            } else ""
            val messages = JSONArray().put(
                JSONObject().put("role", "system").put(
                    "content",
                    (if (settings.verityPlus) settings.systemPrompt else DEFAULT_SYSTEM_PROMPT) + skinPersona + CharacterLore.forAi(settings) + "\n\n" +
                        (if (settings.language == "auto") "Определи язык последнего сообщения пользователя и отвечай на этом же языке. Не переключай язык без просьбы." else "Отвечай на языке ${settings.language}, если пользователь явно не попросил другой язык.") + "\n" +
                        "Если приложены кадры видео, анализируй их как последовательные кадры одного ролика в порядке отправки.\n" +
                        "Перед каждой репликой ставь ровно один технический тег настроения из списка: " +
                        "[mood:happy], [mood:angry], [mood:sad], [mood:normal], [mood:talking], " +
                        "[mood:ouch], [mood:scary], [mood:curious], [mood:sleepy], [mood:laughing], " +
                        "[mood:surprised] или [mood:love]. Выбирай настроение по смыслу, не вставляй его в сам текст. " +
                        "После тега сразу пиши ответ. Пользователь тег не увидит."
                )
            )
            history.takeLast(40).forEach {
                val apiContent: Any = if (it.role == "user" && it.attachments.isNotEmpty()) {
                    JSONArray().apply {
                        if (it.content.isNotBlank()) put(JSONObject().put("type", "text").put("text", it.content))
                        it.attachments.forEach { attachment ->
                            if (attachment.isImage) {
                                put(JSONObject().put("type", "image_url").put(
                                    "image_url",
                                    JSONObject().put("url", "data:${attachment.mimeType};base64,${attachment.content}")
                                ))
                            } else {
                                put(JSONObject().put("type", "text").put(
                                    "text",
                                    "Прикреплённый файл «${attachment.name}» (${attachment.mimeType}):\n${attachment.content}"
                                ))
                            }
                        }
                    }
                } else it.content
                messages.put(JSONObject().put("role", it.role).put("content", apiContent))
            }
            val body = JSONObject()
                .put("model", settings.model.trim())
                .put("messages", messages)
                .put("stream", false)
            // New Gemini Flash models reject legacy sampling parameters.
            if (!settings.providerName.equals("Google Gemini", ignoreCase = true)) {
                body.put("temperature", 0.7)
            }
            val requestBody = body.toString()
            connection.outputStream.bufferedWriter().use { it.write(requestBody) }

            val code = connection.responseCode
            val response = (if (code in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val detail = runCatching {
                    JSONObject(response).optJSONObject("error")?.optString("message")
                }.getOrNull().orEmpty()
                error("API $code${if (detail.isNotBlank()) ": $detail" else ""}")
            }
            val raw = JSONObject(response)
                .getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
                .trim()
            val moodPattern = Regex("^\\s*\\[mood:(happy|angry|sad|normal|talking|ouch|scary|curious|sleepy|laughing|surprised|love)]\\s*", RegexOption.IGNORE_CASE)
            val mood = moodPattern.find(raw)?.groupValues?.getOrNull(1)?.lowercase() ?: "happy"
            return AiReply(text = raw.replaceFirst(moodPattern, "").trim(), mood = mood)
        } finally {
            connection.disconnect()
        }
    }

    fun listModels(settings: AppSettings): List<RemoteModel> {
        val connection = URL(settings.baseUrl.trimEnd('/') + "/models").openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 20_000
            connection.readTimeout = 30_000
            if (settings.apiKey.isNotBlank()) {
                connection.setRequestProperty("Authorization", "Bearer ${settings.apiKey.trim()}")
            }
            val code = connection.responseCode
            val response = (if (code in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) error("API $code: список моделей недоступен")
            val data = JSONObject(response).optJSONArray("data") ?: JSONArray()
            val allModels = List(data.length()) { index ->
                val item = data.getJSONObject(index)
                RemoteModel(item.getString("id"), item.optLong("created", 0L))
            }.distinctBy { it.id }
            val nonChatMarkers = listOf(
                "embedding", "whisper", "tts", "dall-e", "image", "imagen", "veo", "lyria",
                "live", "native-audio", "moderation", "transcribe", "rerank"
            )
            val chatModels = allModels.filter { model ->
                nonChatMarkers.none { marker -> model.id.contains(marker, ignoreCase = true) }
            }
            return (chatModels.ifEmpty { allModels })
                .sortedWith(compareByDescending<RemoteModel> { it.created }.thenByDescending { it.id })
        } finally {
            connection.disconnect()
        }
    }
}
