package dev.veriti.app.ads

import android.app.Activity
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.android.gms.ads.MobileAds
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import java.util.concurrent.atomic.AtomicBoolean

object AdMobController {
    var canRequestAds by mutableStateOf(false)
        private set
    var privacyOptionsRequired by mutableStateOf(false)
        private set
    var consentError by mutableStateOf<String?>(null)
        private set

    private val initialized = AtomicBoolean(false)

    fun requestConsentAndInitialize(activity: Activity) {
        val consent = UserMessagingPlatform.getConsentInformation(activity)
        consent.requestConsentInfoUpdate(
            activity,
            ConsentRequestParameters.Builder().build(),
            {
                updateState(consent)
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { error ->
                    consentError = error?.message
                    updateState(consent)
                    initializeIfAllowed(activity.applicationContext)
                }
            },
            { error ->
                consentError = error.message
                updateState(consent)
                initializeIfAllowed(activity.applicationContext)
            }
        )
    }

    fun showPrivacyOptions(activity: Activity) {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { error ->
            consentError = error?.message
            val consent = UserMessagingPlatform.getConsentInformation(activity)
            updateState(consent)
            initializeIfAllowed(activity.applicationContext)
        }
    }

    private fun updateState(consent: ConsentInformation) {
        canRequestAds = consent.canRequestAds()
        privacyOptionsRequired = consent.privacyOptionsRequirementStatus ==
            ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED
    }

    private fun initializeIfAllowed(context: Context) {
        if (canRequestAds && initialized.compareAndSet(false, true)) {
            Thread { MobileAds.initialize(context) }.start()
        }
    }
}
