package dev.veriti.app.service

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import androidx.core.graphics.drawable.RoundedBitmapDrawableFactory
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import dev.veriti.app.MainActivity
import dev.veriti.app.R
import dev.veriti.app.data.AssistantBridge
import dev.veriti.app.data.Chat
import dev.veriti.app.data.ChatStore
import dev.veriti.app.data.Message
import dev.veriti.app.data.MysteryStory
import dev.veriti.app.data.SkinSheet
import dev.veriti.app.network.AiClient
import dev.veriti.app.network.HomeAssistantClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.random.Random
import java.util.Locale

class FloatingAssistantService : Service() {
    private lateinit var windowManager: WindowManager
    private lateinit var overlayRoot: LinearLayout
    private lateinit var character: ImageView
    private var secondaryCharacter: ImageView? = null
    private val extraCharacters = mutableListOf<ImageView>()
    private val extraCharacterParams = mutableMapOf<ImageView, WindowManager.LayoutParams>()
    private val extraPhysicsFrames = mutableMapOf<View, Runnable>()
    private lateinit var speechCard: LinearLayout
    private lateinit var speechText: TextView
    private lateinit var moreButton: Button
    private lateinit var keyboardButton: TextView
    private lateinit var petColumn: LinearLayout
    private var bubble: View? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var physicsFrame: Runnable? = null
    private var speechPages: List<String> = emptyList()
    private var speechPage = 0
    private var listening = false
    private var requestInFlight = false
    private var overlayChatId: Long? = null
    private var startNewOverlayChat = false
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val chatStore by lazy { ChatStore(applicationContext) }
    private val aiClient = AiClient()
    private var textToSpeech: TextToSpeech? = null
    private var ttsReady = false
    private var textShakeAnimator: ObjectAnimator? = null

    private val wanderRunnable = object : Runnable {
        override fun run() {
            val params = layoutParams
            if (params != null && physicsFrame == null && !listening && speechCard.visibility != View.VISIBLE) {
                val vx = Random.nextInt(-650, 651).toFloat().let { if (abs(it) < 180) 260f else it }
                val vy = Random.nextInt(-360, 361).toFloat()
                hop()
                startPhysics(overlayRoot, params, vx, vy)
            }
            handler.postDelayed(this, Random.nextLong(4_500L, 8_000L))
        }
    }

    override fun onCreate() {
        super.onCreate()
        getSharedPreferences("veriti_data", MODE_PRIVATE).edit().putBoolean("overlay_enabled", true).apply()
        createNotificationChannel()
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        startForeground(
            NOTIFICATION_ID,
            NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_veriti_foreground)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(getString(R.string.overlay_active))
                .setContentIntent(openIntent)
                .setOngoing(true)
                .build()
        )
        showBubble()
        scheduleMysteryFace()
        prepareSpeechRecognizer()
        prepareTextToSpeech()
        AssistantBridge.onAssistantReply = { text, mood -> handler.post { showSpeech(text, mood) } }
        handler.postDelayed(wanderRunnable, 3_000L)
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun showBubble() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        reloadCustomization()
        speechText = TextView(this).apply {
            setTextColor(Color.rgb(33, 28, 38))
            textSize = 15f
            maxLines = 6
            setLineSpacing(0f, 1.08f)
            setOnClickListener {
                AssistantBridge.focusComposerRequested = true
                openApp()
            }
        }
        moreButton = Button(this).apply {
            text = "Ещё"
            isAllCaps = false
            setOnClickListener { showNextSpeechPage() }
        }
        val closeButton = Button(this).apply {
            text = "Закрыть"
            isAllCaps = false
            setOnClickListener {
                closeSpeech()
                AssistantBridge.pendingNewChat = true
                startNewOverlayChat = true
                overlayChatId = null
            }
        }
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            addView(moreButton, LinearLayout.LayoutParams(0, dp(44), 1f))
            addView(closeButton, LinearLayout.LayoutParams(0, dp(44), 1f))
        }
        speechCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(10), dp(8))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(18).toFloat()
                setColor(Color.rgb(250, 246, 255))
                setStroke(dp(1), Color.rgb(211, 199, 226))
            }
            elevation = dp(8).toFloat()
            visibility = View.GONE
            addView(speechText, LinearLayout.LayoutParams(dp(218), LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(actions, LinearLayout.LayoutParams(dp(218), LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        character = ImageView(this).apply {
            SkinSheet.faceForMood(this@FloatingAssistantService, chatStore.loadSettings(), "happy")
                ?.let { setImageBitmap(it) } ?: setImageResource(R.drawable.verity_happy_cutout)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            clipToOutline = false
            elevation = dp(14).toFloat()
            contentDescription = "Поговорить с Verity"
        }
        keyboardButton = TextView(this).apply {
            text = "Чат"
            textSize = 13f
            gravity = Gravity.CENTER
            contentDescription = "Открыть чат"
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(245, 240, 250))
                setStroke(dp(1), Color.rgb(198, 188, 210))
            }
            elevation = dp(10).toFloat()
            setOnClickListener {
                AssistantBridge.focusComposerRequested = true
                openApp()
            }
        }
        val hideButton = TextView(this).apply {
            text = "Скрыть"
            textSize = 13f
            gravity = Gravity.CENTER
            contentDescription = "Убрать Verity с экрана"
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(245, 240, 250))
                setStroke(dp(1), Color.rgb(198, 188, 210))
            }
            elevation = dp(10).toFloat()
            setOnClickListener {
                getSharedPreferences("veriti_data", MODE_PRIVATE).edit().putBoolean("overlay_enabled", false).apply()
                stopSelf()
            }
        }
        val currentSettings = chatStore.loadSettings()
        val visibleCharacterCount = currentSettings.overlayCharacterCount.coerceIn(1, 5)
        val screenWidthDp = (resources.displayMetrics.widthPixels / resources.displayMetrics.density).toInt()
        val actualCharacterSizeDp = minOf(
            currentSettings.overlaySizeDp,
            ((screenWidthDp - 24) / visibleCharacterCount).coerceAtLeast(44)
        )
        // The primary pet has its own overlay window. Additional pets are added below
        // as separate WindowManager windows so each can be dragged independently.
        val characterRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(character, LinearLayout.LayoutParams(dp(actualCharacterSizeDp), dp(actualCharacterSizeDp)))
        }
        val showChatButton = currentSettings.overlayControlsVisible && currentSettings.overlayChatButtonVisible
        val showHideButton = currentSettings.overlayControlsVisible && currentSettings.overlayHideButtonVisible
        val hasQuickActions = showChatButton || showHideButton
        val quickActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            visibility = if (hasQuickActions) View.VISIBLE else View.GONE
            if (showChatButton) addView(keyboardButton, LinearLayout.LayoutParams(dp(64), dp(42)))
            if (showHideButton) {
                addView(hideButton, LinearLayout.LayoutParams(dp(64), dp(42)).apply {
                    if (showChatButton) marginStart = dp(6)
                })
            }
        }
        petColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(characterRow)
            addView(quickActions, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(44)).apply { topMargin = dp(2) })
        }
        val visibleControlsWidth = when {
            showChatButton && showHideButton -> 134
            showChatButton || showHideButton -> 64
            else -> 0
        }
        val petWidthDp = maxOf(actualCharacterSizeDp + 10, visibleControlsWidth)
        overlayRoot = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(speechCard, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = dp(8)
            })
            addView(petColumn, LinearLayout.LayoutParams(dp(petWidthDp), LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                (if (currentSettings.showOnLockScreen) WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED else 0),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = resources.displayMetrics.widthPixels - dp(petWidthDp + 16)
            y = resources.displayMetrics.heightPixels / 3
        }
        layoutParams = params
        character.setOnTouchListener(DragTouchListener(params, overlayRoot))
        windowManager.addView(overlayRoot, params)
        bubble = overlayRoot
        layoutParams = params
        extraCharacters.clear()
        extraCharacterParams.clear()
        for (index in 1 until visibleCharacterCount) {
            val extra = ImageView(this).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                adjustViewBounds = true
                clipToOutline = false
                elevation = dp(14).toFloat()
                contentDescription = "Персонаж Verity ${index + 1} — отдельный объект"
            }
            val extraParams = makeExtraParams(params, actualCharacterSizeDp, index)
            extra.setOnTouchListener(DragTouchListener(extraParams, extra))
            runCatching { windowManager.addView(extra, extraParams) }.onSuccess {
                if (index == 1) secondaryCharacter = extra
                extraCharacters += extra
                extraCharacterParams[extra] = extraParams
            }
        }
        setCharacterImage(R.drawable.verity_happy_cutout)
    }

    private fun makeExtraParams(anchor: WindowManager.LayoutParams, sizeDp: Int, index: Int): WindowManager.LayoutParams {
        val sizePx = dp(sizeDp)
        return WindowManager.LayoutParams(
            sizePx, sizePx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                (if (chatStore.loadSettings().showOnLockScreen) WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED else 0),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            val screenW = resources.displayMetrics.widthPixels
            val screenH = resources.displayMetrics.heightPixels
            x = (anchor.x - dp((index * (sizeDp + 8)))).coerceAtLeast(0)
            if (x + sizePx > screenW) x = (screenW - sizePx).coerceAtLeast(0)
            y = (anchor.y + dp((index % 2) * (sizeDp + 8))).coerceIn(0, (screenH - sizePx).coerceAtLeast(0))
        }
    }

    private inner class DragTouchListener(
        private val params: WindowManager.LayoutParams,
        private val windowView: View
    ) : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f
        private var previousX = 0f
        private var previousY = 0f
        private var previousTime = 0L
        private var velocityX = 0f
        private var velocityY = 0f

        override fun onTouch(view: View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    stopPhysics(windowView)
                    startX = params.x; startY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    previousX = event.rawX; previousY = event.rawY
                    previousTime = event.eventTime
                    velocityX = 0f; velocityY = 0f
                    view.animate().scaleX(1.08f).scaleY(1.08f).setDuration(90).start()
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val elapsed = (event.eventTime - previousTime).coerceAtLeast(1L) / 1000f
                    velocityX = (event.rawX - previousX) / elapsed
                    velocityY = (event.rawY - previousY) / elapsed
                    previousX = event.rawX; previousY = event.rawY; previousTime = event.eventTime
                    params.x = startX + (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    runCatching { windowManager.updateViewLayout(windowView, params) }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    if (abs(event.rawX - touchX) < dp(8) && abs(event.rawY - touchY) < dp(8)) startListening()
                    else startPhysics(windowView, params, velocityX, velocityY)
                    return true
                }
                MotionEvent.ACTION_CANCEL -> {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    return true
                }
            }
            return false
        }
    }

    private fun startPhysics(view: View, params: WindowManager.LayoutParams, initialVelocityX: Float, initialVelocityY: Float) {
        stopPhysics(view)
        val physics = chatStore.loadSettings().takeIf { it.verityPlus }?.physicsStyle ?: "classic"
        val restitution = when (physics) { "bouncy" -> .92f; "float" -> .82f; else -> .72f }
        val drag = when (physics) { "bouncy" -> .988f; "float" -> .995f; else -> .975f }
        var vx = initialVelocityX.coerceIn(-6000f, 6000f)
        var vy = initialVelocityY.coerceIn(-6000f, 6000f)
        var previousNanos = System.nanoTime()
        lateinit var frame: Runnable
        frame = Runnable {
            val now = System.nanoTime()
            val dt = ((now - previousNanos) / 1_000_000_000f).coerceIn(0f, .033f)
            previousNanos = now
            params.x += (vx * dt).toInt()
            params.y += (vy * dt).toInt()
            val maxX = (resources.displayMetrics.widthPixels - view.width).coerceAtLeast(0)
            val maxY = (resources.displayMetrics.heightPixels - view.height).coerceAtLeast(0)
            var bounced = false
            if (params.x <= 0 || params.x >= maxX) {
                params.x = params.x.coerceIn(0, maxX); vx *= -restitution; bounced = true
            }
            if (params.y <= 0 || params.y >= maxY) {
                params.y = params.y.coerceIn(0, maxY); vy *= -restitution; bounced = true
            }
            if (bounced && view === overlayRoot) showOuch()
            vx *= drag; vy *= drag
            runCatching { windowManager.updateViewLayout(view, params) }
            if (hypot(vx, vy) > 28f) handler.postDelayed(frame, 16L)
            else if (view === overlayRoot) physicsFrame = null
            else extraPhysicsFrames.remove(view)
        }
        if (view === overlayRoot) physicsFrame = frame else extraPhysicsFrames[view] = frame
        handler.post(frame)
    }

    private fun stopPhysics(view: View? = null) {
        if (view == null || view === overlayRoot) {
            physicsFrame?.let(handler::removeCallbacks)
            physicsFrame = null
        }
        if (view == null) {
            extraPhysicsFrames.values.forEach(handler::removeCallbacks)
            extraPhysicsFrames.clear()
        } else {
            extraPhysicsFrames.remove(view)?.let(handler::removeCallbacks)
        }
    }

    private fun removeExtraCharacters() {
        extraCharacters.forEach { view ->
            stopPhysics(view)
            runCatching { windowManager.removeView(view) }
        }
        extraCharacters.clear()
        extraCharacterParams.clear()
        secondaryCharacter = null
    }

    private fun showOuch() {
        if (speechCard.visibility == View.VISIBLE || listening) return
        setCharacterImage(R.drawable.verity_ouch_cutout)
        character.animate().cancel()
        character.animate().rotation(12f).scaleX(.84f).scaleY(.9f).setDuration(90L).withEndAction {
            character.animate().rotation(-10f).scaleX(1.08f).scaleY(1.02f).setDuration(90L).withEndAction {
                character.animate().rotation(0f).scaleX(1f).scaleY(1f).setDuration(110L).start()
            }.start()
        }.start()
        handler.removeCallbacks(resetFaceRunnable)
        handler.postDelayed(resetFaceRunnable, 420L)
    }

    private val resetFaceRunnable = Runnable {
        if (!listening && speechCard.visibility != View.VISIBLE) setCharacterImage(R.drawable.verity_happy_cutout)
    }

    private val mysteryFaceRunnable = Runnable { refreshMysteryState() }

    private fun scheduleMysteryFace() {
        handler.removeCallbacks(mysteryFaceRunnable)
        val settings = MysteryStory.withEventSelected(chatStore.loadSettings())
        chatStore.saveSettings(settings)
        if (!MysteryStory.isEnabled(settings) || settings.mysteryStartedAt <= 0L) return
        val now = System.currentTimeMillis()
        val nextAt = when {
            now < settings.mysteryStartedAt + MysteryStory.delayFor(settings) -> settings.mysteryStartedAt + MysteryStory.delayFor(settings)
            settings.mysteryEvent == 1 && now < settings.mysteryStartedAt + MysteryStory.delayFor(settings) + 24L * 60L * 60L * 1000L -> settings.mysteryStartedAt + MysteryStory.delayFor(settings) + 24L * 60L * 60L * 1000L
            else -> 0L
        }
        if (nextAt > 0L) handler.postDelayed(mysteryFaceRunnable, (nextAt - now).coerceAtLeast(1L))
    }

    private fun refreshMysteryState() {
        val settings = MysteryStory.withEventSelected(chatStore.loadSettings())
        chatStore.saveSettings(settings)
        if (!listening && speechCard.visibility != View.VISIBLE) setCharacterImage(R.drawable.verity_happy_cutout)
        scheduleMysteryFace()
    }

    private fun hop() {
        character.animate().cancel()
        character.animate().translationY(-dp(20).toFloat()).scaleX(1.05f).scaleY(.94f).setDuration(220L).withEndAction {
            character.animate().translationY(0f).scaleX(.96f).scaleY(1.06f).setDuration(240L).withEndAction {
                character.animate().scaleX(1f).scaleY(1f).setDuration(100L).start()
            }.start()
        }.start()
    }

    private fun showSpeech(text: String, mood: String) {
        reloadCustomization()
        scheduleMysteryFace()
        speechPages = paginate(text)
        speechPage = 0
        speechText.text = speechPages.firstOrNull().orEmpty()
        updateTextShake()
        moreButton.visibility = if (speechPages.size > 1) View.VISIBLE else View.INVISIBLE
        speechCard.visibility = View.VISIBLE
        setCharacterImage(
            when (mood) {
                "angry" -> R.drawable.verity_angry_cutout
                "sad", "sleepy" -> R.drawable.verity_sad_talking_cutout
                "normal", "curious" -> R.drawable.verity_normal_cutout
                "ouch", "scary", "surprised" -> R.drawable.verity_ouch_cutout
                else -> R.drawable.verity_happy_cutout
            },
            moodOverride = mood
        )
        speakIfEnabled(text)
        stopPhysics()
        handler.post {
            val params = layoutParams ?: return@post
            val maxX = (resources.displayMetrics.widthPixels - overlayRoot.width).coerceAtLeast(0)
            params.x = params.x.coerceIn(0, maxX)
            windowManager.updateViewLayout(overlayRoot, params)
        }
    }

    private fun showNextSpeechPage() {
        if (speechPage + 1 >= speechPages.size) return
        speechPage++
        speechText.text = speechPages[speechPage]
        updateTextShake()
        moreButton.visibility = if (speechPage + 1 < speechPages.size) View.VISIBLE else View.INVISIBLE
    }

    private fun closeSpeech() {
        speechCard.visibility = View.GONE
        speechPages = emptyList()
        speechPage = 0
        textToSpeech?.stop()
        textShakeAnimator?.cancel()
        speechText.translationX = 0f
        setCharacterImage(R.drawable.verity_happy_cutout)
    }

    private fun paginate(text: String, pageLength: Int = 230): List<String> {
        if (text.length <= pageLength) return listOf(text)
        val result = mutableListOf<String>()
        var remaining = text.trim()
        while (remaining.isNotEmpty()) {
            if (remaining.length <= pageLength) { result += remaining; break }
            val boundary = remaining.take(pageLength).lastIndexOfAny(charArrayOf(' ', '\n', '.', '!', '?'))
                .takeIf { it > pageLength / 2 } ?: pageLength
            result += remaining.take(boundary + 1).trim()
            remaining = remaining.drop(boundary + 1).trim()
        }
        return result
    }

    private fun prepareSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        speechRecognizer = (if (Build.VERSION.SDK_INT >= 31 && runCatching { SpeechRecognizer.isOnDeviceRecognitionAvailable(this) }.getOrDefault(false)) {
            SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
        } else {
            SpeechRecognizer.createSpeechRecognizer(this)
        }).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { setListeningVisual(true) }
                override fun onBeginningOfSpeech() = Unit
                override fun onRmsChanged(rmsdB: Float) {
                    val scale = (1f + rmsdB.coerceAtLeast(0f) / 60f).coerceAtMost(1.18f)
                    character.scaleX = scale; character.scaleY = scale
                }
                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() { setListeningVisual(false) }
                override fun onError(error: Int) {
                    setListeningVisual(false)
                    val message = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH -> "Я ничего не услышал."
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Тут слишком тихо. Скажи ещё раз."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                        SpeechRecognizer.ERROR_SERVER -> "Связь сломалась. Попробуем ещё раз."
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Подожди, я ещё слушаю."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Мне не разрешили слушать микрофон."
                        else -> "Что-то пошло не так. Попробуй ещё раз."
                    }
                    showSpeech(message, "sad")
                }
                override fun onResults(results: Bundle?) {
                    setListeningVisual(false)
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!text.isNullOrBlank()) {
                        speechCard.visibility = View.GONE
                        setCharacterImage(R.drawable.verity_happy_cutout)
                        sendVoiceMessage(text)
                    } else showSpeech("Я ничего не услышал.", "sad")
                }
                override fun onPartialResults(partialResults: Bundle?) = Unit
                override fun onEvent(eventType: Int, params: Bundle?) = Unit
            })
        }
    }

    private fun startListening() {
        if (requestInFlight) {
            showSpeech("Подожди немного, я ещё думаю над прошлой фразой.", "normal")
            return
        }
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            showSpeech("Мне нужно разрешение на микрофон, иначе я тебя не услышу.", "sad")
            return
        }
        closeSpeech()
        val voiceLanguage = chatStore.loadSettings().language.let { if (it == "ru" || it.isBlank()) "ru-RU" else if (it == "auto") Locale.getDefault().toLanguageTag() else it }
        speechRecognizer?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, voiceLanguage)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Говорите с Verity")
        }) ?: showSpeech("На этом устройстве распознавание речи недоступно.", "sad")
    }

    private fun sendScreenImageToAi(bitmap: Bitmap, settings: dev.veriti.app.data.AppSettings) {
        val prompt = "Посмотри на снимок экрана телефона и объясни, что на нём видно. Называй только то, что действительно различимо. Не нажимай кнопки и не пытайся совершать действия."
        serviceScope.launch {
            try {
                val encoded = withContext(Dispatchers.IO) {
                    val maxSide = 1152
                    val scale = minOf(1f, maxSide.toFloat() / maxOf(bitmap.width, bitmap.height))
                    val width = (bitmap.width * scale).toInt().coerceAtLeast(1)
                    val height = (bitmap.height * scale).toInt().coerceAtLeast(1)
                    val scaled = if (width == bitmap.width && height == bitmap.height) bitmap else Bitmap.createScaledBitmap(bitmap, width, height, true)
                    try {
                        val output = ByteArrayOutputStream()
                        scaled.compress(Bitmap.CompressFormat.JPEG, 62, output)
                        Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
                    } finally {
                        if (scaled !== bitmap) scaled.recycle()
                        if (!bitmap.isRecycled) bitmap.recycle()
                    }
                }
                val (reply, chatId) = withContext(Dispatchers.IO) {
                    val chats = chatStore.loadChats()
                    val createNew = startNewOverlayChat
                    startNewOverlayChat = false
                    val base = if (createNew) null else overlayChatId?.let { id -> chats.firstOrNull { it.id == id } }
                        ?: chats.firstOrNull()
                    val current = base ?: Chat()
                    val imageMessage = Message(
                        role = "user",
                        content = prompt,
                        attachments = listOf(dev.veriti.app.data.FileAttachment("screen.jpg", "image/jpeg", encoded, true))
                    )
                    val prior = chats.filterNot { it.id == current.id }
                        .sortedByDescending { it.updatedAt }.take(4).flatMap { it.messages.takeLast(4) }.takeLast(16)
                    val answer = aiClient.complete(settings, prior + current.messages.takeLast(20) + imageMessage)
                    val userSaved = Message(role = "user", content = prompt)
                    val completed = current.copy(
                        title = if (current.messages.isEmpty()) "Разбор экрана" else current.title,
                        messages = current.messages + userSaved + Message(role = "assistant", content = answer.text, mood = answer.mood),
                        updatedAt = System.currentTimeMillis()
                    )
                    chatStore.saveChats((chats.filterNot { it.id == completed.id } + completed).sortedByDescending { it.updatedAt })
                    answer to completed.id
                }
                overlayChatId = chatId
                AssistantBridge.notifyOverlayChatChanged(chatId)
                showSpeech(reply.text, reply.mood)
            } catch (error: Exception) {
                val detail = error.message.orEmpty()
                val labels = VerityAccessibilityService.readVisibleScreen()
                if (labels.isNotBlank()) {
                    runCatching {
                        val fallback = withContext(Dispatchers.IO) {
                            aiClient.complete(settings, listOf(Message(role = "user", content = "Модель не смогла обработать изображение. Объясни экран по доступным подписям интерфейса:\n$labels")))
                        }
                        showSpeech(fallback.text, fallback.mood)
                    }.onFailure { showSpeech("Модель не смогла рассмотреть изображение. Проверь, поддерживает ли выбранная модель картинки. $detail", "sad") }
                } else {
                    showSpeech("Не получилось разобрать снимок. Возможно, выбранная модель не поддерживает изображения. $detail", "sad")
                }
            } finally {
                requestInFlight = false
            }
        }
    }

    private fun sendVoiceMessage(text: String) {
        val settings = chatStore.loadSettings()
        var requestText = text.trim()
        val screenQuestion = listOf(
            "что на экране", "объясни экран", "прочитай экран", "что сейчас открыто",
            "объясни что видно", "сделай скриншот", "посмотри на экран", "покажи что на экране"
        ).any { requestText.contains(it, ignoreCase = true) }
        if (screenQuestion) {
            if (settings.screenImageAnalysisEnabled) {
                requestInFlight = true
                showSpeech("Сейчас посмотрю на экран…", "normal")
                // Hide the speech card before the one-shot capture so it does not cover the app.
                handler.postDelayed({
                    speechCard.visibility = View.GONE
                    VerityAccessibilityService.captureCurrentScreen { bitmap, failure ->
                        if (bitmap == null) {
                            requestInFlight = false
                            val labels = VerityAccessibilityService.readVisibleScreen()
                            if (labels.isBlank()) {
                                showSpeech(failure ?: "Не получилось прочитать экран. Проверь службу специальных возможностей.", "sad")
                            } else {
                                sendVoiceMessage("Помоги понять открытое приложение по этим доступным подписям интерфейса:\n$labels")
                            }
                        } else {
                            sendScreenImageToAi(bitmap, settings)
                        }
                    }
                }, 650L)
                return
            }
            val labels = VerityAccessibilityService.readVisibleScreen()
            if (labels.isBlank()) {
                showSpeech("Я пока не вижу подписи интерфейса. Включи службу специальных возможностей Verity. Чтобы я мог рассматривать картинку экрана, отдельно разреши анализ снимка в настройках.", "sad")
                return
            }
            requestText = "Объясни пользователю, что сейчас отображается на экране телефона. Не нажимай ничего и не делай выводов о скрытых данных. Вот доступные подписи интерфейса:\n$labels"
        }
        val normalizedVoice = text.lowercase(Locale.ROOT).replace('ё', 'е').trim().removeSuffix(".").removeSuffix("!")
        val haAction = when {
            Regex("^(?:верити[, ]*)?(закрой шторы|закрой занавески)$").matches(normalizedVoice) -> "close_cover"
            Regex("^(?:верити[, ]*)?(открой шторы|открой занавески)$").matches(normalizedVoice) -> "open_cover"
            Regex("^(?:верити[, ]*)?(включи свет|включи лампу)$").matches(normalizedVoice) -> "turn_on_light"
            Regex("^(?:верити[, ]*)?(выключи свет|выключи лампу)$").matches(normalizedVoice) -> "turn_off_light"
            else -> null
        }
        if (haAction != null) {
            val (domain, service, entity) = when (haAction) {
                "close_cover" -> Triple("cover", "close_cover", settings.homeAssistantCoverEntityId.ifBlank { settings.homeAssistantEntityId.takeIf { id -> id.startsWith("cover.") }.orEmpty() })
                "open_cover" -> Triple("cover", "open_cover", settings.homeAssistantCoverEntityId.ifBlank { settings.homeAssistantEntityId.takeIf { id -> id.startsWith("cover.") }.orEmpty() })
                "turn_on_light" -> Triple("light", "turn_on", settings.homeAssistantLightEntityId.ifBlank { settings.homeAssistantEntityId.takeIf { id -> id.startsWith("light.") }.orEmpty() })
                else -> Triple("light", "turn_off", settings.homeAssistantLightEntityId.ifBlank { settings.homeAssistantEntityId.takeIf { id -> id.startsWith("light.") }.orEmpty() })
            }
            if (entity.substringBefore('.') != domain) {
                showSpeech("Для этой команды в настройках умного дома выбери устройство типа $domain и укажи его entity_id.", "normal")
                return
            }
            requestInFlight = true
            showSpeech("Сейчас проверю подключение к умному дому…", "normal")
            serviceScope.launch {
                val result = withContext(Dispatchers.IO) {
                    HomeAssistantClient.call(settings.homeAssistantUrl, settings.homeAssistantToken, entity, domain, service)
                }
                showSpeech(result.message, if (result.ok) "happy" else "sad")
                requestInFlight = false
            }
            return
        }
        val clickRequest = Regex("^(?:верити[, ]+)?нажми(?: на)?(?: кнопку)?[ «\"]*(.+?)[ »\"]*[.!]?$", RegexOption.IGNORE_CASE)
            .matchEntire(text.trim())?.groupValues?.getOrNull(1)?.trim()
        if (!clickRequest.isNullOrBlank()) {
            val result = if (settings.voiceClickEnabled) VerityAccessibilityService.clickByText(clickRequest)
            else VerityAccessibilityService.ClickResult.DISABLED
            showSpeech(
                when (result) {
                    VerityAccessibilityService.ClickResult.CLICKED -> "Нажал «$clickRequest»."
                    VerityAccessibilityService.ClickResult.BLOCKED -> "Эту кнопку я не нажимаю ради твоей безопасности."
                    VerityAccessibilityService.ClickResult.NOT_FOUND -> "Не вижу кнопку «$clickRequest» на экране."
                    VerityAccessibilityService.ClickResult.DISABLED -> "Сначала включи управление приложениями в настройках Verity."
                },
                if (result == VerityAccessibilityService.ClickResult.CLICKED) "happy" else "normal"
            )
            return
        }
        MysteryStory.reply(settings, requestText)?.let { scripted ->
            val decorated = MysteryStory.decorateAnswer(scripted.settings, scripted.text, scripted.mood)
            chatStore.saveSettings(decorated.settings)
            serviceScope.launch {
                val chatId = withContext(Dispatchers.IO) {
                    val chats = chatStore.loadChats()
                    val base = overlayChatId?.let { id -> chats.firstOrNull { it.id == id } } ?: chats.firstOrNull() ?: Chat()
                    val complete = base.copy(
                        title = if (base.messages.isEmpty()) requestText.replace('\n', ' ').take(42) else base.title,
                        messages = base.messages + Message(role = "user", content = requestText) +
                            Message(role = "assistant", content = decorated.text, mood = decorated.mood),
                        updatedAt = System.currentTimeMillis()
                    )
                    chatStore.saveChats((chats.filterNot { it.id == complete.id } + complete).sortedByDescending { it.updatedAt })
                    complete.id
                }
                overlayChatId = chatId
                AssistantBridge.notifyOverlayChatChanged(chatId)
                showSpeech(decorated.text, decorated.mood)
            }
            return
        }
        if (settings.apiKey.isBlank() && !settings.baseUrl.startsWith("http://10.0.2.2")) {
            showSpeech("Сначала добавь API-ключ в настройках. Например, можно быстро подключить Gemini.", "sad")
            return
        }
        requestInFlight = true
        showSpeech("Секунду…", "normal")
        val createNewChat = startNewOverlayChat
        startNewOverlayChat = false
        serviceScope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    val chats = chatStore.loadChats()
                    val base = if (createNewChat) null else {
                        overlayChatId?.let { id -> chats.firstOrNull { it.id == id } } ?: chats.firstOrNull()
                    } ?: Chat()
                    val userMessage = Message(role = "user", content = requestText)
                    val pending = base.copy(
                        title = if (base.messages.isEmpty()) requestText.replace('\n', ' ').take(42) else base.title,
                        messages = base.messages + userMessage,
                        updatedAt = System.currentTimeMillis()
                    )
                    val rememberedHistory = chats
                        .filterNot { it.id == base.id }
                        .sortedByDescending { it.updatedAt }
                        .take(5)
                        .flatMap { it.messages.takeLast(6) }
                        .takeLast(24) + pending.messages
                    chatStore.saveChats((chats.filterNot { it.id == pending.id } + pending).sortedByDescending { it.updatedAt })
                    val answer = aiClient.complete(settings, rememberedHistory)
                    val decorated = MysteryStory.decorateAnswer(settings, answer.text, answer.mood)
                    chatStore.saveSettings(decorated.settings)
                    val complete = pending.copy(
                        messages = pending.messages + Message(role = "assistant", content = decorated.text, mood = decorated.mood),
                        updatedAt = System.currentTimeMillis()
                    )
                    chatStore.saveChats((chats.filterNot { it.id == complete.id } + complete).sortedByDescending { it.updatedAt })
                    decorated to complete.id
                }
            }.onSuccess { (answer, chatId) ->
                overlayChatId = chatId
                AssistantBridge.notifyOverlayChatChanged(chatId)
                showSpeech(answer.text, answer.mood)
            }.onFailure { error ->
                val detail = error.message.orEmpty()
                val friendly = when {
                    detail.contains("UnknownHost", true) || detail.contains("Unable to resolve", true) -> "Ой, интернета сейчас нет. Я могу показывать свои сохранённые функции, но для ответа нейросети нужно подключение."
                    detail.contains("timed out", true) || detail.contains("timeout", true) -> "Сеть долго молчит. Проверь интернет и попробуй ещё раз."
                    detail.contains("401") || detail.contains("403") -> "Сервер не принял API-ключ. Проверь его в настройках."
                    else -> "Не получилось связаться с нейросетью. Проверь адрес сервера, модель и интернет."
                }
                showSpeech(friendly, "sad")
            }
            requestInFlight = false
        }
    }

    private fun setListeningVisual(value: Boolean) {
        listening = value
        character.alpha = if (value) .78f else 1f
        setCharacterImage(if (value) R.drawable.verity_sad_talking_cutout else R.drawable.verity_happy_cutout)
        if (!value) { character.scaleX = 1f; character.scaleY = 1f }
    }

    private fun openApp() {
        startActivity(Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        })
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, getString(R.string.overlay_channel), NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun reloadCustomization() {
        // Settings are intentionally read at render time so a selected skin applies immediately.
    }

    private fun setCharacterImage(fallback: Int, moodOverride: String? = null) {
        val mood = moodOverride ?: when (fallback) {
            R.drawable.verity_angry_cutout -> "angry"
            R.drawable.verity_sad_talking_cutout -> "sad"
            R.drawable.verity_normal_cutout -> "normal"
            R.drawable.verity_ouch_cutout -> "ouch"
            else -> "happy"
        }
        val settings = chatStore.loadSettings()
        val avatar = SkinSheet.loadAvatar(this, settings.customAvatarUri)

        fun applyTo(target: ImageView, slot: Int, selectedMood: String) {
            val slotAsset = dev.veriti.app.data.CharacterSlotAssets.get(settings, slot)
                .ifBlank { settings.selectedCharacterAsset }
            val slotSprite = if (avatar == null && slotAsset.isNotBlank()) {
                SkinSheet.loadCatalogSprite(this, slotAsset, selectedMood)
            } else null
            val useAlternate = slot > 0 && slot % 2 == 0 && settings.secondarySkinStyle != "none"
            val selectedSettings = if (useAlternate) settings.copy(verityPlus = true, skinStyle = settings.secondarySkinStyle)
                else settings
            when {
                avatar != null -> {
                    val circular = RoundedBitmapDrawableFactory.create(resources, avatar).apply {
                        isCircular = true
                        antiAlias = true
                    }
                    target.setImageDrawable(circular)
                }
                slotSprite != null -> target.setImageBitmap(slotSprite)
                else -> {
                    val custom = SkinSheet.faceForMood(this, selectedSettings, selectedMood)
                    if (custom != null) target.setImageBitmap(custom) else target.setImageResource(fallback)
                }
            }
        }

        applyTo(character, 0, mood)
        extraCharacters.forEachIndexed { index, extra ->
            val moods = listOf("normal", "angry", "sad", "talking", "ouch", "scary", "happy", "curious", "sleepy", "laughing", "surprised", "love")
            applyTo(extra, index + 1, moods[index % moods.size])
        }
    }

    private fun updateTextShake() {
        textShakeAnimator?.cancel()
        speechText.translationX = 0f
        if (!MysteryStory.shouldShakeText(chatStore.loadSettings())) return
        textShakeAnimator = ObjectAnimator.ofFloat(
            speechText,
            View.TRANSLATION_X,
            -dp(2).toFloat(), dp(2).toFloat(), -dp(1).toFloat(), dp(1).toFloat(), 0f
        ).apply {
            duration = 260L
            repeatCount = ValueAnimator.INFINITE
            start()
        }
    }

    private fun prepareTextToSpeech() {
        textToSpeech = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                val selectedLanguage = chatStore.loadSettings().language
                val languageTag = when (selectedLanguage) {
                    "", "ru" -> "ru-RU"
                    "auto" -> Locale.getDefault().toLanguageTag()
                    else -> selectedLanguage
                }
                val locale = Locale.forLanguageTag(languageTag)
                val availability = textToSpeech?.isLanguageAvailable(locale) ?: TextToSpeech.LANG_NOT_SUPPORTED
                textToSpeech?.language = if (availability >= TextToSpeech.LANG_AVAILABLE) locale else Locale.forLanguageTag("ru-RU")
            }
        }
    }

    private fun speakIfEnabled(text: String) {
        val settings = chatStore.loadSettings()
        if (!ttsReady || !settings.verityPlus || settings.voiceStyle == "off") return
        val (pitch, rate) = when (settings.voiceStyle) {
            "bright" -> 1.35f to 1.05f
            "deep" -> .72f to .9f
            "fast" -> 1.05f to 1.35f
            else -> 1f to 1f
        }
        textToSpeech?.setPitch(pitch)
        textToSpeech?.setSpeechRate(rate)
        textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "verity_reply")
    }

    private fun refreshOverlaySettings() {
        stopPhysics()
        removeExtraCharacters()
        bubble?.let { runCatching { windowManager.removeView(it) } }
        bubble = null
        showBubble()
        scheduleMysteryFace()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_REFRESH -> handler.post(::refreshOverlaySettings)
            ACTION_HIDE_FOR_GAME -> handler.post { if (::overlayRoot.isInitialized) overlayRoot.visibility = View.GONE }
            ACTION_SHOW_AFTER_GAME -> handler.post { if (::overlayRoot.isInitialized) overlayRoot.visibility = View.VISIBLE }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(wanderRunnable)
        handler.removeCallbacks(resetFaceRunnable)
        handler.removeCallbacks(mysteryFaceRunnable)
        stopPhysics()
        removeExtraCharacters()
        speechRecognizer?.destroy()
        speechRecognizer = null
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
        textShakeAnimator?.cancel()
        textShakeAnimator = null
        AssistantBridge.onAssistantReply = null
        serviceScope.cancel()
        bubble?.let { windowManager.removeView(it) }
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_REFRESH = "dev.veriti.app.action.REFRESH_OVERLAY"
        const val ACTION_HIDE_FOR_GAME = "dev.veriti.app.action.HIDE_FOR_GAME"
        const val ACTION_SHOW_AFTER_GAME = "dev.veriti.app.action.SHOW_AFTER_GAME"
        private const val CHANNEL_ID = "veriti_overlay"
        private const val NOTIFICATION_ID = 77
    }
}
