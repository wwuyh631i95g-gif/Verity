package dev.veriti.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import dev.veriti.app.data.AppSettings
import dev.veriti.app.network.HomeAssistantClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun HomeAssistantScreen(settings: AppSettings, onSave: (AppSettings) -> Unit, onBack: () -> Unit) {
    var url by remember(settings.homeAssistantUrl) { mutableStateOf(settings.homeAssistantUrl) }
    var token by remember(settings.homeAssistantToken) { mutableStateOf(settings.homeAssistantToken) }
    var entity by remember(settings.homeAssistantEntityId) { mutableStateOf(settings.homeAssistantEntityId) }
    var lightEntity by remember(settings.homeAssistantLightEntityId) { mutableStateOf(settings.homeAssistantLightEntityId) }
    var coverEntity by remember(settings.homeAssistantCoverEntityId) { mutableStateOf(settings.homeAssistantCoverEntityId) }
    var switchEntity by remember(settings.homeAssistantSwitchEntityId) { mutableStateOf(settings.homeAssistantSwitchEntityId) }
    var status by remember { mutableStateOf<String?>(null) }
    var working by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun save() = onSave(settings.copy(
        homeAssistantUrl = url.trim(), homeAssistantToken = token.trim(), homeAssistantEntityId = entity.trim(),
        homeAssistantLightEntityId = lightEntity.trim(), homeAssistantCoverEntityId = coverEntity.trim(),
        homeAssistantSwitchEntityId = switchEntity.trim()
    ))
    fun runAction(domain: String, service: String, deviceEntity: String) {
        save()
        working = true
        status = "Отправляю команду…"
        scope.launch {
            val result = withContext(Dispatchers.IO) { HomeAssistantClient.call(url, token, deviceEntity, domain, service) }
            status = result.message
            working = false
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = {
            TopAppBar(
                modifier = Modifier.statusBarsPadding(),
                title = { Text("Умный дом", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Назад") } }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).navigationBarsPadding().padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 30.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Rounded.Home, null, tint = MaterialTheme.colorScheme.primary)
                        Text("Подключение к Home Assistant", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Эта часть уже отправляет реальные команды REST API. Для Android используйте HTTPS-адрес сервера (например, Home Assistant Cloud или HTTPS-прокси).", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                OutlinedTextField(url, { url = it }, label = { Text("Адрес сервера") }, placeholder = { Text("https://your-home-assistant.example") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            item {
                OutlinedTextField(token, { token = it }, label = { Text("Long-Lived Access Token") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                Text("Токен хранится в локальных настройках приложения. Не отправляй его в чат и не публикуй.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            item {
                OutlinedTextField(lightEntity, { lightEntity = it }, label = { Text("ID света (entity_id)") }, placeholder = { Text("light.living_room") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            item {
                OutlinedTextField(coverEntity, { coverEntity = it }, label = { Text("ID штор / жалюзи") }, placeholder = { Text("cover.curtains") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            item {
                OutlinedTextField(switchEntity, { switchEntity = it }, label = { Text("ID выключателя (необязательно)") }, placeholder = { Text("switch.desk") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            item {
                OutlinedTextField(entity, { entity = it }, label = { Text("Дополнительный ID устройства (необязательно)") }, placeholder = { Text("fan.office") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            item {
                Button(onClick = {
                    save(); working = true; status = "Проверяю соединение…"
                    scope.launch {
                        val result = withContext(Dispatchers.IO) { HomeAssistantClient.test(url, token) }
                        status = result.message; working = false
                    }
                }, enabled = !working && url.isNotBlank() && token.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                    Text(if (working) "Подождите…" else "Сохранить и проверить связь")
                }
            }
            item { Text("Команды для выбранного устройства", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { runAction("light", "turn_on", lightEntity) }, enabled = !working && lightEntity.isNotBlank(), modifier = Modifier.weight(1f)) { Text("Свет: вкл.") }
                    OutlinedButton(onClick = { runAction("light", "turn_off", lightEntity) }, enabled = !working && lightEntity.isNotBlank(), modifier = Modifier.weight(1f)) { Text("Свет: выкл.") }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { runAction("cover", "open_cover", coverEntity) }, enabled = !working && coverEntity.isNotBlank(), modifier = Modifier.weight(1f)) { Text("Открыть шторы") }
                    OutlinedButton(onClick = { runAction("cover", "close_cover", coverEntity) }, enabled = !working && coverEntity.isNotBlank(), modifier = Modifier.weight(1f)) { Text("Закрыть шторы") }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { runAction("switch", "turn_on", switchEntity) }, enabled = !working && switchEntity.isNotBlank(), modifier = Modifier.weight(1f)) { Text("Вкл. выключатель") }
                    OutlinedButton(onClick = { runAction("switch", "turn_off", switchEntity) }, enabled = !working && switchEntity.isNotBlank(), modifier = Modifier.weight(1f)) { Text("Выкл. выключатель") }
                }
            }
            item {
                status?.let { Text(it, color = if (it.startsWith("Команда") || it.startsWith("Связь")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium) }
            }
            item {
                Text("Команды можно произносить плавающему Verity: «Верити, закрой шторы», «открой шторы», «включи свет» или «выключи свет». Для этого заполни соответствующие поля ID света и штор. Для голосового управления выключателем пока есть кнопки на этом экране. Голосовые команды не заменяют проверку перед важными действиями.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
