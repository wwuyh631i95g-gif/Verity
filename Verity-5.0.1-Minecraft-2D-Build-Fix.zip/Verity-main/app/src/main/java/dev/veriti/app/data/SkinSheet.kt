package dev.veriti.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.net.Uri
import dev.veriti.app.R
import java.io.File
import java.util.ArrayDeque

data class SkinStroke(
    val points: List<PointF>,
    val color: Int,
    val width: Float
)

data class CustomSkinEntry(val uri: String, val name: String, val updatedAt: Long)

object SkinSheet {
    private const val WIDTH = 968
    private const val HEIGHT = 1272
    private val rows = floatArrayOf(.13f, .32f, .52f, .70f, .88f)
    private val primaryColumns = floatArrayOf(.24f, .51f)

    fun isValidTemplate(context: Context, uri: Uri): Boolean {
        val bitmap = runCatching { context.contentResolver.openInputStream(uri)?.use(BitmapFactory::decodeStream) }.getOrNull()
            ?: return false
        return bitmap.width >= 128 && bitmap.height >= 128
    }

    /** Copies a user-picked image into app storage so the skin survives reboots and revoked picker grants. */
    fun importCustomSkin(context: Context, uri: Uri): String? {
        val bitmap = runCatching { context.contentResolver.openInputStream(uri)?.use(BitmapFactory::decodeStream) }.getOrNull()
            ?: return null
        if (bitmap.width < 128 || bitmap.height < 128) return null
        val ratio = bitmap.width / bitmap.height.toFloat()
        val isSheet = ratio in .68f..0.82f && rows.all { y -> primaryColumns.all { x -> hasVisibleFace(bitmap, x, y) } }
        val dir = File(context.filesDir, "skins").apply { mkdirs() }
        val file = File(dir, "${if (isSheet) "sheet" else "single"}_${System.currentTimeMillis()}.png")
        return runCatching {
            file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            Uri.fromFile(file).toString()
        }.getOrNull()
    }


    /** Lists only user-created/imported skins in the private skins folder. Stock assets are never included. */
    fun listCustomSkins(context: Context): List<CustomSkinEntry> {
        val dir = File(context.filesDir, "skins")
        return dir.listFiles()
            ?.filter { it.isFile && it.extension.equals("png", ignoreCase = true) }
            ?.sortedByDescending { it.lastModified() }
            ?.map { CustomSkinEntry(Uri.fromFile(it).toString(), it.nameWithoutExtension, it.lastModified()) }
            .orEmpty()
    }

    /** Deletes only a file inside this app's own skins folder; built-in assets cannot be removed here. */
    fun deleteCustomSkin(context: Context, value: String): Boolean = runCatching {
        val uri = Uri.parse(value)
        require(uri.scheme == "file") { "Можно удалить только сохранённую внутри Verity работу." }
        val file = File(uri.path ?: error("Некорректный путь")).canonicalFile
        val root = File(context.filesDir, "skins").canonicalFile
        require(file.parentFile == root && file.extension.equals("png", ignoreCase = true)) {
            "Можно удалить только собственную картинку из галереи Verity."
        }
        file.delete()
    }.getOrDefault(false)

    /** Imports a single portrait and stores it in app-private storage. */
    fun importAvatar(context: Context, uri: Uri): String? {
        val source = runCatching {
            context.contentResolver.openInputStream(uri)?.use(BitmapFactory::decodeStream)
        }.getOrNull() ?: return null
        if (source.width < 32 || source.height < 32) return null
        val side = minOf(maxOf(source.width, source.height), 1024)
        val scaled = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(scaled)
        val scale = minOf(side.toFloat() / source.width, side.toFloat() / source.height)
        val width = source.width * scale
        val height = source.height * scale
        val left = (side - width) / 2f
        val top = (side - height) / 2f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        canvas.drawBitmap(source, null, android.graphics.RectF(left, top, left + width, top + height), paint)
        val dir = File(context.filesDir, "avatars").apply { mkdirs() }
        val file = File(dir, "avatar_${System.currentTimeMillis()}.png")
        return runCatching {
            file.outputStream().use { scaled.compress(Bitmap.CompressFormat.PNG, 100, it) }
            scaled.recycle()
            if (source !== scaled && !source.isRecycled) source.recycle()
            Uri.fromFile(file).toString()
        }.getOrNull()
    }

    fun loadAvatar(context: Context, value: String): Bitmap? {
        if (value.isBlank()) return null
        val uri = Uri.parse(value)
        val source = if (uri.scheme == "file") BitmapFactory.decodeFile(uri.path)
            else runCatching { context.contentResolver.openInputStream(uri)?.use(BitmapFactory::decodeStream) }.getOrNull()
            ?: return null
        val side = minOf(source.width, source.height)
        val left = (source.width - side) / 2
        val top = (source.height - side) / 2
        return runCatching { Bitmap.createBitmap(source, left, top, side, side) }.getOrNull()
    }


    fun loadCatalogSprite(context: Context, assetPath: String, mood: String = "happy"): Bitmap? {
        // User-created characters are stored as private circular PNG files. They are
        // intentionally static; built-in catalog sprite sheets keep their mood frames.
        if (assetPath.startsWith("file://")) {
            val custom = CustomCharacterLibrary.loadBitmap(context, assetPath) ?: return null
            val result = runCatching { custom.copy(Bitmap.Config.ARGB_8888, true) }.getOrNull()
            custom.recycle()
            return result
        }
        if (!assetPath.startsWith("character_catalog/sprites/") || assetPath.contains("..")) return null
        val resolvedPath = if (assetPath.endsWith("/")) {
            val group = assetPath.removeSuffix("/").substringAfterLast('/')
            if (!group.matches(Regex("\\d{2}"))) return null
            val frame = when (mood) {
                "happy" -> 1
                "normal" -> 2
                "angry" -> 3
                "sad" -> 4
                "talking" -> 5
                "ouch" -> 6
                "scary" -> 7
                "curious" -> 8
                "sleepy" -> 9
                "laughing" -> 10
                "surprised" -> 11
                "love" -> 12
                else -> 8
            }
            "$assetPath${group}_${frame.toString().padStart(2, '0')}.png"
        } else assetPath
        if (!resolvedPath.endsWith(".png")) return null
        val decoded = runCatching { context.assets.open(resolvedPath).use(BitmapFactory::decodeStream) }.getOrNull() ?: return null
        val result = decoded.copy(Bitmap.Config.ARGB_8888, true)
        if (result !== decoded) decoded.recycle()
        removeConnectedDarkBackground(result)
        return result
    }

    fun faceForMood(context: Context, settings: AppSettings, mood: String): Bitmap? {
        val selectedStyle = if (settings.verityPlus) settings.skinStyle else "verity"
        val sheet = when (selectedStyle) {
            "verity" -> BitmapFactory.decodeResource(context.resources, R.drawable.skin_verity)
            "legacy" -> BitmapFactory.decodeResource(context.resources, R.drawable.skin_verity_legacy)
            "pink" -> BitmapFactory.decodeResource(context.resources, R.drawable.skin_verity_pink)
            "foxy" -> BitmapFactory.decodeResource(context.resources, R.drawable.skin_foxy_blue)
            "abesity" -> BitmapFactory.decodeResource(context.resources, R.drawable.skin_abesity)
            "custom" -> loadCustom(context, settings.customSkinSheetUri)
            else -> BitmapFactory.decodeResource(context.resources, R.drawable.skin_verity)
        } ?: return null
        if (MysteryStory.isScary(settings)) {
            return BitmapFactory.decodeResource(context.resources, R.drawable.verity_scary_event)
        }
        if (selectedStyle == "custom" && isSingleCustom(settings.customSkinSheetUri)) {
            return prepareSingleFace(sheet)
        }
        val effectiveMood = mood
        val (x, y) = when (effectiveMood) {
            "sad" -> .24f to .13f
            "angry" -> .24f to .52f
            "normal" -> .24f to .70f
            "ouch" -> .51f to .70f
            "scary" -> .51f to .88f
            "talking" -> .51f to .32f
            else -> .51f to .32f
        }
        val face = extractFace(sheet, x, y)
        return if (selectedStyle == "verity") addDarkOutline(face) else face
    }

    fun createDrawnTemplate(context: Context, baseColor: Int, strokes: List<SkinStroke>): String {
        val bitmap = Bitmap.createBitmap(WIDTH, HEIGHT, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val facePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = baseColor; style = Paint.Style.FILL }
        val allSlots = buildList {
            rows.forEach { y -> primaryColumns.forEach { x -> add(x to y) } }
            add(.80f to .52f)
            add(.80f to .70f)
        }
        val radius = WIDTH * .09f
        allSlots.forEach { (cx, cy) ->
            val centerX = WIDTH * cx
            val centerY = HEIGHT * cy
            canvas.drawCircle(centerX, centerY, radius, facePaint)
            strokes.forEach { stroke ->
                if (stroke.points.size < 2) return@forEach
                val path = Path()
                stroke.points.forEachIndexed { index, point ->
                    val px = centerX + (point.x - .5f) * radius * 2f
                    val py = centerY + (point.y - .5f) * radius * 2f
                    if (index == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                canvas.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = stroke.color
                    style = Paint.Style.STROKE
                    strokeCap = Paint.Cap.ROUND
                    strokeJoin = Paint.Join.ROUND
                    strokeWidth = stroke.width * radius * 2f
                })
            }
        }
        val dir = File(context.filesDir, "skins").apply { mkdirs() }
        val file = File(dir, "drawn_${System.currentTimeMillis()}.png")
        file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return Uri.fromFile(file).toString()
    }

    private fun loadCustom(context: Context, value: String): Bitmap? {
        if (value.isBlank()) return null
        val uri = Uri.parse(value)
        return if (uri.scheme == "file") BitmapFactory.decodeFile(uri.path)
        else runCatching { context.contentResolver.openInputStream(uri)?.use(BitmapFactory::decodeStream) }.getOrNull()
    }

    private fun hasVisibleFace(bitmap: Bitmap, centerX: Float, centerY: Float): Boolean {
        val cx = (bitmap.width * centerX).toInt()
        val cy = (bitmap.height * centerY).toInt()
        val radius = (bitmap.width * .075f).toInt().coerceAtLeast(10)
        var visible = 0
        var sampled = 0
        var y = cy - radius
        while (y <= cy + radius) {
            var x = cx - radius
            while (x <= cx + radius) {
                if (x in 0 until bitmap.width && y in 0 until bitmap.height) {
                    val color = bitmap.getPixel(x, y)
                    val bright = maxOf(Color.red(color), Color.green(color), Color.blue(color))
                    if (Color.alpha(color) > 30 && bright > 65) visible++
                    sampled++
                }
                x += 5
            }
            y += 5
        }
        return sampled > 0 && visible.toFloat() / sampled > .18f
    }

    private fun extractFace(sheet: Bitmap, centerX: Float, centerY: Float): Bitmap {
        // A wider crop keeps ears, hair, hands and the top of larger skins inside the bitmap.
        val side = (sheet.width * .28f).toInt().coerceAtMost(sheet.height)
        val left = (sheet.width * centerX - side / 2f).toInt().coerceIn(0, sheet.width - side)
        val top = (sheet.height * centerY - side / 2f).toInt().coerceIn(0, sheet.height - side)
        val crop = Bitmap.createBitmap(sheet, left, top, side, side).copy(Bitmap.Config.ARGB_8888, true)
        removeConnectedDarkBackground(crop)
        return crop
    }

    private fun isSingleCustom(value: String): Boolean =
        Uri.parse(value).lastPathSegment?.startsWith("single_") == true

    private fun prepareSingleFace(source: Bitmap): Bitmap {
        val side = maxOf(source.width, source.height)
        val result = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val scale = minOf(side * .92f / source.width, side * .92f / source.height)
        val left = (side - source.width * scale) / 2f
        val top = (side - source.height * scale) / 2f
        canvas.drawBitmap(source, null, android.graphics.RectF(left, top, left + source.width * scale, top + source.height * scale), Paint(Paint.ANTI_ALIAS_FLAG))
        removeConnectedDarkBackground(result)
        return result
    }

    private fun addDarkOutline(source: Bitmap): Bitmap {
        val result = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val alpha = source.extractAlpha()
        val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(125, 18, 18, 18) }
        val radius = (source.width * .012f).toInt().coerceAtLeast(2)
        for (dx in -radius..radius) for (dy in -radius..radius) {
            if (dx * dx + dy * dy <= radius * radius) {
                canvas.drawBitmap(alpha, dx.toFloat(), dy.toFloat(), outline)
            }
        }
        canvas.drawBitmap(source, 0f, 0f, null)
        alpha.recycle()
        return result
    }

    private fun removeConnectedDarkBackground(bitmap: Bitmap) {
        val width = bitmap.width
        val height = bitmap.height
        val visited = BooleanArray(width * height)
        val queue = ArrayDeque<Int>()
        fun enqueue(x: Int, y: Int) {
            if (x !in 0 until width || y !in 0 until height) return
            val index = y * width + x
            if (visited[index]) return
            val color = bitmap.getPixel(x, y)
            if (Color.alpha(color) < 20 || maxOf(Color.red(color), Color.green(color), Color.blue(color)) < 24) {
                visited[index] = true
                queue.add(index)
            }
        }
        for (x in 0 until width) { enqueue(x, 0); enqueue(x, height - 1) }
        for (y in 0 until height) { enqueue(0, y); enqueue(width - 1, y) }
        while (queue.isNotEmpty()) {
            val index = queue.removeFirst()
            val x = index % width
            val y = index / width
            bitmap.setPixel(x, y, Color.TRANSPARENT)
            enqueue(x - 1, y); enqueue(x + 1, y); enqueue(x, y - 1); enqueue(x, y + 1)
        }
    }
}
