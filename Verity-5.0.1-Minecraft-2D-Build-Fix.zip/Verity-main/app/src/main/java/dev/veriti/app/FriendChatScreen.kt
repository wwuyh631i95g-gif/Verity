package dev.veriti.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import dev.veriti.app.data.AppSettings
import dev.veriti.app.network.FriendChatClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun FriendChatScreen(settings: AppSettings, onSave: (AppSettings) -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var apiKey by remember(settings.friendFirebaseApiKey) { mutableStateOf(settings.friendFirebaseApiKey) }
    var databaseUrl by remember(settings.friendDatabaseUrl) { mutableStateOf(settings.friendDatabaseUrl) }
    var displayName by remember(settings.friendDisplayName) { mutableStateOf(settings.friendDisplayName) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var roomCode by remember(settings.friendRoomCode) { mutableStateOf(settings.friendRoomCode) }
    var session by remember { mutableStateOf<FriendChatClient.Session?>(null) }
    var messages by remember { mutableStateOf<List<FriendChatClient.Message>>(emptyList()) }
    var draft by remember { mutableStateOf("") }
    var status by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var imageToSave by remember { mutableStateOf("") }

    fun saveSettings(nextSession: FriendChatClient.Session? = session, nextRoom: String = roomCode) {
        onSave(settings.copy(
            friendFirebaseApiKey = apiKey.trim(), friendDatabaseUrl = databaseUrl.trim(),
            friendRefreshToken = nextSession?.refreshToken ?: settings.friendRefreshToken,
            friendUid = nextSession?.uid ?: settings.friendUid,
            friendRoomCode = nextRoom.trim().uppercase(), friendDisplayName = displayName.trim().ifBlank { "Друг Verity" }
        ))
    }

    val saveImageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/jpeg")) { uri ->
        if (uri != null && imageToSave.isNotBlank()) {
            runCatching {
                val bytes = Base64.decode(imageToSave, Base64.DEFAULT)
                context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    ?: throw IllegalStateException("Не получилось открыть место сохранения")
            }.onSuccess { status = "Изображение сохранено." }
                .onFailure { status = it.message ?: "Не получилось сохранить изображение." }
        }
        imageToSave = ""
    }
    val pickImageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val active = session
            if (active == null || roomCode.length != 10) {
                status = "Сначала войди и подключись к комнате."
            } else {
                busy = true
                status = "Подготавливаю изображение…"
                scope.launch {
                    val encoded = withContext(Dispatchers.IO) { compressImage(context, uri) }
                    if (encoded == null) {
                        status = "Не удалось прочитать это изображение. Выбери другое фото."
                    } else {
                        val result = withContext(Dispatchers.IO) {
                            FriendChatClient.sendImage(databaseUrl, roomCode, active, displayName, encoded, "image/jpeg")
                        }
                        status = result.error ?: "Изображение отправлено."
                        if (result.ok) {
                            val latest = withContext(Dispatchers.IO) { FriendChatClient.readMessages(databaseUrl, roomCode, active) }
                            latest.value?.let { messages = it }
                        }
                    }
                    busy = false
                }
            }
        }
    }

    LaunchedEffect(settings.friendRefreshToken, settings.friendFirebaseApiKey) {
        if (session == null && settings.friendRefreshToken.isNotBlank() && settings.friendFirebaseApiKey.isNotBlank()) {
            val refreshed = withContext(Dispatchers.IO) { FriendChatClient.refresh(settings.friendFirebaseApiKey, settings.friendRefreshToken) }
            if (refreshed.value != null) {
                session = refreshed.value
                saveSettings(refreshed.value)
                status = "Аккаунт восстановлен."
            } else status = "Нужно войти в аккаунт Firebase ещё раз: ${refreshed.error}"
        }
    }

    LaunchedEffect(session?.idToken, roomCode, databaseUrl) {
        val active = session
        if (active != null && roomCode.length == 10 && databaseUrl.isNotBlank()) {
            while (true) {
                val result = withContext(Dispatchers.IO) { FriendChatClient.readMessages(databaseUrl, roomCode, active) }
                result.value?.let { messages = it }
                if (result.error != null && result.error.contains("401")) {
                    val refreshed = withContext(Dispatchers.IO) { FriendChatClient.refresh(apiKey, active.refreshToken) }
                    if (refreshed.value != null) session = refreshed.value else status = "Сеанс истёк. Войди снова."
                } else if (result.error != null && messages.isEmpty()) status = result.error
                delay(4_000)
            }
        }
    }

    fun authenticate(create: Boolean) {
        busy = true
        status = if (create) "Создаю аккаунт…" else "Вхожу…"
        scope.launch {
            val result = withContext(Dispatchers.IO) { FriendChatClient.signIn(apiKey, email, password, create) }
            val signed = result.value
            if (signed != null) {
                session = signed
                saveSettings(signed)
                password = ""
                status = if (create) "Аккаунт создан и подключён." else "Вход выполнен."
            } else status = result.error
            busy = false
        }
    }

    fun joinRoom(code: String) {
        val active = session
        if (active == null) { status = "Сначала войди в Firebase."; return }
        if (databaseUrl.isBlank()) { status = "Добавь URL Realtime Database."; return }
        busy = true
        status = "Подключаю комнату…"
        scope.launch {
            val result = withContext(Dispatchers.IO) { FriendChatClient.joinRoom(databaseUrl, code, active, displayName) }
            if (result.ok) {
                roomCode = code.uppercase()
                saveSettings(active, roomCode)
                status = "Ты в комнате $roomCode. Передай этот код другу."
                messages = emptyList()
            } else status = result.error
            busy = false
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = {
            TopAppBar(
                modifier = Modifier.statusBarsPadding(),
                title = { Text("Verity и друзья", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Назад") } }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).navigationBarsPadding().padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Подключение Firebase", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Каждый друг входит в свой аккаунт, затем оба вводят один код комнаты. Не публикуй код комнаты и не отправляй его незнакомым людям.", style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(apiKey, { apiKey = it }, label = { Text("Firebase Web API Key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(databaseUrl, { databaseUrl = it }, label = { Text("Realtime Database URL") }, placeholder = { Text("https://…firebasedatabase.app") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(displayName, { displayName = it.take(28) }, label = { Text("Твоё имя в комнате") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(email, { email = it }, label = { Text("Email аккаунта") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(password, { password = it }, label = { Text("Пароль") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { authenticate(false) }, enabled = !busy && apiKey.isNotBlank() && email.isNotBlank() && password.isNotBlank(), modifier = Modifier.weight(1f)) { Text("Войти") }
                            OutlinedButton(onClick = { authenticate(true) }, enabled = !busy && apiKey.isNotBlank() && email.isNotBlank() && password.isNotBlank(), modifier = Modifier.weight(1f)) { Text("Регистрация") }
                        }
                        Text("Пароль не сохраняется в Verity: он отправляется Firebase только при входе. Токен обновления хранится зашифрованно в Android Keystore.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            item {
                Card {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Комната друзей", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        OutlinedTextField(roomCode, { roomCode = it.uppercase().filter(Char::isLetterOrDigit).take(10) }, label = { Text("Код комнаты из 10 символов") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { joinRoom(roomCode) }, enabled = !busy && session != null && roomCode.length == 10, modifier = Modifier.weight(1f)) { Text("Подключиться") }
                            OutlinedButton(onClick = { roomCode = FriendChatClient.newRoomCode(); joinRoom(roomCode) }, enabled = !busy && session != null, modifier = Modifier.weight(1f)) { Text("Создать код") }
                        }
                        if (roomCode.length == 10 && session != null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Код: $roomCode", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                IconButton(onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Код комнаты Verity", roomCode))
                                    status = "Код скопирован."
                                }) { Icon(Icons.Rounded.ContentCopy, "Скопировать код") }
                                IconButton(onClick = {
                                    context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "Давай общаться в Verity! Код комнаты: $roomCode") }, "Отправить код"))
                                }) { Icon(Icons.Rounded.Share, "Поделиться кодом") }
                            }
                        }
                    }
                }
            }
            if (status != null) item { Text(status.orEmpty(), color = if (status!!.contains("ошиб") || status!!.contains("Не удалось") || status!!.contains("Firebase отклонил")) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall) }
            if (session != null && roomCode.length == 10) {
                item { Text("Сообщения комнаты", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                items(messages, key = { it.id }) { message ->
                    val isMine = message.senderUid == session?.uid
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = if (isMine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(if (isMine) "Ты" else message.senderName, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            if (message.text.isNotBlank()) Text(message.text, style = MaterialTheme.typography.bodyMedium)
                            if (message.imageBase64.isNotBlank()) {
                                val bitmap = remember(message.id) {
                                    runCatching { val bytes = Base64.decode(message.imageBase64, Base64.DEFAULT); BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap() }.getOrNull()
                                }
                                if (bitmap != null) Image(bitmap, "Изображение от ${message.senderName}", Modifier.fillMaxWidth().heightIn(max = 280.dp), contentScale = androidx.compose.ui.layout.ContentScale.Fit)
                                TextButton(onClick = { imageToSave = message.imageBase64; saveImageLauncher.launch("verity_friend_${message.sentAt}.jpg") }) { Text("Сохранить изображение") }
                            }
                            Text(DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(message.sentAt)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (message.text.isNotBlank()) TextButton(onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("Сообщение Verity", message.text))
                                status = "Текст скопирован."
                            }) { Text("Копировать текст") }
                        }
                    }
                }
                item {
                    OutlinedTextField(draft, { draft = it.take(4000) }, label = { Text("Сообщение другу") }, minLines = 2, maxLines = 5, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { pickImageLauncher.launch("image/*") }, enabled = !busy, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Rounded.AddPhotoAlternate, null); Spacer(Modifier.width(6.dp)); Text("Фото")
                        }
                        Button(onClick = {
                            val active = session ?: return@Button
                            val body = draft.trim()
                            if (body.isNotBlank()) {
                                busy = true
                                scope.launch {
                                    val result = withContext(Dispatchers.IO) { FriendChatClient.sendText(databaseUrl, roomCode, active, displayName, body) }
                                    if (result.ok) draft = ""
                                    status = result.error ?: "Сообщение отправлено."
                                    busy = false
                                    val latest = withContext(Dispatchers.IO) { FriendChatClient.readMessages(databaseUrl, roomCode, active) }
                                    latest.value?.let { messages = it }
                                }
                            }
                        }, enabled = !busy && draft.isNotBlank(), modifier = Modifier.weight(1f)) {
                            Icon(Icons.AutoMirrored.Rounded.Send, null); Spacer(Modifier.width(6.dp)); Text("Отправить")
                        }
                    }
                }
            }
        }
    }
}

private fun compressImage(context: Context, uri: android.net.Uri): String? = runCatching {
    val source = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return null
    val maxSide = 640
    val scale = minOf(1f, maxSide.toFloat() / maxOf(source.width, source.height))
    val width = (source.width * scale).toInt().coerceAtLeast(1)
    val height = (source.height * scale).toInt().coerceAtLeast(1)
    val scaled = if (width == source.width && height == source.height) source else Bitmap.createScaledBitmap(source, width, height, true)
    val output = ByteArrayOutputStream()
    scaled.compress(Bitmap.CompressFormat.JPEG, 68, output)
    if (scaled !== source) scaled.recycle()
    source.recycle()
    val bytes = output.toByteArray()
    require(bytes.size <= 380_000) { "Фото слишком большое после сжатия. Выбери другое." }
    Base64.encodeToString(bytes, Base64.NO_WRAP)
}.getOrNull()
