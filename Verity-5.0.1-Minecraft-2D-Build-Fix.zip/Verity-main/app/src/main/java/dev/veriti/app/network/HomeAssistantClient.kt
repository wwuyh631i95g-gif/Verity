package dev.veriti.app.network

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Small, explicit Home Assistant REST client. It never guesses a device or service. */
object HomeAssistantClient {
    data class Result(val ok: Boolean, val message: String)

    private fun normalizedBase(raw: String): String {
        val value = raw.trim().trimEnd('/')
        require(value.startsWith("https://", true)) {
            "Для безопасного подключения укажи HTTPS-адрес Home Assistant (например, адрес Home Assistant Cloud или HTTPS-прокси)."
        }
        val url = URL(value)
        require(url.host.isNotBlank() && url.userInfo == null) { "Адрес сервера выглядит неверно." }
        return value
    }

    private fun open(rawUrl: String, token: String, method: String, body: String? = null): Result {
        val connection = URL(rawUrl).openConnection() as HttpURLConnection
        return try {
            connection.requestMethod = method
            connection.connectTimeout = 8_000
            connection.readTimeout = 12_000
            connection.setRequestProperty("Authorization", "Bearer ${token.trim()}")
            connection.setRequestProperty("Accept", "application/json")
            if (body != null) {
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                connection.outputStream.bufferedWriter(Charsets.UTF_8).use { it.write(body) }
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code in 200..299) Result(true, response.take(600).ifBlank { "Запрос выполнен." })
            else Result(false, "Home Assistant ответил HTTP $code: ${response.take(350)}")
        } catch (e: Exception) {
            Result(false, e.message ?: "Не удалось подключиться к Home Assistant.")
        } finally {
            connection.disconnect()
        }
    }

    fun test(baseUrl: String, token: String): Result {
        if (token.isBlank()) return Result(false, "Добавь долгосрочный токен доступа Home Assistant.")
        val base = runCatching { normalizedBase(baseUrl) }.getOrElse { return Result(false, it.message ?: "Неверный адрес") }
        val result = open("$base/api/", token, "GET")
        return if (result.ok) Result(true, "Связь установлена. Home Assistant ответил: ${result.message.take(220)}") else result
    }

    fun call(baseUrl: String, token: String, entityId: String, domain: String, service: String): Result {
        if (token.isBlank()) return Result(false, "Сначала сохрани токен Home Assistant.")
        if (!Regex("^[a-z_]+\\.[a-z0-9_]+$").matches(entityId.trim())) return Result(false, "Укажи entity_id, например light.living_room.")
        val allowed = mapOf(
            "light" to setOf("turn_on", "turn_off"),
            "switch" to setOf("turn_on", "turn_off"),
            "fan" to setOf("turn_on", "turn_off"),
            "cover" to setOf("open_cover", "close_cover")
        )
        if (allowed[domain]?.contains(service) != true || entityId.substringBefore('.') != domain) {
            return Result(false, "Эта команда не разрешена. Поддерживаются свет, выключатели, вентиляторы и шторы.")
        }
        val base = runCatching { normalizedBase(baseUrl) }.getOrElse { return Result(false, it.message ?: "Неверный адрес") }
        val body = JSONObject().put("entity_id", entityId.trim()).toString()
        return open("$base/api/services/$domain/$service", token, "POST", body).let {
            if (it.ok) Result(true, "Команда $service отправлена для $entityId.") else it
        }
    }
}
