package dev.veriti.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class ChatStore(context: Context) {
    private val prefs = context.getSharedPreferences("veriti_data", Context.MODE_PRIVATE)

    fun loadChats(): List<Chat> = runCatching {
        val array = JSONArray(prefs.getString("chats", "[]"))
        List(array.length()) { i ->
            val json = array.getJSONObject(i)
            val messagesJson = json.getJSONArray("messages")
            Chat(
                id = json.getLong("id"),
                title = json.getString("title"),
                updatedAt = json.getLong("updatedAt"),
                messages = List(messagesJson.length()) { j ->
                    val message = messagesJson.getJSONObject(j)
                    Message(
                        id = message.getLong("id"),
                        role = message.getString("role"),
                        content = message.getString("content"),
                        mood = message.optString("mood").takeIf { it.isNotBlank() },
                        videoUri = message.optString("videoUri").takeIf { it.isNotBlank() },
                        attachments = message.optJSONArray("attachments")?.let { attachments ->
                            List(attachments.length()) { k ->
                                val attachment = attachments.getJSONObject(k)
                                FileAttachment(
                                    name = attachment.getString("name"),
                                    mimeType = attachment.optString("mimeType", "application/octet-stream"),
                                    content = attachment.optString("content"),
                                    isImage = attachment.optBoolean("isImage", false)
                                )
                            }
                        }.orEmpty(),
                        createdAt = message.getLong("createdAt")
                    )
                }
            )
        }.sortedByDescending { it.updatedAt }
    }.getOrDefault(emptyList())

    fun saveChats(chats: List<Chat>) {
        val array = JSONArray()
        chats.forEach { chat ->
            val messages = JSONArray()
            chat.messages.forEach { message ->
                messages.put(JSONObject().apply {
                    put("id", message.id); put("role", message.role)
                    put("content", message.content); put("createdAt", message.createdAt)
                    message.mood?.let { put("mood", it) }
                    message.videoUri?.let { put("videoUri", it) }
                    put("attachments", JSONArray().apply {
                        message.attachments.forEach { attachment ->
                            put(JSONObject().apply {
                                put("name", attachment.name)
                                put("mimeType", attachment.mimeType)
                                put("content", attachment.content)
                                put("isImage", attachment.isImage)
                            })
                        }
                    })
                })
            }
            array.put(JSONObject().apply {
                put("id", chat.id); put("title", chat.title)
                put("updatedAt", chat.updatedAt); put("messages", messages)
            })
        }
        prefs.edit().putString("chats", array.toString()).apply()
    }

    fun loadSettings(): AppSettings = AppSettings(
        providerName = prefs.getString("provider", "OpenAI") ?: "OpenAI",
        baseUrl = prefs.getString("baseUrl", "https://api.openai.com/v1") ?: "https://api.openai.com/v1",
        apiKey = prefs.getString("apiKey", "") ?: "",
        model = prefs.getString("model", "gpt-4.1-mini") ?: "gpt-4.1-mini",
        language = prefs.getString("language", "ru") ?: "ru",
        systemPrompt = prefs.getString("systemPrompt", DEFAULT_SYSTEM_PROMPT) ?: DEFAULT_SYSTEM_PROMPT,
        uiStyle = prefs.getString("uiStyle", "material") ?: "material",
        uiAccent = prefs.getString("uiAccent", "violet") ?: "violet",
        verityPlus = prefs.getBoolean("verityPlus", false),
        physicsStyle = prefs.getString("physicsStyle", "classic") ?: "classic",
        voiceStyle = prefs.getString("voiceStyle", "off") ?: "off",
        customCostumeUri = prefs.getString("customCostumeUri", "") ?: "",
        overlaySizeDp = prefs.getInt("overlaySizeDp", 96).coerceIn(56, 180),
        overlayCharacterCount = prefs.getInt("overlayCharacterCount", 1).coerceIn(1, 5),
        customAvatarUri = prefs.getString("customAvatarUri", "") ?: "",
        selectedCharacterAsset = prefs.getString("selectedCharacterAsset", "") ?: "",
        additionalCharacterAssets = prefs.getString("additionalCharacterAssets", "[]") ?: "[]",
        screenImageAnalysisEnabled = prefs.getBoolean("screenImageAnalysisEnabled", false),
        homeAssistantUrl = prefs.getString("homeAssistantUrl", "") ?: "",
        homeAssistantToken = decryptSecret(prefs.getString("homeAssistantTokenEnc", "") ?: "") ?: "",
        homeAssistantEntityId = prefs.getString("homeAssistantEntityId", "") ?: "",
        homeAssistantLightEntityId = prefs.getString("homeAssistantLightEntityId", "") ?: "",
        homeAssistantCoverEntityId = prefs.getString("homeAssistantCoverEntityId", "") ?: "",
        homeAssistantSwitchEntityId = prefs.getString("homeAssistantSwitchEntityId", "") ?: "",
        friendFirebaseApiKey = prefs.getString("friendFirebaseApiKey", "") ?: "",
        friendDatabaseUrl = prefs.getString("friendDatabaseUrl", "") ?: "",
        friendRefreshToken = decryptSecret(prefs.getString("friendRefreshTokenEnc", "") ?: "") ?: "",
        friendUid = prefs.getString("friendUid", "") ?: "",
        friendRoomCode = prefs.getString("friendRoomCode", "") ?: "",
        friendDisplayName = prefs.getString("friendDisplayName", "Друг Verity") ?: "Друг Verity",
        overlayControlsVisible = prefs.getBoolean("overlayControlsVisible", true),
        overlayChatButtonVisible = prefs.getBoolean("overlayChatButtonVisible", true),
        overlayHideButtonVisible = prefs.getBoolean("overlayHideButtonVisible", true),
        showOnLockScreen = prefs.getBoolean("showOnLockScreen", true),
        arenaSource = prefs.getString("arenaSource", prefs.getString("wallpaperSource", "soccer")) ?: "soccer",
        arenaImageUri = prefs.getString("arenaImageUri", prefs.getString("wallpaperImageUri", "")) ?: "",
        skinStyle = when (val savedSkin = prefs.getString("skinStyle", "verity") ?: "verity") {
            "classic", "yellow" -> "verity"
            "obesity" -> "abesity"
            "blue", "foxy_blue" -> "foxy"
            else -> savedSkin
        },
        customSkinSheetUri = prefs.getString("customSkinSheetUri", "") ?: "",
        secondarySkinStyle = prefs.getString("secondarySkinStyle", "none") ?: "none",
        voiceClickEnabled = prefs.getBoolean("voiceClickEnabled", true),
        developerMode = prefs.getBoolean("developerMode", false),
        mysteryEnabled = prefs.getBoolean("mysteryEnabled", false),
        mysteryStartedAt = if (prefs.getInt("mysteryStoryVersion", 0) >= 2) prefs.getLong("mysteryStartedAt", 0L) else 0L,
        mysteryDelayHours = prefs.getInt("mysteryDelayHours", 72).coerceIn(1, 168),
        mysteryEvent = if (prefs.getInt("mysteryStoryVersion", 0) >= 3) prefs.getInt("mysteryEvent", 0).coerceIn(0, 2) else 0,
        mysteryResolved = if (prefs.getInt("mysteryStoryVersion", 0) >= 2) prefs.getBoolean("mysteryResolved", false) else false,
        mysteryStoryVersion = 3
    )

    fun saveSettings(value: AppSettings) {
        val editor = prefs.edit()
        editor
            .putString("provider", value.providerName)
            .putString("baseUrl", value.baseUrl)
            .putString("apiKey", value.apiKey)
            .putString("model", value.model)
            .putString("language", value.language)
            .putString("systemPrompt", value.systemPrompt)
            .putString("uiStyle", value.uiStyle)
            .putString("uiAccent", value.uiAccent)
            .putBoolean("verityPlus", value.verityPlus)
            .putString("physicsStyle", value.physicsStyle)
            .putString("voiceStyle", value.voiceStyle)
            .putString("customCostumeUri", value.customCostumeUri)
            .putInt("overlaySizeDp", value.overlaySizeDp.coerceIn(56, 180))
            .putInt("overlayCharacterCount", value.overlayCharacterCount.coerceIn(1, 5))
            .putString("customAvatarUri", value.customAvatarUri)
            .putString("selectedCharacterAsset", value.selectedCharacterAsset)
            .putString("additionalCharacterAssets", value.additionalCharacterAssets)
            .putBoolean("screenImageAnalysisEnabled", value.screenImageAnalysisEnabled)
            .putString("homeAssistantUrl", value.homeAssistantUrl)
            .putString("homeAssistantTokenEnc", encryptSecret(value.homeAssistantToken))
            .remove("homeAssistantToken")
            .putString("homeAssistantEntityId", value.homeAssistantEntityId)
            .putString("homeAssistantLightEntityId", value.homeAssistantLightEntityId)
            .putString("homeAssistantCoverEntityId", value.homeAssistantCoverEntityId)
            .putString("homeAssistantSwitchEntityId", value.homeAssistantSwitchEntityId)
            .putString("friendFirebaseApiKey", value.friendFirebaseApiKey)
            .putString("friendDatabaseUrl", value.friendDatabaseUrl)
            .putString("friendRefreshTokenEnc", encryptSecret(value.friendRefreshToken))
            .putString("friendUid", value.friendUid)
            .putString("friendRoomCode", value.friendRoomCode)
            .putString("friendDisplayName", value.friendDisplayName)
            .putBoolean("overlayControlsVisible", value.overlayControlsVisible)
            .putBoolean("overlayChatButtonVisible", value.overlayChatButtonVisible)
            .putBoolean("overlayHideButtonVisible", value.overlayHideButtonVisible)
            .putBoolean("showOnLockScreen", value.showOnLockScreen)
            .putString("arenaSource", value.arenaSource)
            .putString("arenaImageUri", value.arenaImageUri)
            .putString("skinStyle", value.skinStyle)
            .putString("customSkinSheetUri", value.customSkinSheetUri)
            .putString("secondarySkinStyle", value.secondarySkinStyle)
            .putBoolean("voiceClickEnabled", value.voiceClickEnabled)
            .putBoolean("developerMode", value.developerMode)
            .putBoolean("mysteryEnabled", value.mysteryEnabled)
            .putLong("mysteryStartedAt", value.mysteryStartedAt)
            .putInt("mysteryDelayHours", value.mysteryDelayHours.coerceIn(1, 168))
            .putInt("mysteryEvent", value.mysteryEvent.coerceIn(0, 2))
            .putBoolean("mysteryResolved", value.mysteryResolved)
            .putInt("mysteryStoryVersion", value.mysteryStoryVersion)
        editor.apply()
    }

    private fun encryptSecret(value: String): String {
        if (value.isBlank()) return ""
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(cipher.iv + encrypted, Base64.NO_WRAP)
    }

    private fun decryptSecret(value: String): String? {
        if (value.isBlank()) return ""
        return runCatching {
            val packed = Base64.decode(value, Base64.NO_WRAP)
            require(packed.size > 12)
            val iv = packed.copyOfRange(0, 12)
            val encrypted = packed.copyOfRange(12, packed.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(encrypted), Charsets.UTF_8)
        }.getOrNull()
    }

    private fun getOrCreateSecretKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val alias = "verity_home_assistant_token"
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }
}
