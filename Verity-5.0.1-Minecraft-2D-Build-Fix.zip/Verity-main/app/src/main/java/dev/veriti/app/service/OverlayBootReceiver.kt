package dev.veriti.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.content.ContextCompat

class OverlayBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val enabled = context.getSharedPreferences("veriti_data", Context.MODE_PRIVATE)
            .getBoolean("overlay_enabled", false)
        if (enabled && Settings.canDrawOverlays(context)) {
            ContextCompat.startForegroundService(context, Intent(context, FloatingAssistantService::class.java))
        }
    }
}
