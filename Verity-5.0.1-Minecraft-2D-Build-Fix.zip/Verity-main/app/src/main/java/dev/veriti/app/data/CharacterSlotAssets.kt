package dev.veriti.app.data

import dev.veriti.app.data.AppSettings
import org.json.JSONArray

/** Per-window character selection. Slot 0 is the original main selection; slots 1–4 are stored separately. */
object CharacterSlotAssets {
    fun get(settings: AppSettings, slot: Int): String {
        if (slot <= 0) return settings.selectedCharacterAsset
        return runCatching { JSONArray(settings.additionalCharacterAssets).optString(slot - 1, "") }.getOrDefault("")
    }

    fun set(settings: AppSettings, slot: Int, asset: String): AppSettings {
        if (slot <= 0) return settings.copy(selectedCharacterAsset = asset)
        val current = runCatching { JSONArray(settings.additionalCharacterAssets) }.getOrElse { JSONArray() }
        val updated = JSONArray()
        for (index in 0 until 4) {
            updated.put(if (index == slot - 1) asset else current.optString(index, ""))
        }
        return settings.copy(additionalCharacterAssets = updated.toString())
    }
}
