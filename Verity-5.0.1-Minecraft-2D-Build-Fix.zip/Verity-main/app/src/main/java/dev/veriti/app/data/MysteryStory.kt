package dev.veriti.app.data

data class MysteryReply(
    val text: String,
    val mood: String,
    val settings: AppSettings
)

object MysteryStory {
    const val THREE_DAYS_MS = 3L * 24L * 60L * 60L * 1000L
    const val FOUR_DAYS_MS = 4L * 24L * 60L * 60L * 1000L
    private const val HOUR_MS = 60L * 60L * 1000L

    fun delayFor(settings: AppSettings): Long = settings.mysteryDelayHours.coerceIn(1, 168) * HOUR_MS
    private fun delayMs(settings: AppSettings): Long = delayFor(settings)

    private val waitingLine: (Int) -> String = { hours -> "В моём страшном режиме ещё $hours ч. до следующего события." }
    private val eerieLines = listOf(
        "Кажется, картинка на секунду дрогнула… Наверное, показалось.",
        "Тише. Я услышал странный электронный звук.",
        "На секунду всё стало слишком тихим. Ладно, продолжаем."
    )

    fun isEnabled(settings: AppSettings): Boolean = settings.mysteryEnabled

    fun withEventSelected(settings: AppSettings, now: Long = System.currentTimeMillis()): AppSettings {
        if (!isEnabled(settings) || settings.mysteryStartedAt <= 0L || now - settings.mysteryStartedAt < delayMs(settings)) {
            return settings
        }
        if (settings.mysteryEvent in 1..2) return settings
        val selected = kotlin.random.Random(settings.mysteryStartedAt).nextInt(1, 3)
        return settings.copy(mysteryEvent = selected)
    }

    fun isScary(settings: AppSettings, now: Long = System.currentTimeMillis()): Boolean =
        withEventSelected(settings, now).let { selected ->
            isEnabled(selected) && selected.mysteryEvent == 2 &&
                selected.mysteryStartedAt > 0L && now - selected.mysteryStartedAt >= delayMs(selected)
        }

    fun shouldShakeText(settings: AppSettings, now: Long = System.currentTimeMillis()): Boolean = isScary(settings, now)

    /** Horror effects must never hide or disable the user's floating assistant. */
    fun shouldHideOverlay(settings: AppSettings, now: Long = System.currentTimeMillis()): Boolean = false

    fun startAfterAnswer(settings: AppSettings, now: Long = System.currentTimeMillis()): MysteryReply? {
        if (!isEnabled(settings) || settings.mysteryStartedAt != 0L) return null
        return MysteryReply(waitingLine(settings.mysteryDelayHours), "normal", settings.copy(mysteryStartedAt = now, mysteryEvent = 0, mysteryResolved = false))
    }

    fun decorateAnswer(
        settings: AppSettings,
        text: String,
        mood: String,
        now: Long = System.currentTimeMillis()
    ): MysteryReply {
        if (!isEnabled(settings)) return MysteryReply(text, mood, settings)
        var updated = if (settings.mysteryStartedAt == 0L) {
            settings.copy(mysteryStartedAt = now, mysteryEvent = 0, mysteryResolved = false)
        } else settings
        updated = withEventSelected(updated, now)
        val elapsed = now - updated.mysteryStartedAt
        val suffix = when {
            elapsed < delayMs(updated) -> waitingLine(((delayMs(updated) - elapsed) / HOUR_MS).toInt().coerceAtLeast(1))
            updated.mysteryEvent == 1 -> {
                val index = ((now / 60_000L) % eerieLines.size).toInt()
                eerieLines[index]
            }
            else -> null
        }
        val decorated = if (suffix == null || text.trimEnd().endsWith(suffix)) text else "${text.trimEnd()}\n\n$suffix"
        return MysteryReply(decorated, mood, updated)
    }

    fun reply(settings: AppSettings, input: String, now: Long = System.currentTimeMillis()): MysteryReply? {
        val normalized = input.lowercase().replace(Regex("[^а-яёa-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ").trim()
        if (!isEnabled(settings) || settings.mysteryStartedAt == 0L) return null
        val selected = withEventSelected(settings, now)
        if (selected.mysteryEvent == 1 && now - selected.mysteryStartedAt >= delayMs(selected) &&
            (normalized.contains("что с тобой") || normalized.contains("что случилось"))) {
            return MysteryReply("Ничего! Просто в режиме истории иногда происходят странные визуальные эффекты.", "angry", selected)
        }
        return null
    }
}
