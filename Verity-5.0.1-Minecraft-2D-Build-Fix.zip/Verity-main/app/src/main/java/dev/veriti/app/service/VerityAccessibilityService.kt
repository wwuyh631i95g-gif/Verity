package dev.veriti.app.service

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.graphics.Bitmap
import android.os.Build
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class VerityAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() {
        activeService = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (activeService === this) activeService = null
        super.onDestroy()
    }

    private fun clickVisibleNode(label: String): ClickResult {
        val normalized = label.trim()
        if (normalized.isBlank()) return ClickResult.NOT_FOUND
        if (blockedWords.any { normalized.contains(it, ignoreCase = true) }) return ClickResult.BLOCKED
        val root = rootInActiveWindow ?: return ClickResult.NOT_FOUND
        val candidates = root.findAccessibilityNodeInfosByText(normalized)
        val exact = candidates.firstOrNull { node ->
            node.isVisibleToUser && node.isEnabled && !node.isPassword && (
                node.text?.toString()?.trim()?.equals(normalized, ignoreCase = true) == true ||
                    node.contentDescription?.toString()?.trim()?.equals(normalized, ignoreCase = true) == true
                )
        } ?: return ClickResult.NOT_FOUND

        // Only click the exact labelled node or one of its own clickable parents.
        // Never guess based on a nearby button: that can activate the wrong control.
        var target: AccessibilityNodeInfo? = exact
        repeat(7) {
            val node = target ?: return@repeat
            val labelText = listOf(node.text, node.contentDescription).joinToString(" ") { it?.toString().orEmpty() }
            if (blockedWords.any { labelText.contains(it, ignoreCase = true) }) return ClickResult.BLOCKED
            if (node.isVisibleToUser && node.isEnabled && node.isClickable) {
                return if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) ClickResult.CLICKED else ClickResult.NOT_FOUND
            }
            target = node.parent
        }
        return ClickResult.NOT_FOUND
    }

    private fun collectVisibleLabels(node: AccessibilityNodeInfo, output: LinkedHashSet<String>) {
        if (!node.isVisibleToUser || node.isPassword) return
        // Do not read text typed into input fields. We only collect visible labels and button names.
        if (!node.isEditable) {
            node.text?.toString()?.trim()?.takeIf { it.length in 2..180 }?.let(output::add)
            node.contentDescription?.toString()?.trim()?.takeIf { it.length in 2..180 }?.let(output::add)
        }
        for (index in 0 until node.childCount) {
            if (output.size >= 100) break
            node.getChild(index)?.let { child ->
                collectVisibleLabels(child, output)
                child.recycle()
            }
        }
    }


    private fun captureScreen(callback: (Bitmap?, String?) -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            callback(null, "Захват экрана доступен начиная с Android 11.")
            return
        }
        runCatching {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                    val buffer = result.hardwareBuffer
                    val bitmap = try {
                        runCatching {
                            val hardwareBitmap = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                            hardwareBitmap?.copy(Bitmap.Config.ARGB_8888, false)
                        }.getOrNull()
                    } finally {
                        buffer.close()
                    }
                    callback(bitmap, if (bitmap == null) "Android не вернул изображение экрана." else null)
                }

                override fun onFailure(errorCode: Int) {
                    callback(null, "Android запретил снимок этого экрана (код $errorCode). Возможно, приложение защищает содержимое.")
                }
            })
        }.onFailure { callback(null, it.message ?: "Не удалось сделать снимок экрана.") }
    }

    private fun readScreenLabels(): String {
        val root = rootInActiveWindow ?: return ""
        val labels = linkedSetOf<String>()
        collectVisibleLabels(root, labels)
        root.recycle()
        return labels.take(70).joinToString("\n").take(5_000)
    }

    enum class ClickResult { CLICKED, NOT_FOUND, BLOCKED, DISABLED }

    companion object {
        @Volatile private var activeService: VerityAccessibilityService? = null
        private val blockedWords = listOf(
            "купить", "оплатить", "перевести", "удалить", "разрешить", "установить",
            "подтвердить", "подписать", "отправить деньги", "оплатить заказ", "удалить аккаунт",
            "сбросить настройки", "factory reset", "purchase", "pay now", "delete account", "confirm payment"
        )

        fun clickByText(label: String): ClickResult =
            activeService?.clickVisibleNode(label) ?: ClickResult.DISABLED

        fun readVisibleScreen(): String = activeService?.readScreenLabels().orEmpty()

        fun captureCurrentScreen(callback: (Bitmap?, String?) -> Unit) {
            val service = activeService
            if (service == null) {
                callback(null, "Сначала включи службу специальных возможностей Verity.")
                return
            }
            service.captureScreen(callback)
        }
    }
}
