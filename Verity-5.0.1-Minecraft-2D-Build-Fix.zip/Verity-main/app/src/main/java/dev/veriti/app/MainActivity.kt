package dev.veriti.app

import android.Manifest
import android.app.DownloadManager
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.provider.OpenableColumns
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarColors
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material3.DrawerValue
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import dev.veriti.app.data.AppSettings
import dev.veriti.app.ads.AdMobController
import dev.veriti.app.data.AssistantBridge
import dev.veriti.app.data.Chat
import dev.veriti.app.data.CharacterSlotAssets
import dev.veriti.app.data.CustomCharacterLibrary
import dev.veriti.app.data.Message
import dev.veriti.app.data.MysteryStory
import dev.veriti.app.data.FileAttachment
import dev.veriti.app.data.DEFAULT_SYSTEM_PROMPT
import dev.veriti.app.data.Provider
import dev.veriti.app.data.Providers
import dev.veriti.app.data.SkinSheet
import dev.veriti.app.data.SkinStroke
import dev.veriti.app.game.LanGameSession
import dev.veriti.app.service.FloatingAssistantService
import dev.veriti.app.service.GameOverlayService
import dev.veriti.app.service.VerityAccessibilityService
import dev.veriti.app.ui.ChatViewModel
import dev.veriti.app.network.ReleaseUpdate
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import zone.ien.hig.adaptive.AdaptiveButton
import zone.ien.hig.adaptive.AdaptiveNavigationBar
import zone.ien.hig.adaptive.AdaptiveNavigationBarItem
import zone.ien.hig.adaptive.AdaptiveScaffold
import zone.ien.hig.adaptive.AdaptiveSlider
import zone.ien.hig.adaptive.AdaptiveSwitch
import zone.ien.hig.adaptive.AdaptiveTextButton
import zone.ien.hig.adaptive.AdaptiveTheme
import zone.ien.hig.adaptive.AdaptiveTonalButton
import zone.ien.hig.adaptive.AdaptiveTopAppBar
import zone.ien.hig.adaptive.CupertinoThemeSpec
import zone.ien.hig.adaptive.ExperimentalAdaptiveApi
import zone.ien.hig.adaptive.MaterialThemeSpec
import zone.ien.hig.adaptive.Theme
import zone.ien.hig.theme.darkColorScheme as higDarkColorScheme
import zone.ien.hig.theme.lightColorScheme as higLightColorScheme
import kotlin.math.hypot
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AdMobController.requestConsentAndInitialize(this)
        setContent { VerityRoot() }
    }
}

private val VeritiLight = lightColorScheme(
    primary = Color(0xFF65558F),
    secondary = Color(0xFF625B71),
    tertiary = Color(0xFF7D5260),
    background = Color(0xFFFFF9FF),
    surface = Color(0xFFFFF9FF),
    surfaceVariant = Color(0xFFE8E0F0)
)

private val VeritiDark = darkColorScheme(
    primary = Color(0xFFD0BCFF),
    secondary = Color(0xFFCCC2DC),
    tertiary = Color(0xFFEFB8C8)
)

// Store only a one-way fingerprint in source control; never publish the activation key itself.
private const val VERITY_PLUS_KEY_SHA256 = "557b7a0519ec7b4d461c9d7df05bea61ca6c885fabcfceaaf183936d6c5eebc6"

private fun activationKeyMatches(value: String): Boolean {
    val digest = MessageDigest.getInstance("SHA-256").digest(value.trim().toByteArray(Charsets.UTF_8))
    val fingerprint = digest.joinToString("") { byte -> "%02x".format(byte.toInt() and 0xff) }
    return fingerprint == VERITY_PLUS_KEY_SHA256
}

private data class AccentPalette(val primary: Color, val secondary: Color, val tertiary: Color)

private fun accentPalette(key: String): AccentPalette = when (key) {
    "blue" -> AccentPalette(Color(0xFF1976D2), Color(0xFF64B5F6), Color(0xFF26A69A))
    "green" -> AccentPalette(Color(0xFF2E7D32), Color(0xFF66BB6A), Color(0xFF80CBC4))
    "orange" -> AccentPalette(Color(0xFFEF6C00), Color(0xFFFFB74D), Color(0xFF8D6E63))
    "pink" -> AccentPalette(Color(0xFFC2185B), Color(0xFFF06292), Color(0xFF8E7CC3))
    "red" -> AccentPalette(Color(0xFFC62828), Color(0xFFEF5350), Color(0xFFFFB74D))
    else -> AccentPalette(Color(0xFF7C4DFF), Color(0xFF9C7BFF), Color(0xFFE57BB6))
}

@OptIn(ExperimentalAdaptiveApi::class)
@Composable
private fun VeritiTheme(style: String, accent: String, content: @Composable () -> Unit) {
    val context = LocalContext.current
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    val materialScheme = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && style == "material") {
        if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else if (style == "sf") {
        if (dark) darkColorScheme(primary = Color(0xFF0A84FF), background = Color(0xFF000000), surface = Color(0xFF1C1C1E), surfaceVariant = Color(0xFF2C2C2E))
        else lightColorScheme(primary = Color(0xFF007AFF), background = Color(0xFFF2F2F7), surface = Color.White, surfaceVariant = Color(0xFFE5E5EA))
    } else if (dark) VeritiDark else VeritiLight
    val accentColors = accentPalette(accent)
    val finalScheme = materialScheme.copy(
        primary = accentColors.primary,
        secondary = accentColors.secondary,
        tertiary = accentColors.tertiary
    )
    val shapes = if (style == "sf") {
        Shapes(extraSmall = RoundedCornerShape(8.dp), small = RoundedCornerShape(12.dp), medium = RoundedCornerShape(16.dp), large = RoundedCornerShape(22.dp), extraLarge = RoundedCornerShape(28.dp))
    } else {
        Shapes(extraSmall = RoundedCornerShape(10.dp), small = RoundedCornerShape(16.dp), medium = RoundedCornerShape(24.dp), large = RoundedCornerShape(32.dp), extraLarge = RoundedCornerShape(44.dp))
    }
    AdaptiveTheme(
        target = if (style == "sf") Theme.Cupertino else Theme.Material3,
        material = MaterialThemeSpec(colorScheme = finalScheme, shapes = shapes),
        cupertino = CupertinoThemeSpec(colorScheme = if (dark) higDarkColorScheme() else higLightColorScheme()),
        content = content
    )
}

private enum class Screen { CHAT, GAME, SETTINGS, PLUS, ABOUT, SKIN_EDITOR, CHARACTERS, APP_BUILDER, HOME_ASSISTANT, FRIENDS, FEATURES }

@Composable
private fun VerityRoot() {
    val context = LocalContext.current
    val preferences = remember { context.getSharedPreferences("veriti_data", android.content.Context.MODE_PRIVATE) }
    var onboardingComplete by rememberSaveable {
        mutableStateOf(preferences.getBoolean("onboarding_complete_v3", false))
    }
    var uiStyle by rememberSaveable {
        mutableStateOf(
            if (preferences.getBoolean("verityPlus", false)) preferences.getString("uiStyle", "material") ?: "material"
            else "material"
        )
    }
    var uiAccent by rememberSaveable { mutableStateOf(preferences.getString("uiAccent", "violet") ?: "violet") }
    VeritiTheme(uiStyle, uiAccent) {
        if (onboardingComplete) {
            VeritiApp(
                onStyleChange = { uiStyle = it },
                onAccentChange = {
                    uiAccent = it
                    preferences.edit().putString("uiAccent", it).apply()
                }
            )
        } else {
            FirstMeetingScreen(onComplete = {
                preferences.edit().putBoolean("onboarding_complete_v3", true).apply()
                onboardingComplete = true
            })
        }
    }
}

@Composable
private fun FirstMeetingScreen(onComplete: () -> Unit) {
    val context = LocalContext.current
    var stage by rememberSaveable { mutableStateOf(0) }
    val whiteFade = remember { Animatable(0f) }
    fun startPetAndFinish() {
        if (Settings.canDrawOverlays(context)) {
            ContextCompat.startForegroundService(context, Intent(context, FloatingAssistantService::class.java))
        }
        onComplete()
    }
    val overlayLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        startPetAndFinish()
    }
    val permissionsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (Settings.canDrawOverlays(context)) {
            startPetAndFinish()
        } else {
            overlayLauncher.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
        }
    }
    LaunchedEffect(Unit) {
        delay(1_400)
        stage = 1
        whiteFade.animateTo(1f, tween(900))
        delay(220)
        whiteFade.animateTo(0f, tween(1_100))
        stage = 2
    }

    Surface(Modifier.fillMaxSize(), color = Color(0xFF0D0B10)) {
        Column(
            Modifier.fillMaxSize().background(Color.White.copy(alpha = whiteFade.value))
                .statusBarsPadding().navigationBarsPadding().padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (stage == 0) {
                Surface(color = Color(0xFF29242E), shape = RoundedCornerShape(22.dp)) {
                    Text("Кажется, кто-то рядом…", color = Color.White, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(20.dp))
                }
            } else if (stage == 1) {
                Spacer(Modifier.size(320.dp))
            } else {
                JumpingVerity()
                Spacer(Modifier.height(24.dp))
                Surface(color = Color(0xFF29242E), shape = RoundedCornerShape(24.dp)) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Наконец-то.", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text(
                            "Можно мне жить поверх экрана и слушать тебя, когда ты нажимаешь на меня? Я смогу отвечать текстом и голосом.",
                            color = Color(0xFFE9DFED),
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
                Spacer(Modifier.height(22.dp))
                Button(
                    onClick = {
                        val permissions = buildList {
                            add(Manifest.permission.RECORD_AUDIO)
                            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
                        }.toTypedArray()
                        permissionsLauncher.launch(permissions)
                    },
                    modifier = Modifier.fillMaxWidth().widthIn(max = 440.dp)
                ) { Text("Разрешить и познакомиться") }
                TextButton(onClick = onComplete) { Text("Не сейчас", color = Color(0xFFD8CBE1)) }
            }
        }
    }
}

@Composable
private fun JumpingVerity() {
    val jump = remember { Animatable(150f) }
    val squash = remember { Animatable(.72f) }
    LaunchedEffect(Unit) {
        jump.animateTo(0f, spring(dampingRatio = .34f, stiffness = 210f))
    }
    LaunchedEffect(Unit) {
        squash.animateTo(1f, spring(dampingRatio = .3f, stiffness = 260f))
    }
    Image(
        painter = painterResource(R.drawable.verity_happy_cutout),
        contentDescription = "Verity",
        contentScale = ContentScale.Fit,
        modifier = Modifier
            .offset(y = jump.value.dp)
            .size(190.dp)
            .scale(scaleX = 2f - squash.value, scaleY = squash.value)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VeritiApp(onStyleChange: (String) -> Unit, onAccentChange: (String) -> Unit, vm: ChatViewModel = viewModel()) {
    val state = vm.state
    AppSpeechEffect(state.settings)
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var screen by rememberSaveable { mutableStateOf(Screen.CHAT) }
    var characterSlotTarget by rememberSaveable { mutableIntStateOf(0) }
    var showProviders by rememberSaveable { mutableStateOf(false) }
    var showGeminiHelp by rememberSaveable { mutableStateOf(false) }
    val voiceText = AssistantBridge.pendingVoiceText
    val newChatRequested = AssistantBridge.pendingNewChat
    val focusComposer = AssistantBridge.focusComposerRequested
    val chatRevision = AssistantBridge.chatRevision

    LaunchedEffect(Unit) { vm.checkForUpdates() }

    LaunchedEffect(voiceText) {
        if (!voiceText.isNullOrBlank()) {
            screen = Screen.CHAT
            vm.send(voiceText)
            AssistantBridge.pendingVoiceText = null
        }
    }
    LaunchedEffect(newChatRequested) {
        if (newChatRequested) {
            vm.newChat()
            screen = Screen.CHAT
            AssistantBridge.pendingNewChat = false
        }
    }
    LaunchedEffect(chatRevision) {
        if (chatRevision > 0L) vm.reloadChats(AssistantBridge.lastOverlayChatId)
    }
    LaunchedEffect(screen, state.settings.baseUrl, state.settings.apiKey) {
        if (screen == Screen.SETTINGS && state.models.isEmpty() && state.settings.apiKey.isNotBlank()) {
            vm.refreshModels(autoSelectNewest = true)
        }
    }
    LaunchedEffect(screen) {
        if (screen == Screen.SETTINGS && state.update == null && !state.isCheckingUpdate) {
            vm.checkForUpdates()
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        bottomBar = {
            if (screen != Screen.ABOUT && screen != Screen.SKIN_EDITOR && screen != Screen.CHARACTERS) {
                AppBottomBar(selected = screen, sfStyle = state.settings.uiStyle == "sf", onSelected = { screen = it })
            }
        }
    ) { outerPadding ->
        ModalNavigationDrawer(
            modifier = Modifier.padding(outerPadding),
            drawerState = drawerState,
            gesturesEnabled = screen == Screen.CHAT,
            drawerContent = {
                HistoryDrawer(
                    chats = state.chats,
                    selectedId = state.currentChat.id,
                    onNew = { vm.newChat(); screen = Screen.CHAT; scope.launch { drawerState.close() } },
                    onOpen = { vm.openChat(it); screen = Screen.CHAT; scope.launch { drawerState.close() } },
                    onDelete = vm::deleteChat
                )
            }
        ) {
            AnimatedContent(targetState = screen, label = "screen transition") { currentScreen ->
            when (currentScreen) {
            Screen.CHAT -> ChatScreen(
                chat = state.currentChat,
                settings = state.settings,
                model = state.settings.model,
                isLoading = state.isLoading,
                error = state.error,
                focusComposer = focusComposer,
                showApiSuggestion = state.settings.apiKey.isBlank(),
                onMenu = { scope.launch { drawerState.open() } },
                onProvider = { showProviders = true },
                onGeminiSuggestion = { showGeminiHelp = true },
                onOpenPlus = { screen = Screen.PLUS },
                onAvatarPicked = { uri ->
                    scope.launch {
                        val imported = withContext(Dispatchers.IO) { SkinSheet.importAvatar(context, uri) }
                        if (imported != null) {
                            vm.updateSettings(state.settings.copy(customAvatarUri = imported, selectedCharacterAsset = ""))
                            if (context.getSharedPreferences("veriti_data", android.content.Context.MODE_PRIVATE).getBoolean("overlay_enabled", false)) {
                                ContextCompat.startForegroundService(context, Intent(context, FloatingAssistantService::class.java).setAction(FloatingAssistantService.ACTION_REFRESH))
                            }
                        }
                    }
                },
                onSend = vm::send,
                onComposerFocused = { AssistantBridge.focusComposerRequested = false },
                onDismissError = vm::clearError,
                sfStyle = state.settings.uiStyle == "sf"
            )
            Screen.GAME -> GameScreen(
                settings = state.settings,
                onSave = vm::updateSettings,
                onOpenPlus = { screen = Screen.PLUS }
            )
            Screen.SETTINGS -> SettingsScreen(
                settings = state.settings,
                models = state.models.map { it.id },
                isLoadingModels = state.isLoadingModels,
                modelError = state.modelError,
                update = state.update,
                isCheckingUpdate = state.isCheckingUpdate,
                updateError = state.updateError,
                onPickProvider = { showProviders = true },
                onRefreshModels = vm::refreshModels,
                onSelectModel = vm::selectModel,
                onCheckUpdate = vm::checkForUpdates,
                onAbout = { screen = Screen.ABOUT },
                onCharacters = { slot -> characterSlotTarget = slot.coerceIn(0, 4); screen = Screen.CHARACTERS },
                onSkinEditor = { screen = Screen.SKIN_EDITOR },
                onAppBuilder = { screen = Screen.APP_BUILDER },
                onHomeAssistant = { screen = Screen.HOME_ASSISTANT },
                onFriends = { screen = Screen.FRIENDS },
                onFeatures = { screen = Screen.FEATURES },
                onSave = vm::updateSettings,
                onAccentChange = onAccentChange
            )
            Screen.PLUS -> PlusScreen(
                settings = state.settings,
                onSave = vm::updateSettings,
                onStyleChange = onStyleChange,
                onOpenSkinEditor = { screen = Screen.SKIN_EDITOR }
            )
            Screen.ABOUT -> AboutScreen(onBack = { screen = Screen.SETTINGS })
            Screen.CHARACTERS -> CharacterCatalogScreen(
                targetSlot = characterSlotTarget,
                onBack = { screen = Screen.SETTINGS },
                onSelectCharacter = { assetPath ->
                    vm.updateSettings(CharacterSlotAssets.set(state.settings, characterSlotTarget, assetPath).copy(customAvatarUri = ""))
                    if (context.getSharedPreferences("veriti_data", android.content.Context.MODE_PRIVATE).getBoolean("overlay_enabled", false)) {
                        ContextCompat.startForegroundService(context, Intent(context, FloatingAssistantService::class.java).setAction(FloatingAssistantService.ACTION_REFRESH))
                    }
                    screen = Screen.SETTINGS
                },
                onDeleteCustomCharacter = { assetPath ->
                    var cleaned = state.settings
                    for (slot in 0 until 5) {
                        if (CharacterSlotAssets.get(cleaned, slot) == assetPath) {
                            cleaned = CharacterSlotAssets.set(cleaned, slot, "")
                        }
                    }
                    vm.updateSettings(cleaned)
                    if (context.getSharedPreferences("veriti_data", android.content.Context.MODE_PRIVATE).getBoolean("overlay_enabled", false)) {
                        ContextCompat.startForegroundService(context, Intent(context, FloatingAssistantService::class.java).setAction(FloatingAssistantService.ACTION_REFRESH))
                    }
                }
            )
            Screen.APP_BUILDER -> AppProjectBuilderScreen(settings = state.settings, onBack = { screen = Screen.SETTINGS })
            Screen.HOME_ASSISTANT -> HomeAssistantScreen(settings = state.settings, onSave = vm::updateSettings, onBack = { screen = Screen.SETTINGS })
            Screen.FRIENDS -> FriendChatScreen(settings = state.settings, onSave = vm::updateSettings, onBack = { screen = Screen.SETTINGS })
            Screen.FEATURES -> FeatureListScreen(onBack = { screen = Screen.SETTINGS })
            Screen.SKIN_EDITOR -> SkinEditorScreen(
                onBack = { screen = Screen.SETTINGS },
                onSave = { uri ->
                    vm.updateSettings(state.settings.copy(skinStyle = "custom", customSkinSheetUri = uri))
                    screen = Screen.SETTINGS
                }
            )
            }
            }
        }
    }

    if (showProviders) {
        ProviderSheet(
            selected = state.settings.providerName,
            verityPlus = state.settings.verityPlus,
            onDismiss = { showProviders = false },
            onSelect = {
                vm.selectProvider(it)
                if (state.settings.apiKey.isNotBlank()) vm.refreshModels(autoSelectNewest = true)
                showProviders = false
            }
        )
    }
    if (showGeminiHelp) {
        GeminiHelpDialog(
            onDismiss = { showGeminiHelp = false },
            onOpenSettings = {
                Providers.all.firstOrNull { it.name == "Google Gemini" }?.let(vm::selectProvider)
                screen = Screen.SETTINGS
                showGeminiHelp = false
            }
        )
    }
}

@Composable
private fun AppSpeechEffect(settings: AppSettings) {
    val context = LocalContext.current
    var ready by remember { mutableStateOf(false) }
    val tts = remember {
        TextToSpeech(context.applicationContext) { status -> ready = status == TextToSpeech.SUCCESS }
    }
    LaunchedEffect(ready) {
        if (ready) tts.language = Locale.forLanguageTag("ru-RU")
    }
    DisposableEffect(settings.verityPlus, settings.voiceStyle, ready) {
        AssistantBridge.onAppAssistantReply = { text, _ ->
            val overlayIsSpeaking = AssistantBridge.onAssistantReply != null
            if (ready && settings.verityPlus && settings.voiceStyle != "off" && !overlayIsSpeaking) {
                val (pitch, rate) = when (settings.voiceStyle) {
                    "bright" -> 1.35f to 1.05f
                    "deep" -> .72f to .9f
                    "fast" -> 1.05f to 1.35f
                    else -> 1f to 1f
                }
                tts.setPitch(pitch)
                tts.setSpeechRate(rate)
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "verity_app_reply")
            }
        }
        onDispose { AssistantBridge.onAppAssistantReply = null }
    }
    DisposableEffect(tts) {
        onDispose {
            tts.stop()
            tts.shutdown()
        }
    }
}

@Composable
private fun HistoryDrawer(
    chats: List<Chat>,
    selectedId: Long,
    onNew: () -> Unit,
    onOpen: (Long) -> Unit,
    onDelete: (Long) -> Unit
) {
    ModalDrawerSheet(modifier = Modifier.width(320.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painterResource(R.drawable.verity_happy_cutout), null,
                Modifier.size(46.dp), contentScale = ContentScale.Fit
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Verity", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
        }
        NavigationDrawerItem(
            label = { Text("Новый чат") },
            selected = false,
            icon = { Icon(Icons.Rounded.Add, null) },
            onClick = onNew,
            modifier = Modifier.padding(horizontal = 12.dp)
        )
        Row(Modifier.padding(start = 28.dp, top = 20.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.History, null, Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("ИСТОРИЯ", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 12.dp)) {
            if (chats.isEmpty()) {
                item { Text("Здесь появятся сохранённые чаты", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
            items(chats, key = { it.id }) { chat ->
                NavigationDrawerItem(
                    label = { Text(chat.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    selected = chat.id == selectedId,
                    badge = {
                        IconButton(onClick = { onDelete(chat.id) }, Modifier.size(34.dp)) {
                            Icon(Icons.Rounded.DeleteOutline, "Удалить", Modifier.size(19.dp))
                        }
                    },
                    onClick = { onOpen(chat.id) }
                )
            }
        }
        Spacer(Modifier.navigationBarsPadding())
    }
}

@OptIn(ExperimentalAdaptiveApi::class)
@Composable
private fun AppBottomBar(selected: Screen, sfStyle: Boolean, onSelected: (Screen) -> Unit) {
    val tabs = listOf(Screen.CHAT, Screen.GAME, Screen.SETTINGS, Screen.PLUS)
    if (sfStyle) {
        val items = listOf(
            Triple(Screen.CHAT, R.drawable.sf_bubble, "Чаты"),
            Triple(Screen.GAME, R.drawable.sf_gamecontroller, "Игра"),
            Triple(Screen.SETTINGS, R.drawable.sf_gear, "Настройки"),
            Triple(Screen.PLUS, R.drawable.sf_star, "Verity+")
        )
        Surface(
            modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 10.dp, vertical = 6.dp),
            color = Color(0xE61C1C1E),
            shape = RoundedCornerShape(28.dp),
            shadowElevation = 14.dp
        ) {
            Row(Modifier.fillMaxWidth().padding(5.dp)) {
                items.forEach { (screen, icon, label) ->
                    val selectedColor by animateColorAsState(
                        if (selected == screen) Color(0x553A3A3C) else Color.Transparent,
                        label = "cupertino tab glass"
                    )
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(22.dp)).background(selectedColor)
                            .clickable { onSelected(screen) }.padding(vertical = 7.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Image(
                            painterResource(icon),
                            contentDescription = label,
                            modifier = Modifier.size(22.dp),
                            colorFilter = ColorFilter.tint(if (selected == screen) Color.White else Color(0xFFAEAEB2))
                        )
                        Text(label, color = if (selected == screen) Color.White else Color(0xFFAEAEB2), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
        return
    }
    AdaptiveNavigationBar(
        selectedTabIndex = { tabs.indexOf(selected).coerceAtLeast(0) },
        onTabSelected = { index -> tabs.getOrNull(index)?.let(onSelected) },
        tabsCount = tabs.size
    ) {
        AdaptiveNavigationBarItem(
            index = 0,
            onClick = { onSelected(Screen.CHAT) },
            icon = { StyleTabIcon(sfStyle, R.drawable.sf_bubble) { Icon(Icons.Rounded.ChatBubbleOutline, null) } },
            label = { Text("Чаты") }
        )
        AdaptiveNavigationBarItem(
            index = 1,
            onClick = { onSelected(Screen.GAME) },
            icon = { StyleTabIcon(sfStyle, R.drawable.sf_gamecontroller) { Icon(Icons.Rounded.AutoAwesome, null) } },
            label = { Text("Игра") }
        )
        AdaptiveNavigationBarItem(
            index = 2,
            onClick = { onSelected(Screen.SETTINGS) },
            icon = { StyleTabIcon(sfStyle, R.drawable.sf_gear) { Icon(Icons.Rounded.Settings, null) } },
            label = { Text("Настройки") }
        )
        AdaptiveNavigationBarItem(
            index = 3,
            onClick = { onSelected(Screen.PLUS) },
            icon = { StyleTabIcon(sfStyle, R.drawable.sf_star) { Icon(Icons.Rounded.Star, null) } },
            label = { Text("Verity+") }
        )
    }
}

@Composable
private fun StyleTabIcon(sfStyle: Boolean, sfResource: Int, material: @Composable () -> Unit) {
    if (sfStyle) {
        Image(
            painter = painterResource(sfResource),
            contentDescription = null,
            modifier = Modifier.size(24.dp),
            colorFilter = ColorFilter.tint(MaterialTheme.colorScheme.onSurface)
        )
    } else material()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChatScreen(
    chat: Chat,
    settings: AppSettings,
    model: String,
    isLoading: Boolean,
    error: String?,
    focusComposer: Boolean,
    showApiSuggestion: Boolean,
    onMenu: () -> Unit,
    onProvider: () -> Unit,
    onGeminiSuggestion: () -> Unit,
    onOpenPlus: () -> Unit,
    onAvatarPicked: (Uri) -> Unit,
    onSend: (String, List<FileAttachment>) -> Unit,
    onComposerFocused: () -> Unit,
    onDismissError: () -> Unit,
    sfStyle: Boolean
) {
    var input by rememberSaveable(chat.id) { mutableStateOf("") }
    var attachments by remember(chat.id) { mutableStateOf(emptyList<FileAttachment>()) }
    var attachmentError by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val attachmentScope = rememberCoroutineScope()
    val mainAvatarLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> uri?.let(onAvatarPicked) }
    val fileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            attachmentScope.launch {
                val batches = withContext(Dispatchers.IO) { uris.take(5).map { readAttachments(context, it) } }
                val loaded = batches.flatten().take(5)
                attachments = (attachments + loaded).distinctBy { it.name }.take(5)
                attachmentError = if (batches.any { it.isEmpty() }) "Некоторые файлы слишком большие или недоступны" else null
            }
        }
    }
    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val recognized = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!recognized.isNullOrBlank()) input = recognized
        }
    }
    val listState = rememberLazyListState()
    LaunchedEffect(chat.messages.size, isLoading) {
        if (chat.messages.isNotEmpty()) listState.animateScrollToItem(chat.messages.lastIndex + if (isLoading) 1 else 0)
    }
    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = {
            Column(Modifier.statusBarsPadding()) {
                TopAppBar(
                    title = {
                        Surface(onClick = onProvider, shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                            Row(Modifier.padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(model, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    },
                    navigationIcon = { IconButton(onClick = onMenu) { StyleTabIcon(sfStyle, R.drawable.sf_bubble) { Icon(Icons.Rounded.Menu, "История") } } },
                    actions = {
                        IconButton(onClick = { mainAvatarLauncher.launch("image/*") }) { Icon(Icons.Rounded.Add, "Добавить фото персонажа") }
                        IconButton(onClick = onProvider) { StyleTabIcon(sfStyle, R.drawable.sf_gear) { Icon(Icons.Rounded.Settings, "Модель и API") } }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
                )
                if (!settings.verityPlus) AdPlacement(onOpenPlus, Modifier.padding(horizontal = 16.dp))
            }
        },
        bottomBar = {
            MessageComposer(
                value = input,
                enabled = !isLoading,
                requestFocus = focusComposer,
                attachments = attachments,
                onValueChange = { input = it },
                onPickFiles = { fileLauncher.launch(arrayOf("*/*")) },
                onRemoveAttachment = { target -> attachments = attachments.filterNot { it.name == target.name } },
                onVoiceInput = {
                    voiceLauncher.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                    })
                },
                onFocusHandled = onComposerFocused,
                sfStyle = sfStyle,
                onSend = {
                    if (input.isNotBlank() || attachments.isNotEmpty()) {
                        onSend(input, attachments)
                        input = ""
                        attachments = emptyList()
                    }
                }
            )
        }
    ) { padding ->
        if (chat.messages.isEmpty()) {
            Column(Modifier.fillMaxSize().padding(padding)) {
                if (showApiSuggestion) {
                    GeminiSuggestionCard(onClick = onGeminiSuggestion, modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp))
                }
                EmptyPet(settings, modifier = Modifier.fillMaxWidth().weight(1f))
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (showApiSuggestion) item { GeminiSuggestionCard(onClick = onGeminiSuggestion) }
                items(chat.messages, key = { it.id }) { MessageBubble(it, sfStyle, settings) }
                if (isLoading) item { TypingBubble(sfStyle, settings) }
            }
        }
    }
    if (attachmentError != null) {
        AlertDialog(
            onDismissRequest = { attachmentError = null },
            title = { Text("Не все файлы добавлены") },
            text = { Text(attachmentError.orEmpty()) },
            confirmButton = { TextButton(onClick = { attachmentError = null }) { Text("Понятно") } }
        )
    }
    if (error != null) {
        AlertDialog(
            onDismissRequest = onDismissError,
            icon = { Icon(Icons.Rounded.Close, null) },
            title = { Text("Verity не смог ответить") },
            text = { Text(error + "\n\nПроверьте API-ключ, URL и название модели в настройках.") },
            confirmButton = { TextButton(onClick = onDismissError) { Text("Понятно") } }
        )
    }
}

@Composable
private fun GeminiSuggestionCard(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary) {
                Icon(Icons.Rounded.AutoAwesome, null, Modifier.padding(12.dp), tint = MaterialTheme.colorScheme.onPrimary)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Может, Gemini?", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Нажмите — покажу, как бесплатно получить API-ключ", color = MaterialTheme.colorScheme.onPrimaryContainer)
            }
            Text("›", style = MaterialTheme.typography.headlineMedium)
        }
    }
}

@Composable
private fun AdPlacement(onOpenPlus: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val widthDp = (LocalConfiguration.current.screenWidthDp - 32).coerceAtLeast(280)
    @Suppress("DEPRECATION")
    val adSize = remember(context, widthDp) {
        AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(context, widthDp)
    }
    var failed by remember { mutableStateOf(false) }
    if (!AdMobController.canRequestAds || failed) {
        PlusFallbackAd(onOpenPlus, modifier)
        return
    }
    AndroidView(
        modifier = modifier.fillMaxWidth().height(adSize.height.dp),
        factory = { viewContext ->
            AdView(viewContext).apply {
                adUnitId = BuildConfig.ADMOB_BANNER_ID
                setAdSize(adSize)
                adListener = object : AdListener() {
                    override fun onAdFailedToLoad(error: LoadAdError) {
                        failed = true
                    }
                }
                loadAd(AdRequest.Builder().build())
            }
        },
        onRelease = { it.destroy() }
    )
}

@Composable
private fun PlusFallbackAd(onOpenPlus: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("VERITY+", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                Text("Без рекламы · Legacy · Ловити", style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = onOpenPlus) { Text("Подробнее") }
        }
    }
}

@Composable
private fun GeminiHelpDialog(onDismiss: () -> Unit, onOpenSettings: () -> Unit) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Rounded.AutoAwesome, null) },
        title = { Text("Как подключить Gemini") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("1. Откройте Google AI Studio и войдите в Google.")
                Text("2. Нажмите Create API key.")
                Text("3. Скопируйте созданный ключ.")
                Text("4. В настройках Verity выберите Google Gemini и вставьте ключ в поле «API-ключ».")
                Text("Ключ хранится только на вашем устройстве.", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            }
        },
        confirmButton = {
            Button(onClick = {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/app/apikey")))
            }) { Text("Открыть AI Studio") }
        },
        dismissButton = {
            TextButton(onClick = onOpenSettings) { Text("Перейти в настройки") }
        }
    )
}

@Composable
private fun EmptyPet(settings: AppSettings, modifier: Modifier) {
    val hop by rememberInfiniteTransition(label = "pet hop").animateFloat(
        initialValue = 0f,
        targetValue = -18f,
        animationSpec = infiniteRepeatable(tween(620), RepeatMode.Reverse),
        label = "hop"
    )
    Box(modifier, contentAlignment = Alignment.Center) {
        VerityFace(settings, "happy", Modifier.offset(y = hop.dp).size(148.dp))
    }
}

@Composable
private fun MessageBubble(message: Message, sfStyle: Boolean, settings: AppSettings) {
    val user = message.role == "user"
    val shake by rememberInfiniteTransition(label = "mystery text shake").animateFloat(
        initialValue = -1.2f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(tween(85), RepeatMode.Reverse),
        label = "mystery text offset"
    )
    val shakeText = !user && MysteryStory.shouldShakeText(settings)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
        if (!user) {
            VerityFace(settings, message.mood ?: "happy", Modifier.size(40.dp))
            Spacer(Modifier.width(9.dp))
        }
        Surface(
            color = if (sfStyle && user) Color(0xFF007AFF)
                else if (user) MaterialTheme.colorScheme.primaryContainer
                else MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(
                topStart = 22.dp, topEnd = 22.dp,
                bottomStart = if (user) 22.dp else 6.dp,
                bottomEnd = if (user) 6.dp else 22.dp
            ),
            modifier = Modifier.widthIn(max = 640.dp)
        ) {
            SelectionContainer {
                Column(
                    Modifier.offset(x = if (shakeText) shake.dp else 0.dp).padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    message.attachments.forEach { attachment ->
                        Surface(color = MaterialTheme.colorScheme.surface.copy(alpha = .7f), shape = RoundedCornerShape(12.dp)) {
                            Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.AttachFile, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(attachment.name, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                    if (message.content.isNotBlank()) {
                        if (user) Text(
                            message.content,
                            style = MaterialTheme.typography.bodyLarge,
                            color = if (sfStyle) Color.White else Color.Unspecified
                        )
                        else FormattedAssistantText(message.content)
                    }
                    if (!message.videoUri.isNullOrBlank()) {
                        AndroidView(
                            modifier = Modifier.fillMaxWidth().height(320.dp).clip(RoundedCornerShape(16.dp)),
                            factory = { viewContext ->
                                VideoView(viewContext).apply {
                                    val controls = MediaController(viewContext)
                                    controls.setAnchorView(this)
                                    setMediaController(controls)
                                    setVideoURI(Uri.parse(message.videoUri))
                                    setOnPreparedListener { player -> player.isLooping = true; seekTo(1) }
                                    setOnClickListener { if (isPlaying) pause() else start() }
                                    tag = message.videoUri
                                }
                            },
                            update = { videoView ->
                                if (videoView.tag != message.videoUri) {
                                    videoView.setVideoURI(Uri.parse(message.videoUri))
                                    videoView.tag = message.videoUri
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TypingBubble(sfStyle: Boolean, settings: AppSettings) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        VerityFace(settings, "talking", Modifier.size(40.dp))
        Spacer(Modifier.width(9.dp))
        Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(if (sfStyle) 18.dp else 20.dp)) {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(17.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp)); Text("Думаю…")
            }
        }
    }
}

@Composable
private fun VerityFace(settings: AppSettings, mood: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var timerRevision by remember(settings.mysteryStartedAt, settings.mysteryEvent, settings.mysteryEnabled) { mutableStateOf(0) }
    LaunchedEffect(settings.mysteryStartedAt, settings.mysteryEvent, settings.mysteryEnabled) {
        if (MysteryStory.isEnabled(settings) && settings.mysteryStartedAt > 0L) {
            val remaining = settings.mysteryStartedAt + dev.veriti.app.data.MysteryStory.delayFor(settings) - System.currentTimeMillis()
            if (remaining > 0L) delay(remaining)
            timerRevision++
        }
    }
    val bitmap = remember(settings, mood, timerRevision) {
        (SkinSheet.faceForMood(context, settings, mood)
            ?: BitmapFactory.decodeResource(context.resources, R.drawable.verity_happy_cutout)).asImageBitmap()
    }
    Image(bitmap = bitmap, contentDescription = "Verity", modifier = modifier, contentScale = ContentScale.Fit)
}

@Composable
private fun MessageComposer(
    value: String,
    enabled: Boolean,
    requestFocus: Boolean,
    attachments: List<FileAttachment>,
    onValueChange: (String) -> Unit,
    onPickFiles: () -> Unit,
    onRemoveAttachment: (FileAttachment) -> Unit,
    onVoiceInput: () -> Unit,
    onFocusHandled: () -> Unit,
    sfStyle: Boolean,
    onSend: () -> Unit
) {
    val focusRequester = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    LaunchedEffect(requestFocus) {
        if (requestFocus) {
            focusRequester.requestFocus()
            keyboard?.show()
            onFocusHandled()
        }
    }
    Surface(color = if (sfStyle) Color.Black else MaterialTheme.colorScheme.surface, tonalElevation = if (sfStyle) 0.dp else 2.dp) {
        Column(Modifier.fillMaxWidth().imePadding().padding(horizontal = 12.dp, vertical = 8.dp)) {
            if (attachments.isNotEmpty()) {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    attachments.forEach { attachment ->
                        Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.secondaryContainer) {
                            Row(Modifier.padding(start = 10.dp, end = 4.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(attachment.name, maxLines = 1, style = MaterialTheme.typography.labelMedium)
                                IconButton(onClick = { onRemoveAttachment(attachment) }, Modifier.size(28.dp)) { Icon(Icons.Rounded.Close, "Убрать", Modifier.size(16.dp)) }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
            }
            if (sfStyle) {
                val canSend = enabled && (value.isNotBlank() || attachments.isNotEmpty())
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Surface(
                        modifier = Modifier.size(50.dp).border(1.dp, Color(0xFF3A3A3C), CircleShape),
                        shape = CircleShape,
                        color = Color(0xFF1C1C1E)
                    ) {
                        IconButton(onClick = onPickFiles, enabled = enabled) {
                            Icon(Icons.Rounded.Add, "Добавить фото, видео или файл", tint = Color(0xFFE5E5EA), modifier = Modifier.size(29.dp))
                        }
                    }
                    Surface(
                        modifier = Modifier.weight(1f).height(50.dp).border(1.dp, Color(0xFF3A3A3C), RoundedCornerShape(27.dp)),
                        shape = RoundedCornerShape(27.dp),
                        color = Color(0xFF1C1C1E)
                    ) {
                        Box(Modifier.fillMaxSize().padding(horizontal = 18.dp), contentAlignment = Alignment.CenterStart) {
                            BasicTextField(
                                value = value,
                                onValueChange = onValueChange,
                                modifier = Modifier.fillMaxWidth().focusRequester(focusRequester),
                                enabled = enabled,
                                maxLines = 4,
                                textStyle = TextStyle(color = Color.White, fontSize = MaterialTheme.typography.bodyLarge.fontSize),
                                cursorBrush = SolidColor(Color.White),
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                                keyboardActions = KeyboardActions(onSend = { if (canSend) onSend() })
                            )
                        }
                    }
                    Surface(
                        modifier = Modifier.size(50.dp).border(1.dp, Color(0xFF3A3A3C), CircleShape),
                        shape = CircleShape,
                        color = if (canSend) Color(0xFF0A84FF) else Color(0xFF1C1C1E)
                    ) {
                        IconButton(onClick = if (canSend) onSend else onVoiceInput, enabled = enabled) {
                            if (canSend) Icon(Icons.AutoMirrored.Rounded.Send, "Отправить", tint = Color.White)
                            else Icon(Icons.Rounded.Mic, "Голосовой ввод", tint = Color(0xFFE5E5EA), modifier = Modifier.size(27.dp))
                        }
                    }
                }
            } else {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                    IconButton(onClick = onPickFiles, enabled = enabled, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.Rounded.AttachFile, "Добавить файл")
                    }
                    OutlinedTextField(
                        value = value,
                        onValueChange = onValueChange,
                        modifier = Modifier.weight(1f).focusRequester(focusRequester),
                        placeholder = { Text("Сообщение для Verity…") },
                        shape = RoundedCornerShape(26.dp),
                        maxLines = 8,
                        enabled = enabled,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { onSend() })
                    )
                    Spacer(Modifier.width(8.dp))
                    FilledIconButton(onClick = onSend, enabled = enabled && (value.isNotBlank() || attachments.isNotEmpty()), modifier = Modifier.size(52.dp)) {
                        Icon(Icons.AutoMirrored.Rounded.Send, "Отправить")
                    }
                }
            }
        }
    }
}

@Composable
private fun FormattedAssistantText(content: String) {
    val parts = remember(content) { content.split("```") }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        parts.forEachIndexed { index, part ->
            if (part.isBlank()) return@forEachIndexed
            if (index % 2 == 1) {
                val code = part.substringAfter('\n', part).trim()
                Surface(color = MaterialTheme.colorScheme.inverseSurface, shape = RoundedCornerShape(14.dp)) {
                    Text(
                        code,
                        color = MaterialTheme.colorScheme.inverseOnSurface,
                        fontFamily = FontFamily.Monospace,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(14.dp).horizontalScroll(rememberScrollState())
                    )
                }
            } else {
                Text(part.trim(), style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}

private fun readAttachments(context: android.content.Context, uri: Uri): List<FileAttachment> = runCatching {
    val resolver = context.contentResolver
    val mime = resolver.getType(uri) ?: "application/octet-stream"
    var name = uri.lastPathSegment?.substringAfterLast('/') ?: "file"
    resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) name = cursor.getString(0)
    }
    if (mime.startsWith("video/")) {
        val retriever = MediaMetadataRetriever()
        return@runCatching try {
            retriever.setDataSource(context, uri)
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?.coerceAtLeast(1L) ?: 1L
            listOf(.08f, .28f, .50f, .72f, .92f).mapIndexedNotNull { index, position ->
                val frame = retriever.getFrameAtTime((durationMs * position * 1_000L).toLong(), MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    ?: return@mapIndexedNotNull null
                val scale = minOf(1f, 1024f / maxOf(frame.width, frame.height))
                val prepared = if (scale < 1f) Bitmap.createScaledBitmap(frame, (frame.width * scale).toInt(), (frame.height * scale).toInt(), true) else frame
                val output = ByteArrayOutputStream()
                prepared.compress(Bitmap.CompressFormat.JPEG, 82, output)
                if (prepared !== frame) prepared.recycle()
                frame.recycle()
                FileAttachment(
                    name = "$name · кадр ${index + 1}/5",
                    mimeType = "image/jpeg",
                    content = Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP),
                    isImage = true
                )
            }
        } finally {
            retriever.release()
        }
    }
    val bytes = resolver.openInputStream(uri)?.use { input ->
        val limit = if (mime.startsWith("image/")) 2_500_000 else 500_000
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(16 * 1024)
        var total = 0
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            total += read
            if (total > limit) error("Файл слишком большой")
            output.write(buffer, 0, read)
        }
        val data = output.toByteArray()
        if (data.size > limit) error("Файл слишком большой")
        data
    } ?: return@runCatching emptyList()
    if (mime.startsWith("image/")) {
        listOf(FileAttachment(name, mime, Base64.encodeToString(bytes, Base64.NO_WRAP), isImage = true))
    } else {
        val text = bytes.toString(Charsets.UTF_8).take(120_000)
        listOf(FileAttachment(name, mime, text, isImage = false))
    }
}.getOrDefault(emptyList())

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProviderSheet(selected: String, verityPlus: Boolean, onDismiss: () -> Unit, onSelect: (Provider) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = remember(query, verityPlus) {
        Providers.all.filter { provider ->
            (verityPlus || !Providers.isLocal(provider)) && provider.name.contains(query, ignoreCase = true)
        }
    }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxHeight(.88f)) {
            Text("${filtered.size} API-провайдер", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 24.dp))
            Text(if (verityPlus) "Включая локальные AI" else "Локальные AI доступны в Verity+", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                placeholder = { Text("Найти провайдера") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                shape = RoundedCornerShape(18.dp)
            )
            LazyColumn(contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 28.dp)) {
                items(filtered) { provider ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).clickable { onSelect(provider) }.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(42.dp).background(MaterialTheme.colorScheme.secondaryContainer, CircleShape),
                            contentAlignment = Alignment.Center
                        ) { Text(provider.name.take(1), fontWeight = FontWeight.Bold) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(provider.name, fontWeight = FontWeight.SemiBold)
                            Text(provider.defaultModel, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (provider.name == selected) Icon(Icons.Rounded.Check, "Выбрано", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ModelSheet(
    selected: String,
    models: List<String>,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = remember(query, models) {
        models.filter { it.contains(query.trim(), ignoreCase = true) }
    }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxHeight(.82f)) {
            Text(
                "Выберите модель",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 24.dp)
            )
            Text(
                "Новые модели находятся через API и появляются здесь автоматически",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp)
            )
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                placeholder = { Text("Найти модель") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                shape = RoundedCornerShape(18.dp)
            )
            LazyColumn(contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 28.dp)) {
                items(filtered) { model ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).clickable { onSelect(model) }.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(42.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                            contentAlignment = Alignment.Center
                        ) { Text(model.take(1).uppercase(), fontWeight = FontWeight.Bold) }
                        Spacer(Modifier.width(12.dp))
                        Text(model, Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                        if (model == models.firstOrNull()) {
                            Text("NEW", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(8.dp))
                        }
                        if (model == selected) Icon(Icons.Rounded.Check, "Выбрано", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AboutScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    fun openTelegram(username: String) {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/$username")))
    }
    fun openDevelopmentChannel() {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/+0YcvInzqHV85ODIy")))
    }
    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = {
            TopAppBar(
                modifier = Modifier.statusBarsPadding(),
                title = { Text("О приложении", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Назад")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding).navigationBarsPadding().padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item { Spacer(Modifier.height(8.dp)) }
            item {
            Card(
                modifier = Modifier.fillMaxWidth().widthIn(max = 620.dp),
                shape = RoundedCornerShape(40.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 30.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.surface.copy(alpha = .72f),
                        shape = RoundedCornerShape(48.dp)
                    ) {
                        Image(
                            painterResource(R.drawable.verity_happy_cutout),
                            "Verity",
                            Modifier.size(170.dp).padding(12.dp),
                            contentScale = ContentScale.Fit
                        )
                    }
                    Spacer(Modifier.height(24.dp))
                    Text(
                        "Verity",
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        "Версия ${BuildConfig.VERSION_NAME}",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .72f)
                    )
                }
            }
            }
            item { Spacer(Modifier.height(28.dp)) }
            item {
            Column(Modifier.fillMaxWidth().widthIn(max = 620.dp).padding(bottom = 24.dp)) {
                Text(
                    "Команда",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 4.dp, bottom = 14.dp)
                )
                MaterialDeveloperCard(
                    name = "Samrat",
                    role = "Разработчик",
                    username = "@Beketov_samrat",
                    avatarRes = R.drawable.developer_samrat,
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    onClick = { openTelegram("Beketov_samrat") }
                )
                Spacer(Modifier.height(12.dp))
                MaterialDeveloperCard(
                    name = "Мистер Бизнес",
                    role = "CEO",
                    username = "@Denkvant50",
                    avatarRes = R.drawable.developer_mister_business,
                    containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                    onClick = { openTelegram("Denkvant50") }
                )
                Spacer(Modifier.height(12.dp))
                MaterialDeveloperCard(
                    name = "Николай",
                    role = "Спрайтер и тестер",
                    username = "@kola67sn",
                    avatarRes = null,
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    onClick = { openTelegram("kola67sn") }
                )
                Spacer(Modifier.height(12.dp))
                MaterialDeveloperCard(
                    name = "Telegram-канал Verity",
                    role = "Разработка, тесты и новости",
                    username = "Открыть канал",
                    avatarRes = null,
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    onClick = { openDevelopmentChannel() }
                )
            }
            }
        }
    }
}

@Composable
private fun MaterialDeveloperCard(
    name: String,
    role: String,
    username: String?,
    avatarRes: Int?,
    containerColor: Color,
    onClick: (() -> Unit)?
) {
    Surface(
        modifier = Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        color = containerColor,
        shape = RoundedCornerShape(30.dp)
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(
                modifier = Modifier.size(58.dp),
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surface.copy(alpha = .8f)
            ) {
                if (avatarRes != null) {
                    Image(
                        painterResource(avatarRes),
                        name,
                        Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(name.take(1), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(role, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (username != null) {
                    Text(username, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = .72f))
                }
            }
            if (onClick != null) Text("↗", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun GameScreen(settings: AppSettings, onSave: (AppSettings) -> Unit, onOpenPlus: () -> Unit) {
    val context = LocalContext.current
    val session = remember { LanGameSession() }
    val lan by session.state.collectAsState()
    var hostAddress by rememberSaveable { mutableStateOf("") }
    var gameMode by rememberSaveable { mutableStateOf("football") }
    var localX by rememberSaveable { mutableStateOf(.28f) }
    var localY by rememberSaveable { mutableStateOf(.58f) }
    var playerScore by rememberSaveable { mutableStateOf(0) }
    var botScore by rememberSaveable { mutableStateOf(0) }
    var botX by remember { mutableStateOf(.72f) }
    var botY by remember { mutableStateOf(.50f) }
    var ballX by remember { mutableStateOf(.50f) }
    var ballY by remember { mutableStateOf(.50f) }
    var ballVx by remember { mutableStateOf(0f) }
    var ballVy by remember { mutableStateOf(0f) }
    var raceProgress by remember { mutableStateOf(.08f) }
    var botRaceProgress by remember { mutableStateOf(.08f) }
    val arenaLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            onSave(settings.copy(arenaSource = "gallery", arenaImageUri = uri.toString()))
        }
    }
    val arena = remember(settings.arenaSource, settings.arenaImageUri) {
        val bitmap = when (settings.arenaSource) {
            "numbers" -> BitmapFactory.decodeResource(context.resources, R.drawable.arena_verity_numbers)
            "gallery" -> runCatching {
                context.contentResolver.openInputStream(Uri.parse(settings.arenaImageUri))?.use(BitmapFactory::decodeStream)
            }.getOrNull() ?: BitmapFactory.decodeResource(context.resources, R.drawable.arena_verity_soccer)
            else -> BitmapFactory.decodeResource(context.resources, R.drawable.arena_verity_soccer)
        }
        bitmap.asImageBitmap()
    }
    val soccerArena = remember {
        BitmapFactory.decodeResource(context.resources, R.drawable.arena_verity_soccer).asImageBitmap()
    }
    val localPet = remember(settings) {
        (SkinSheet.faceForMood(context, settings, "happy")
            ?: BitmapFactory.decodeResource(context.resources, R.drawable.verity_happy_cutout)).asImageBitmap()
    }
    val remotePet = remember {
        (SkinSheet.faceForMood(context, settings.copy(verityPlus = true, skinStyle = "pink"), "happy")
            ?: BitmapFactory.decodeResource(context.resources, R.drawable.verity_happy_cutout)).asImageBitmap()
    }

    LaunchedEffect(gameMode) {
        while (true) {
            delay(16L)
            if (gameMode == "football") {
                val toBallX = ballX - botX
                val toBallY = ballY - botY
                val distance = hypot(toBallX, toBallY).coerceAtLeast(.001f)
                botX = (botX + toBallX / distance * .0023f).coerceIn(.05f, .95f)
                botY = (botY + toBallY / distance * .0023f).coerceIn(.10f, .90f)
                if (distance < .105f) {
                    ballVx = (-.010f - kotlin.math.abs(toBallX) * .02f)
                    ballVy = (ballY - botY) * .05f
                }
                ballX += ballVx
                ballY += ballVy
                ballVx *= .982f
                ballVy *= .982f
                if (ballY !in .08f..92f) {
                    ballY = ballY.coerceIn(.08f, .92f)
                    ballVy *= -.82f
                }
                if (ballX >= .98f) {
                    playerScore++
                    ballX = .5f; ballY = .5f; ballVx = 0f; ballVy = 0f
                } else if (ballX <= .02f) {
                    botScore++
                    ballX = .5f; ballY = .5f; ballVx = 0f; ballVy = 0f
                }
            } else {
                botRaceProgress += .0014f
                if (botRaceProgress >= .94f) {
                    botScore++
                    botRaceProgress = .08f
                    raceProgress = .08f
                }
            }
        }
    }

    DisposableEffect(Unit) {
        val activity = context as? android.app.Activity
        val previousOrientation = activity?.requestedOrientation
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        val overlayEnabled = context.getSharedPreferences("veriti_data", android.content.Context.MODE_PRIVATE)
            .getBoolean("overlay_enabled", false)
        if (overlayEnabled) ContextCompat.startForegroundService(
            context,
            Intent(context, FloatingAssistantService::class.java).setAction(FloatingAssistantService.ACTION_HIDE_FOR_GAME)
        )
        onDispose {
            session.close()
            if (previousOrientation != null) activity.requestedOrientation = previousOrientation
            if (overlayEnabled) ContextCompat.startForegroundService(
                context,
                Intent(context, FloatingAssistantService::class.java).setAction(FloatingAssistantService.ACTION_SHOW_AFTER_GAME)
            )
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = {
            TopAppBar(
                modifier = Modifier.statusBarsPadding(),
                title = { Text("Игра с Verity", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(shape = MaterialTheme.shapes.extraLarge) {
                    Box(Modifier.fillMaxWidth().aspectRatio(16f / 7.2f)) {
                        Canvas(
                            Modifier.fillMaxSize()
                                .pointerInput(gameMode) {
                                    detectTapGestures { point ->
                                        if (gameMode == "race") {
                                            raceProgress += .045f
                                            if (raceProgress >= .94f) {
                                                playerScore++
                                                raceProgress = .08f
                                                botRaceProgress = .08f
                                            }
                                            session.sendPosition(raceProgress, .52f)
                                        } else {
                                            localX = (point.x / size.width).coerceIn(.06f, .94f)
                                            localY = (point.y / size.height).coerceIn(.08f, .92f)
                                            val dx = ballX - localX
                                            val dy = ballY - localY
                                            if (hypot(dx, dy) < .14f) {
                                                ballVx = dx * .12f + .008f
                                                ballVy = dy * .12f
                                            }
                                        }
                                        session.sendPosition(localX, localY)
                                    }
                                }
                                .pointerInput(gameMode) {
                                    detectDragGestures(
                                        onDragStart = { point ->
                                            if (gameMode == "football") {
                                                localX = (point.x / size.width).coerceIn(.06f, .94f)
                                                localY = (point.y / size.height).coerceIn(.08f, .92f)
                                            }
                                        },
                                        onDrag = { change, _ ->
                                            change.consume()
                                            if (gameMode == "football") {
                                                localX = (change.position.x / size.width).coerceIn(.06f, .94f)
                                                localY = (change.position.y / size.height).coerceIn(.08f, .92f)
                                                val dx = ballX - localX
                                                val dy = ballY - localY
                                                if (hypot(dx, dy) < .14f) {
                                                    ballVx = dx * .12f + .008f
                                                    ballVy = dy * .12f
                                                }
                                                session.sendPosition(localX, localY)
                                            }
                                        }
                                    )
                                }
                        ) {
                            val background = if (gameMode == "football") soccerArena else arena
                            drawImage(background, dstSize = IntSize(size.width.toInt(), size.height.toInt()))
                            val petSize = minOf(size.width, size.height) * .22f
                            fun drawPet(image: androidx.compose.ui.graphics.ImageBitmap, x: Float, y: Float) {
                                drawImage(
                                    image,
                                    dstOffset = IntOffset((x * size.width - petSize / 2).toInt(), (y * size.height - petSize / 2).toInt()),
                                    dstSize = IntSize(petSize.toInt(), petSize.toInt())
                                )
                            }
                            if (gameMode == "football") {
                                drawCircle(Color.White, petSize * .18f, Offset(ballX * size.width, ballY * size.height))
                                drawCircle(Color.Black, petSize * .18f, Offset(ballX * size.width, ballY * size.height), style = androidx.compose.ui.graphics.drawscope.Stroke(3f))
                                drawPet(localPet, localX, localY)
                                drawPet(remotePet, botX, botY)
                                if (lan.connected) drawPet(remotePet, lan.remoteX, lan.remoteY)
                            } else {
                                val finishX = size.width * .94f
                                drawLine(Color.White, Offset(finishX, 0f), Offset(finishX, size.height), strokeWidth = 8f)
                                repeat(8) { index ->
                                    val top = index * size.height / 8f
                                    drawRect(if (index % 2 == 0) Color.Black else Color.White, Offset(finishX - 16f, top), androidx.compose.ui.geometry.Size(16f, size.height / 8f))
                                }
                                drawLine(Color.White.copy(alpha = .7f), Offset(0f, size.height * .5f), Offset(size.width, size.height * .5f), strokeWidth = 3f)
                                drawPet(localPet, raceProgress, .32f)
                                drawPet(remotePet, botRaceProgress, .70f)
                                if (lan.connected) drawPet(remotePet, lan.remoteX, .52f)
                            }
                        }
                        Surface(
                            Modifier.align(Alignment.TopStart).padding(12.dp),
                            shape = RoundedCornerShape(16.dp),
                            color = Color.Black.copy(alpha = .62f)
                        ) { Text("Вы $playerScore : $botScore Бот", color = Color.White, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)) }
                    }
                }
            }
            item {
                SettingsCard {
                    Text("Режим игры", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        if (gameMode == "football") "Ведите Verity пальцем и толкайте мяч в правые ворота. Розовый бот защищается и атакует."
                        else "Быстро нажимайте по арене, чтобы Verity добежал до финиша раньше розового бота.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("football" to "Футбол против бота", "race" to "Забег против бота").forEach { (value, label) ->
                            if (gameMode == value) Button(onClick = {}) { Text(label) }
                            else OutlinedButton(onClick = {
                                gameMode = value
                                playerScore = 0; botScore = 0
                                raceProgress = .08f; botRaceProgress = .08f
                                ballX = .5f; ballY = .5f
                            }) { Text(label) }
                        }
                    }
                    OutlinedButton(onClick = { arenaLauncher.launch(arrayOf("image/*")) }, Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.AttachFile, null); Spacer(Modifier.width(8.dp)); Text("Своя арена из галереи")
                    }
                    Text("Все арены бесплатны.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                }
            }
            item {
                SettingsCard {
                    Text("Мультиплеер по Wi‑Fi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Оба телефона должны быть в одной Wi‑Fi сети. Verity+ нужен хотя бы одному игроку; Bluetooth не используется.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(lan.status, color = if (lan.connected) Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary)
                    if (lan.address.isNotBlank()) Text("Адрес хоста: ${lan.address}:${LanGameSession.PORT}", fontWeight = FontWeight.SemiBold)
                    Button(onClick = { session.startHost(settings.verityPlus) }, Modifier.fillMaxWidth()) { Text("Создать игру") }
                    OutlinedTextField(
                        value = hostAddress,
                        onValueChange = { hostAddress = it },
                        label = { Text("IP телефона-хоста") },
                        placeholder = { Text("192.168.1.20") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedButton(onClick = { session.join(hostAddress, settings.verityPlus) }, Modifier.fillMaxWidth(), enabled = hostAddress.isNotBlank()) { Text("Подключиться") }
                    if (!settings.verityPlus) TextButton(onClick = onOpenPlus) { Text("Открыть Verity+") }
                }
            }
        }
    }
}

private fun isVerityAccessibilityEnabled(context: android.content.Context): Boolean {
    val component = ComponentName(context, VerityAccessibilityService::class.java).flattenToString()
    val enabled = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
    return enabled.split(':').any { it.equals(component, ignoreCase = true) }
}

private fun accessibilitySettingsIntent(context: android.content.Context): Intent =
    Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
        val component = ComponentName(context, VerityAccessibilityService::class.java)
        putExtra(Intent.EXTRA_COMPONENT_NAME, component)
    }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsScreen(
    settings: AppSettings,
    models: List<String>,
    isLoadingModels: Boolean,
    modelError: String?,
    update: ReleaseUpdate?,
    isCheckingUpdate: Boolean,
    updateError: String?,
    onPickProvider: () -> Unit,
    onRefreshModels: (Boolean) -> Unit,
    onSelectModel: (String) -> Unit,
    onCheckUpdate: () -> Unit,
    onAbout: () -> Unit,
    onCharacters: (Int) -> Unit,
    onSkinEditor: () -> Unit,
    onAppBuilder: () -> Unit,
    onHomeAssistant: () -> Unit,
    onFriends: () -> Unit,
    onFeatures: () -> Unit,
    onSave: (AppSettings) -> Unit,
    onAccentChange: (String) -> Unit
) {
    var draft by remember(settings) { mutableStateOf(settings) }
    var saved by remember { mutableStateOf(false) }
    var showModelPicker by rememberSaveable { mutableStateOf(false) }
    var showOfflineModels by rememberSaveable { mutableStateOf(false) }
    val modelChoices = remember(models, draft.providerName, draft.model) {
        val recommended = Providers.all.firstOrNull { it.name == draft.providerName }?.recommendedModels.orEmpty()
        (models + recommended + draft.model).filter { it.isNotBlank() }.distinct()
    }
    val context = LocalContext.current
    var overlayActive by rememberSaveable {
        mutableStateOf(context.getSharedPreferences("veriti_data", android.content.Context.MODE_PRIVATE).getBoolean("overlay_enabled", false))
    }
    val overlayLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (Settings.canDrawOverlays(context)) {
            ContextCompat.startForegroundService(context, Intent(context, FloatingAssistantService::class.java))
            context.getSharedPreferences("veriti_data", android.content.Context.MODE_PRIVATE).edit().putBoolean("overlay_enabled", true).apply()
            overlayActive = true
        }
    }
    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val microphoneLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val avatarScope = rememberCoroutineScope()
    var avatarError by remember { mutableStateOf<String?>(null) }
    var customSkins by remember { mutableStateOf(SkinSheet.listCustomSkins(context)) }
    var showCustomSkinGallery by remember { mutableStateOf(false) }
    val avatarLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) avatarScope.launch {
            val imported = withContext(Dispatchers.IO) { SkinSheet.importAvatar(context, uri) }
            if (imported != null) {
                val updated = draft.copy(customAvatarUri = imported, selectedCharacterAsset = "")
                draft = updated
                onSave(updated)
                avatarError = null
                if (overlayActive) ContextCompat.startForegroundService(context, Intent(context, FloatingAssistantService::class.java).setAction(FloatingAssistantService.ACTION_REFRESH))
            } else avatarError = "Не удалось открыть изображение. Выбери PNG или JPG."
        }
    }
    var accessibilityActive by remember { mutableStateOf(isVerityAccessibilityEnabled(context)) }
    LaunchedEffect(Unit) {
        while (true) {
            accessibilityActive = isVerityAccessibilityEnabled(context)
            delay(1_000L)
        }
    }

    fun applyOverlaySettings(updated: AppSettings) {
        draft = updated
        onSave(updated)
        saved = true
        if (overlayActive) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, FloatingAssistantService::class.java).setAction(FloatingAssistantService.ACTION_REFRESH)
            )
        }
    }

    fun enableOverlay() {
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            microphoneLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 && ActivityCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Settings.canDrawOverlays(context)) {
            ContextCompat.startForegroundService(context, Intent(context, FloatingAssistantService::class.java))
            overlayActive = true
        } else {
            overlayLauncher.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = {
            TopAppBar(
                modifier = Modifier.statusBarsPadding(),
                title = { Text("Настройки", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(36.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Row(Modifier.fillMaxWidth().padding(22.dp), verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painterResource(R.drawable.ic_veriti),
                            "Иконка Verity",
                            Modifier.size(76.dp).clip(RoundedCornerShape(24.dp))
                        )
                        Spacer(Modifier.width(18.dp))
                        Column {
                            Text("Verity", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                            Text("${if (draft.uiStyle == "sf") "Cupertino Style" else "Material You 3"} · версия ${BuildConfig.VERSION_NAME} Litelia · Bug-Fix", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            item { SectionTitle("ИИ И API") }
            item {
                SettingsCard {
                    Text("Провайдер", style = MaterialTheme.typography.labelLarge)
                    OutlinedButton(onClick = onPickProvider, Modifier.fillMaxWidth()) {
                        Text(draft.providerName, Modifier.weight(1f)); Icon(Icons.Rounded.AutoAwesome, null)
                    }
                    OutlinedTextField(
                        value = draft.apiKey,
                        onValueChange = { draft = draft.copy(apiKey = it); saved = false },
                        label = { Text("API-ключ") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
                    )
                    Text("Модель", style = MaterialTheme.typography.labelLarge)
                    OutlinedButton(onClick = { showModelPicker = true }, Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.Start) {
                            Text(draft.model, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("Нажмите, чтобы выбрать", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(Icons.Rounded.AutoAwesome, null)
                    }
                    OutlinedButton(
                        onClick = {
                            onSave(draft)
                            onRefreshModels(true)
                        },
                        enabled = !isLoadingModels,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (isLoadingModels) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                        }
                        Text(if (isLoadingModels) "Получаю модели…" else "Найти новые модели")
                    }
                    if (models.isNotEmpty()) {
                        Text(
                            "Новые модели добавлены в список выбора",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (modelError != null) {
                        Text(modelError, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                    Button(onClick = { onSave(draft); saved = true }, Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.Check, null); Spacer(Modifier.width(8.dp)); Text("Сохранить")
                    }
                    AnimatedVisibility(saved) { Text("Сохранено локально на устройстве", color = Color(0xFF2E7D32), style = MaterialTheme.typography.bodySmall) }
                }
            }
            item { SectionTitle("ЯЗЫК ОТВЕТОВ И РЕЧИ") }
            item {
                SettingsCard {
                    Text("Выбери язык распознавания голоса и ответов ИИ. Автоматический режим старается отвечать на языке твоего последнего сообщения.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            "auto" to "Авто",
                            "ru-RU" to "Русский",
                            "en-US" to "English",
                            "de-DE" to "Deutsch",
                            "fr-FR" to "Français",
                            "es-ES" to "Español",
                            "it-IT" to "Italiano",
                            "pt-BR" to "Português",
                            "tr-TR" to "Türkçe",
                            "pl-PL" to "Polski",
                            "uk-UA" to "Українська",
                            "zh-CN" to "中文",
                            "ja-JP" to "日本語"
                        ).forEach { (code, label) ->
                            if (draft.language == code || (draft.language == "ru" && code == "ru-RU")) Button(onClick = {}) { Text(label) }
                            else OutlinedButton(onClick = { draft = draft.copy(language = code); onSave(draft); saved = true }) { Text(label) }
                        }
                    }
                    val onDeviceVoice = Build.VERSION.SDK_INT >= 31 && runCatching { android.speech.SpeechRecognizer.isOnDeviceRecognitionAvailable(context) }.getOrDefault(false)
                    Text(
                        if (onDeviceVoice) "На этом Android обнаружена поддержка локального распознавания речи. Наличие русского языкового пакета нужно проверить на устройстве." else "Локальное распознавание речи системой не обнаружено. Голосовой ввод может использовать сетевую службу Android.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            item { SectionTitle("ОФОРМЛЕНИЕ ПРИЛОЖЕНИЯ") }
            item {
                SettingsCard {
                    Text("Цветовая тема", fontWeight = FontWeight.SemiBold)
                    Text("Выбери акцент интерфейса. Настройка бесплатная и действует сразу.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            "violet" to "Фиолетовая",
                            "blue" to "Синяя",
                            "green" to "Зелёная",
                            "orange" to "Оранжевая",
                            "pink" to "Розовая",
                            "red" to "Красная"
                        ).forEach { (key, label) ->
                            if (draft.uiAccent == key) Button(onClick = {}) { Text(label) }
                            else OutlinedButton(onClick = {
                                draft = draft.copy(uiAccent = key)
                                onSave(draft)
                                onAccentChange(key)
                                saved = true
                            }) { Text(label) }
                        }
                    }
                }
            }
            item { SectionTitle("АССИСТЕНТ НА ЭКРАНЕ") }
            item {
                SettingsCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painterResource(R.drawable.verity_happy_cutout), null,
                            Modifier.size(54.dp), contentScale = ContentScale.Fit
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Летающий Verity", fontWeight = FontWeight.SemiBold)
                            Text("Нажмите — слушает. Бросьте — летит и отскакивает", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Text("Размер: ${draft.overlaySizeDp} dp", style = MaterialTheme.typography.labelLarge)
                    Slider(
                        value = draft.overlaySizeDp.toFloat(),
                        onValueChange = { draft = draft.copy(overlaySizeDp = it.toInt().coerceIn(56, 180)) },
                        onValueChangeFinished = { applyOverlaySettings(draft) },
                        valueRange = 56f..180f,
                        steps = 30
                    )
                    Text("Персонажей на экране: ${draft.overlayCharacterCount.coerceIn(1, 5)}", style = MaterialTheme.typography.labelLarge)
                    Slider(
                        value = draft.overlayCharacterCount.coerceIn(1, 5).toFloat(),
                        onValueChange = { draft = draft.copy(overlayCharacterCount = it.toInt().coerceIn(1, 5)) },
                        onValueChangeFinished = { applyOverlaySettings(draft) },
                        valueRange = 1f..5f,
                        steps = 3
                    )
                    Text("Каждый персонаж — отдельное плавающее окно. Теперь для каждого слота можно назначить собственную категорию или кадр из твоей таблицы.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        (0 until draft.overlayCharacterCount.coerceIn(1, 5)).forEach { slot ->
                            val slotAsset = CharacterSlotAssets.get(draft, slot)
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("Персонаж ${slot + 1}", fontWeight = FontWeight.SemiBold)
                                    val chosenCustomName = if (slotAsset.startsWith("file://")) {
                                        CustomCharacterLibrary.list(context).firstOrNull { it.uri == slotAsset }?.name ?: "Свой персонаж"
                                    } else null
                                    Text(
                                        when {
                                            slotAsset.isBlank() -> "Стандартный образ Verity"
                                            chosenCustomName != null -> "$chosenCustomName · свой персонаж"
                                            else -> slotAsset.trimEnd('/').substringAfterLast('/').removeSuffix(".png") + if (slotAsset.endsWith('/')) " · набор кадров" else " · один кадр"
                                        },
                                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                TextButton(onClick = { onCharacters(slot) }) { Text("Выбрать") }
                                if (slotAsset.isNotBlank()) {
                                    TextButton(onClick = { applyOverlaySettings(CharacterSlotAssets.set(draft, slot, "")) }) { Text("Сбросить") }
                                }
                            }
                        }
                    }
                    OutlinedButton(onClick = { avatarLauncher.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(8.dp)); Text(if (draft.customAvatarUri.isBlank()) "＋ Добавить своё фото персонажа" else "Заменить фото персонажа")
                    }
                    if (draft.customAvatarUri.isNotBlank()) {
                        Text("Фото сохранено внутри Verity и будет обрезано по кругу на плавающем персонаже.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        TextButton(onClick = { applyOverlaySettings(draft.copy(customAvatarUri = "")) }) { Text("Убрать своё фото") }
                    }
                    if (draft.selectedCharacterAsset.isNotBlank()) {
                        Text(
                            "Выбран персонаж из таблицы: ${draft.selectedCharacterAsset.trimEnd('/').substringAfterLast('/').removeSuffix(".png")}" + if (draft.selectedCharacterAsset.endsWith('/')) " · набор кадров" else " · один кадр",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        TextButton(onClick = { applyOverlaySettings(draft.copy(selectedCharacterAsset = "")) }) { Text("Вернуть стандартный образ") }
                    }
                    avatarError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Кнопки рядом с персонажами", fontWeight = FontWeight.SemiBold)
                            Text("Главный переключатель: показывает или скрывает все кнопки", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        AdaptiveSwitch(
                            checked = draft.overlayControlsVisible,
                            onCheckedChange = { applyOverlaySettings(draft.copy(overlayControlsVisible = it)) }
                        )
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Кнопка «Чат»", fontWeight = FontWeight.Medium)
                            Text("Отдельно открыть переписку с Verity", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        AdaptiveSwitch(
                            checked = draft.overlayChatButtonVisible,
                            onCheckedChange = { if (draft.overlayControlsVisible) applyOverlaySettings(draft.copy(overlayChatButtonVisible = it)) }
                        )
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Кнопка «Скрыть»", fontWeight = FontWeight.Medium)
                            Text("Убрать плавающих персонажей с экрана", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        AdaptiveSwitch(
                            checked = draft.overlayHideButtonVisible,
                            onCheckedChange = { if (draft.overlayControlsVisible) applyOverlaySettings(draft.copy(overlayHideButtonVisible = it)) }
                        )
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Экран блокировки", fontWeight = FontWeight.SemiBold)
                            Text("Показывать overlay поверх блокировки, если прошивка телефона это разрешает", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        AdaptiveSwitch(
                            checked = draft.showOnLockScreen,
                            onCheckedChange = { applyOverlaySettings(draft.copy(showOnLockScreen = it)) }
                        )
                    }
                    if (!overlayActive) {
                        Button(onClick = { enableOverlay() }, Modifier.fillMaxWidth()) { Text("Включить на экране") }
                    } else {
                        OutlinedButton(
                            onClick = {
                                context.getSharedPreferences("veriti_data", android.content.Context.MODE_PRIVATE).edit().putBoolean("overlay_enabled", false).apply()
                                context.stopService(Intent(context, FloatingAssistantService::class.java)); overlayActive = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Выключить") }
                    }
                }
            }
            item {
                SettingsCard {
                    Text("Автор проекта", fontWeight = FontWeight.SemiBold)
                    Text("TikTok: @dudesjack2", style = MaterialTheme.typography.bodyMedium)
                    TextButton(onClick = {
                        runCatching {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tiktok.com/@dudesjack2")))
                        }
                    }) { Text("Открыть TikTok автора") }
                }
            }
            item { SectionTitle("СВОИ ПЕРСОНАЖИ") }
            item {
                SettingsCard {
                    Text("Редактор и галерея", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Нарисуй свой образ, сохрани его в памяти приложения, вернись к нему позже или удали только собственные работы. Встроенные образы Verity и каталог из 48 групп не удаляются.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = onSkinEditor, modifier = Modifier.fillMaxWidth()) {
                        Text("Нарисовать своего персонажа")
                    }
                    OutlinedButton(onClick = {
                        customSkins = SkinSheet.listCustomSkins(context)
                        showCustomSkinGallery = true
                    }, modifier = Modifier.fillMaxWidth()) {
                        Text("Мои сохранённые персонажи (${customSkins.size})")
                    }
                    if (draft.skinStyle == "custom" && draft.customSkinSheetUri.isNotBlank()) {
                        Text("Сейчас используется собственный скин.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                        TextButton(onClick = { applyOverlaySettings(draft.copy(skinStyle = "verity", customSkinSheetUri = "")) }) { Text("Вернуть стандартный образ Verity") }
                    }
                }
            }
            item { SectionTitle("РЕЖИМЫ VERITY") }
            item {
                SettingsCard {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Страшный режим", fontWeight = FontWeight.SemiBold)
                            Text("По умолчанию выключен. При включении запускается мистическое событие с изменениями поведения и изображения персонажа.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        AdaptiveSwitch(
                            checked = draft.mysteryEnabled,
                            onCheckedChange = { applyOverlaySettings(draft.copy(mysteryEnabled = it)) }
                        )
                    }
                    Text("Обычный режим остаётся активным, пока вы сами не включите этот переключатель.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    Text("Начать визуальные события через ${draft.mysteryDelayHours} ч.", style = MaterialTheme.typography.labelLarge)
                    Slider(
                        value = draft.mysteryDelayHours.coerceIn(1, 168).toFloat(),
                        onValueChange = { draft = draft.copy(mysteryDelayHours = it.toInt().coerceIn(1, 168)) },
                        onValueChangeFinished = { applyOverlaySettings(draft) },
                        valueRange = 1f..168f,
                        steps = 166
                    )
                    Text("Эффекты затрагивают только персонажа и текст Verity. Они не меняют настройки телефона, не скрывают уведомления и не отключают приложение.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item {
                SettingsCard {
                    Text("Все основные функции", fontWeight = FontWeight.SemiBold)
                    Text(
                        listOf(
                            "Чат с ИИ через выбранный API",
                            "Голосовой ввод по нажатию на персонажа",
                            "Озвучивание ответов (Verity+)",
                            "Плавающий персонаж поверх приложений",
                            "Перемещение, броски и отскоки",
                            "Несколько персонажей на экране",
                            "Импорт и рисование собственных скинов",
                            "Прикрепление изображений и файлов к чату",
                            "Управление доступными кнопками через службу специальных возможностей",
                            "Локальные API-серверы и загрузка совместимых моделей"
                        ).joinToString("\n", prefix = "• "),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            item { SectionTitle("УПРАВЛЕНИЕ ПРИЛОЖЕНИЯМИ") }
            item {
                SettingsCard {
                    Text("Нажатия по голосовой команде", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Скажите, например: «Верити, нажми кнопку Отправить». Verity нажмёт только элемент с точной подписью. Если точное совпадение не найдено, команда будет отменена.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Платежи, покупки, удаления, разрешения и подтверждения заблокированы.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(if (accessibilityActive) "Служба Android включена" else "Служба Android выключена", fontWeight = FontWeight.SemiBold)
                                Text(if (draft.voiceClickEnabled) "Команды разрешены в Verity" else "Команды выключены в Verity", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            AdaptiveSwitch(
                                checked = draft.voiceClickEnabled,
                                onCheckedChange = { enabled ->
                                    applyOverlaySettings(draft.copy(voiceClickEnabled = enabled))
                                    if (enabled && !accessibilityActive) {
                                        context.startActivity(accessibilitySettingsIntent(context))
                                    }
                                }
                            )
                        }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Разрешить анализ снимка экрана", fontWeight = FontWeight.SemiBold)
                                Text("Только по твоей просьбе. Снимок будет отправлен выбранной AI-модели. По умолчанию выключено.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            AdaptiveSwitch(
                                checked = draft.screenImageAnalysisEnabled,
                                onCheckedChange = { enabled ->
                                    applyOverlaySettings(draft.copy(screenImageAnalysisEnabled = enabled))
                                    if (enabled && !accessibilityActive) context.startActivity(accessibilitySettingsIntent(context))
                                }
                            )
                        }
                    }
                    OutlinedButton(
                        onClick = { context.startActivity(accessibilitySettingsIntent(context)) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (accessibilityActive) "Проверить службу" else "Включить службу Android") }
                }
            }
            item {
                Text(
                    "Verity отправляет сообщения только выбранному вами API. История и ключ сохраняются локально.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }
            if (AdMobController.privacyOptionsRequired) {
                item { SectionTitle("КОНФИДЕНЦИАЛЬНОСТЬ РЕКЛАМЫ") }
                item {
                    SettingsCard {
                        Text("Настройки персонализации рекламы", fontWeight = FontWeight.SemiBold)
                        Text("Здесь можно изменить или отозвать ранее данное согласие.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        OutlinedButton(
                            onClick = { (context as? android.app.Activity)?.let(AdMobController::showPrivacyOptions) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Настроить рекламу") }
                    }
                }
            }
            item { SectionTitle("ОБНОВЛЕНИЯ") }
            item {
                SettingsCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Info, null, Modifier.size(30.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Обновление Verity", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("GitHub Releases", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    if (isCheckingUpdate) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(10.dp)); Text("Проверяю…")
                        }
                    } else if (update != null) {
                        if (update.isUpToDate) {
                            Text("Вы обновились до самой новой версии!", style = MaterialTheme.typography.bodyLarge, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                        } else if (update.hasApk) {
                            Text("Доступно обновление: ${update.name}", style = MaterialTheme.typography.bodyLarge)
                            Button(
                                onClick = {
                                    update.apkUrl?.let { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it))) }
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Скачать APK") }
                        } else {
                            Text("Есть обновление,оно вам не нужно", style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                    if (updateError != null) {
                        Text(updateError, color = MaterialTheme.colorScheme.error)
                    }
                    OutlinedButton(onClick = onCheckUpdate, enabled = !isCheckingUpdate, modifier = Modifier.fillMaxWidth()) {
                        Text("Проверить ещё раз")
                    }
                }
            }
            item {
                Card(
                    onClick = onFeatures,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
                ) {
                    Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("📚", style = MaterialTheme.typography.headlineLarge)
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Все функции Verity", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("Полный список возможностей и их текущий статус — бесплатно", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            item {
                Card(
                    onClick = { showOfflineModels = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🧠", style = MaterialTheme.typography.headlineLarge)
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Офлайн-нейросеть", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("Скачать компактную модель и подключить локальный сервер — доступно бесплатно", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            item {
                Card(
                    onClick = onHomeAssistant,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                ) {
                    Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🏠", style = MaterialTheme.typography.headlineLarge)
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Умный дом", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("Подключение Home Assistant: свет, выключатели и шторы", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            item {
                Card(
                    onClick = onFriends,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
                ) {
                    Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("💬", style = MaterialTheme.typography.headlineLarge)
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Verity и друзья", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("Комнаты по коду, текстовые сообщения и фотографии", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            item {
                Card(
                    onClick = onAppBuilder,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🛠️", style = MaterialTheme.typography.headlineLarge)
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Создатель приложений", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("Опиши приложение — Verity сгенерирует исходный проект ZIP и шаблон сборки APK", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            item {
                Card(
                    onClick = { onCharacters(0) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(32.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
                ) {
                    Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🎭", style = MaterialTheme.typography.headlineLarge)
                        Spacer(Modifier.width(18.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Каталог персонажей", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Text("48 групп из твоей таблицы", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(Icons.Rounded.Info, null, Modifier.size(28.dp))
                    }
                }
            }
            item {
                Card(
                    onClick = onAbout,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(32.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                ) {
                    Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            modifier = Modifier.size(64.dp),
                            shape = RoundedCornerShape(22.dp),
                            color = MaterialTheme.colorScheme.surface.copy(alpha = .72f)
                        ) {
                            Image(
                                painterResource(R.drawable.verity_happy_cutout),
                                null,
                                Modifier.padding(7.dp),
                                contentScale = ContentScale.Fit
                            )
                        }
                        Spacer(Modifier.width(18.dp))
                        Column(Modifier.weight(1f)) {
                            Text("О приложении", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Text("Verity · разработчики", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(Icons.Rounded.Info, null, Modifier.size(28.dp))
                    }
                }
            }
        }
    }

    if (showModelPicker) {
        ModelSheet(
            selected = draft.model,
            models = modelChoices,
            onDismiss = { showModelPicker = false },
            onSelect = { model ->
                draft = draft.copy(model = model)
                onSelectModel(model)
                saved = true
                showModelPicker = false
            }
        )
    }
    if (showCustomSkinGallery) {
        CustomSkinGalleryDialog(
            skins = customSkins,
            selectedUri = draft.customSkinSheetUri,
            onDismiss = { showCustomSkinGallery = false },
            onUse = { uri ->
                applyOverlaySettings(draft.copy(skinStyle = "custom", customSkinSheetUri = uri, customAvatarUri = "", selectedCharacterAsset = ""))
                showCustomSkinGallery = false
            },
            onDelete = { uri ->
                if (SkinSheet.deleteCustomSkin(context, uri)) {
                    customSkins = SkinSheet.listCustomSkins(context)
                    if (draft.customSkinSheetUri == uri) applyOverlaySettings(draft.copy(skinStyle = "verity", customSkinSheetUri = ""))
                }
            }
        )
    }
    if (showOfflineModels) {
        OfflineModelsDialog(
            onDismiss = { showOfflineModels = false },
            onOpenServer = {
                runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.micklab.llama"))) }
            }
        )
    }
}


@Composable
private fun PlusScreen(
    settings: AppSettings,
    onSave: (AppSettings) -> Unit,
    onStyleChange: (String) -> Unit,
    onOpenSkinEditor: () -> Unit
) {
    var draft by remember(settings) { mutableStateOf(settings) }
    var saved by remember { mutableStateOf(false) }
    var showPlusDialog by rememberSaveable { mutableStateOf(false) }
    var skinError by rememberSaveable { mutableStateOf<String?>(null) }
    var wallpaperStatus by rememberSaveable { mutableStateOf<String?>(null) }
    var localAiStatus by rememberSaveable { mutableStateOf<String?>(null) }
    var minecraftStatus by rememberSaveable { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val startMinecraft: () -> Unit = {
        runCatching { ContextCompat.startForegroundService(context, Intent(context, GameOverlayService::class.java)) }
            .onSuccess { minecraftStatus = "Minecraft 2D запущен поверх экрана. Остановка — кнопкой в уведомлении." }
            .onFailure { minecraftStatus = "Не удалось запустить режим: ${it.message ?: "ошибка Android"}" }
    }
    val minecraftPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (Settings.canDrawOverlays(context)) startMinecraft()
        else minecraftStatus = "Разрешение не выдано. Режим не запускался."
    }
    val skinLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val imported = withContext(Dispatchers.IO) { SkinSheet.importCustomSkin(context, uri) }
            if (imported != null) {
                runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                val updated = draft.copy(skinStyle = "custom", customSkinSheetUri = imported)
                draft = updated
                onSave(updated)
                saved = true
                skinError = null
            } else skinError = "Не удалось открыть изображение. Выберите PNG или JPG размером хотя бы 128×128."
        }
    }
    fun apply(updated: AppSettings) {
        draft = updated
        onSave(updated)
        saved = true
        if (context.getSharedPreferences("veriti_data", android.content.Context.MODE_PRIVATE).getBoolean("overlay_enabled", false)) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, FloatingAssistantService::class.java).setAction(FloatingAssistantService.ACTION_REFRESH)
            )
        }
    }
    fun installWallpaper(drawable: Int, name: String) {
        wallpaperStatus = "Устанавливаю…"
        scope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    val bitmap = BitmapFactory.decodeResource(context.resources, drawable)
                    WallpaperManager.getInstance(context).setBitmap(bitmap, null, true, WallpaperManager.FLAG_SYSTEM)
                }
            }.onSuccess { wallpaperStatus = "Обои «$name» установлены на главный экран." }
                .onFailure { wallpaperStatus = "Не удалось установить обои: ${it.message ?: "ошибка системы"}" }
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = {
            TopAppBar(
                modifier = Modifier.statusBarsPadding(),
                title = { Text("Verity+", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
                    shape = MaterialTheme.shapes.extraLarge
                ) {
                    Column(Modifier.fillMaxWidth().padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        StyleTabIcon(draft.uiStyle == "sf", R.drawable.sf_star) { Icon(Icons.Rounded.Star, null, Modifier.size(34.dp)) }
                        Text("Verity+", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text(
                            if (draft.verityPlus) "Активирован на этом устройстве"
                            else "Cupertino Style, скины, промты, голоса, физика, режим разработки, Wi‑Fi-комнаты и новый режим Verity в Minecraft 2D.",
                            color = MaterialTheme.colorScheme.onTertiaryContainer
                        )
                        if (!draft.verityPlus) Button(onClick = { showPlusDialog = true }, Modifier.fillMaxWidth()) { Text("Купить Verity+") }
                    }
                }
            }
            if (draft.verityPlus) {
                item { SectionTitle("ИГРА: VERITY В MINECRAFT 2D") }
                item {
                    SettingsCard {
                        Text("Minecraft 2D World", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Игровой мир поверх приложений: биомы, пещеры, города, деревни, мобы, дракон, блоки, добыча и инвентарь. Внутри мира появляется Verity с гравитацией, столкновением с блоками, ходьбой и прыжком.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Button(onClick = {
                            if (Settings.canDrawOverlays(context)) startMinecraft()
                            else minecraftPermissionLauncher.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
                        }, modifier = Modifier.fillMaxWidth()) { Text("Запустить Minecraft 2D") }
                        OutlinedButton(onClick = {
                            context.stopService(Intent(context, GameOverlayService::class.java))
                            minecraftStatus = "Режим Minecraft 2D остановлен."
                        }, modifier = Modifier.fillMaxWidth()) { Text("Остановить режим") }
                        Text(if (Settings.canDrawOverlays(context)) "Разрешение поверх других приложений уже выдано." else "При первом запуске Android попросит разрешение «Поверх других приложений». Оно нужно только для игрового оверлея.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (minecraftStatus != null) Text(minecraftStatus.orEmpty(), style = MaterialTheme.typography.bodySmall)
                        Text("Управление: сначала долго нажми первый слот «Рука», чтобы включить взаимодействие; затем используй кнопки ← / → / ↑. Жест двумя пальцами меняет масштаб и поворот мира вместе с Verity. Повтори долгое нажатие на «Руку», чтобы вернуть touch-through и пропускать касания к телефону.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                item { SectionTitle("ИНТЕРФЕЙС") }
                item {
                    SettingsCard {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Cupertino Style", fontWeight = FontWeight.SemiBold)
                                Text("Интерфейс в стиле Apple Cupertino с прозрачными стеклянными панелями", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            AdaptiveSwitch(
                                checked = draft.uiStyle == "sf",
                                onCheckedChange = { sf ->
                                    val updated = draft.copy(uiStyle = if (sf) "sf" else "material")
                                    apply(updated)
                                    onStyleChange(updated.uiStyle)
                                }
                            )
                        }
                    }
                }
                item { SectionTitle("ХАРАКТЕР И ГОЛОС") }
                item {
                    SettingsCard {
                        OutlinedTextField(
                            value = draft.systemPrompt,
                            onValueChange = { draft = draft.copy(systemPrompt = it); saved = false },
                            label = { Text("Свой промт Verity") },
                            minLines = 5,
                            maxLines = 12,
                            modifier = Modifier.fillMaxWidth()
                        )
                        TextButton(onClick = { draft = draft.copy(systemPrompt = DEFAULT_SYSTEM_PROMPT); saved = false }) { Text("Стандартный промт") }
                        Text("Физика", style = MaterialTheme.typography.labelLarge)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("classic" to "Классика", "bouncy" to "Прыгучая", "float" to "Невесомость").forEach { (value, label) ->
                                if (draft.physicsStyle == value) Button(onClick = {}) { Text(label) }
                                else OutlinedButton(onClick = { draft = draft.copy(physicsStyle = value); saved = false }) { Text(label) }
                            }
                        }
                        Text("Голос", style = MaterialTheme.typography.labelLarge)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("off" to "Текст", "bright" to "Высокий", "deep" to "Низкий", "fast" to "Быстрый").forEach { (value, label) ->
                                if (draft.voiceStyle == value) Button(onClick = {}) { Text(label) }
                                else OutlinedButton(onClick = { apply(draft.copy(voiceStyle = value)) }) { Text(label) }
                            }
                        }
                    }
                }
                item { SectionTitle("СКИНЫ") }
                item {
                    SettingsCard {
                        Text("Verity, Legacy, Ловити, Фокси, Абесити или своя картинка", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(
                                "verity" to "Verity",
                                "legacy" to "Legacy",
                                "pink" to "Ловити",
                                "foxy" to "Фокси",
                                "abesity" to "Абесити"
                            ).forEach { (value, label) ->
                                if (draft.skinStyle == value) Button(onClick = {}) { Text(label) }
                                else OutlinedButton(onClick = { apply(draft.copy(skinStyle = value)) }) { Text(label) }
                            }
                        }
                        Text(
                            when (draft.skinStyle) {
                                "legacy" -> "Legacy — классический плоский облик Verity из первой версии."
                                "pink" -> "Ловити — розовая девочка Verity."
                                "foxy" -> "Фокси — синий скин из присланной таблицы эмоций."
                                "abesity" -> "Абесити — крупный жёлтый скин из присланной таблицы эмоций."
                                "custom" -> "Используется выбранная вами текстура. Поддерживается и таблица эмоций, и одна картинка."
                                else -> "Обычный характер Verity."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedButton(onClick = { skinLauncher.launch(arrayOf("image/*")) }, Modifier.fillMaxWidth()) {
                            Icon(Icons.Rounded.AttachFile, null); Spacer(Modifier.width(8.dp)); Text("Импортировать шаблон")
                        }
                        Text("Откроется системный выбор файлов. Текстура копируется внутрь игры и не пропадёт после перезагрузки.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        OutlinedButton(onClick = onOpenSkinEditor, Modifier.fillMaxWidth()) { Text("Нарисовать скин") }
                        if (skinError != null) Text(skinError.orEmpty(), color = MaterialTheme.colorScheme.error)
                        Text("Второй персонаж на экране", style = MaterialTheme.typography.labelLarge)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(
                                "none" to "Нет", "verity" to "Verity", "pink" to "Ловити",
                                "foxy" to "Фокси", "abesity" to "Абесити", "legacy" to "Legacy"
                            ).forEach { (value, label) ->
                                if (draft.secondarySkinStyle == value) Button(onClick = {}) { Text(label) }
                                else OutlinedButton(onClick = { apply(draft.copy(secondarySkinStyle = value)) }) { Text(label) }
                            }
                        }
                    }
                }
                item { SectionTitle("ОБОИ") }
                item {
                    SettingsCard {
                        Text("Обои главного экрана", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Установка выполняется через системный WallpaperManager.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Button(onClick = { installWallpaper(R.drawable.arena_verity_soccer, "Футбольное поле") }, Modifier.fillMaxWidth()) {
                            Text("Поставить футбольное поле")
                        }
                        OutlinedButton(onClick = { installWallpaper(R.drawable.arena_verity_numbers, "Линии 1–10") }, Modifier.fillMaxWidth()) {
                            Text("Поставить линии 1–10")
                        }
                        if (wallpaperStatus != null) Text(wallpaperStatus.orEmpty(), style = MaterialTheme.typography.bodySmall)
                    }
                }
                item { SectionTitle("СОБЫТИЕ ЧЕРЕЗ 3 ДНЯ") }
                item {
                    SettingsCard {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Мистическое событие", fontWeight = FontWeight.SemiBold)
                                Text("Если выключить, Verity останется на экране без ограничения по времени.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            AdaptiveSwitch(
                                checked = draft.mysteryEnabled,
                                onCheckedChange = { apply(draft.copy(mysteryEnabled = it)) }
                            )
                        }
                    }
                }
                item { SectionTitle("РАЗРАБОТКА") }
                item {
                    SettingsCard {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Режим разработки", fontWeight = FontWeight.SemiBold)
                                Text("Ручной адрес совместимого API", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            AdaptiveSwitch(checked = draft.developerMode, onCheckedChange = { apply(draft.copy(developerMode = it)) })
                        }
                        if (draft.developerMode) OutlinedTextField(
                            value = draft.baseUrl,
                            onValueChange = { draft = draft.copy(baseUrl = it); saved = false },
                            label = { Text("Base URL") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                item {
                    Button(onClick = { apply(draft) }, Modifier.fillMaxWidth()) { Text("Сохранить настройки Verity+") }
                    AnimatedVisibility(saved) { Text("Сохранено", color = Color(0xFF2E7D32)) }
                }
            }
        }
    }
    if (showPlusDialog) VerityPlusDialog(
        onDismiss = { showPlusDialog = false },
        onActivated = {
            apply(draft.copy(verityPlus = true))
            showPlusDialog = false
        }
    )
}

@Composable
private fun SkinEditorScreen(onBack: () -> Unit, onSave: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val strokes = remember { mutableStateListOf<SkinStroke>() }
    var faceColor by remember { mutableStateOf(Color(0xFFFFD925)) }
    var inkColor by remember { mutableStateOf(Color.Black) }
    var brushWidth by remember { mutableStateOf(.035f) }
    var saving by remember { mutableStateOf(false) }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = {
            TopAppBar(
                modifier = Modifier.statusBarsPadding(),
                title = { Text("Редактор скина", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Назад") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Нарисуйте одну эмоцию", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(
                "Приложение само повторит рисунок в десяти слотах правильного шаблона. Импортированный файл проходит такую же проверку 5×2.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Card(
                Modifier.fillMaxWidth().weight(1f),
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101012))
            ) {
                Canvas(
                    Modifier.fillMaxSize().padding(18.dp).pointerInput(inkColor, brushWidth) {
                        fun normalized(point: Offset) = android.graphics.PointF(
                            (point.x / size.width.toFloat()).coerceIn(0f, 1f),
                            (point.y / size.height.toFloat()).coerceIn(0f, 1f)
                        )
                        detectDragGestures(
                            onDragStart = { point ->
                                strokes.add(SkinStroke(listOf(normalized(point)), inkColor.toArgb(), brushWidth))
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                if (strokes.isNotEmpty()) {
                                    val last = strokes.last()
                                    strokes[strokes.lastIndex] = last.copy(points = last.points + normalized(change.position))
                                }
                            }
                        )
                    }
                ) {
                    val radius = minOf(size.width, size.height) * .42f
                    drawCircle(faceColor, radius, center)
                    strokes.forEach { stroke ->
                        val color = Color(stroke.color)
                        stroke.points.zipWithNext().forEach { (from, to) ->
                            drawLine(
                                color = color,
                                start = Offset(from.x * size.width, from.y * size.height),
                                end = Offset(to.x * size.width, to.y * size.height),
                                strokeWidth = stroke.width * minOf(size.width, size.height),
                                cap = androidx.compose.ui.graphics.StrokeCap.Round
                            )
                        }
                    }
                }
            }
            Text("Цвет скина", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(Color(0xFFFFD925), Color(0xFFFF6FB4), Color(0xFF55B8FF), Color(0xFF78D66B)).forEach { color ->
                    Surface(
                        modifier = Modifier.size(42.dp).clip(CircleShape).clickable { faceColor = color },
                        color = color,
                        shape = CircleShape,
                        tonalElevation = if (faceColor == color) 8.dp else 0.dp
                    ) {}
                }
                Spacer(Modifier.weight(1f))
                listOf(Color.Black, Color.White).forEach { color ->
                    Surface(
                        modifier = Modifier.size(42.dp).clip(CircleShape).clickable { inkColor = color },
                        color = color,
                        shape = CircleShape,
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {}
                }
            }
            Text("Толщина линии", style = MaterialTheme.typography.labelLarge)
            Slider(value = brushWidth, onValueChange = { brushWidth = it }, valueRange = .012f..08f)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { strokes.clear() }, Modifier.weight(1f), enabled = strokes.isNotEmpty()) { Text("Очистить") }
                Button(
                    onClick = {
                        saving = true
                        scope.launch {
                            val uri = withContext(Dispatchers.IO) {
                                SkinSheet.createDrawnTemplate(context, faceColor.toArgb(), strokes.toList())
                            }
                            saving = false
                            onSave(uri)
                        }
                    },
                    modifier = Modifier.weight(1f),
                    enabled = strokes.isNotEmpty() && !saving
                ) { Text(if (saving) "Сохраняю…" else "Сохранить") }
            }
        }
    }
}

@Composable
private fun VerityPlusDialog(onDismiss: () -> Unit, onActivated: () -> Unit) {
    val context = LocalContext.current
    var key by rememberSaveable { mutableStateOf("") }
    var visited by rememberSaveable { mutableStateOf(false) }
    var invalid by rememberSaveable { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Rounded.Star, null) },
        title = { Text("Подключить Verity+") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("1. Перейдите на страницу Boosty по кнопке ниже и оформите Verity+.\n2. Вернитесь сюда и введите полученный ключ.")
                OutlinedButton(
                    onClick = {
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://boosty.to/hyperpyos/posts/9ea8364e-3520-47a3-8099-2e9f1e1ef995")))
                        visited = true
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Перейти на Boosty") }
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it; invalid = false },
                    label = { Text("Ключ Verity+") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (!visited) Text("Сначала откройте страницу покупки.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (invalid) Text("Ключ не подошёл. Проверьте символы и попробуйте снова.", color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            Button(onClick = {
                if (activationKeyMatches(key)) onActivated() else invalid = true
            }, enabled = key.isNotBlank()) { Text("Активировать") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Позже") } }
    )
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = 4.dp, top = 8.dp))
}

@Composable
private fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f))) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
    }
}

@OptIn(ExperimentalAdaptiveApi::class)
@Composable
private fun Button(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    content: @Composable RowScope.() -> Unit
) = AdaptiveButton(onClick = onClick, modifier = modifier, enabled = enabled, content = content)

@OptIn(ExperimentalAdaptiveApi::class)
@Composable
private fun OutlinedButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    content: @Composable RowScope.() -> Unit
) = AdaptiveTonalButton(onClick = onClick, modifier = modifier, enabled = enabled, content = content)

@OptIn(ExperimentalAdaptiveApi::class)
@Composable
private fun TextButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    content: @Composable RowScope.() -> Unit
) = AdaptiveTextButton(onClick = onClick, modifier = modifier, enabled = enabled, content = content)

@OptIn(ExperimentalAdaptiveApi::class)
@Composable
private fun Slider(
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    valueRange: ClosedFloatingPointRange<Float> = 0f..1f,
    steps: Int = 0,
    onValueChangeFinished: (() -> Unit)? = null
) = AdaptiveSlider(
    value = value,
    onValueChange = onValueChange,
    modifier = modifier,
    enabled = enabled,
    valueRange = valueRange,
    steps = steps,
    onValueChangeFinished = onValueChangeFinished
)

@OptIn(ExperimentalAdaptiveApi::class)
@Composable
private fun Scaffold(
    modifier: Modifier = Modifier,
    contentWindowInsets: WindowInsets = WindowInsets(0),
    topBar: @Composable () -> Unit = {},
    bottomBar: @Composable () -> Unit = {},
    content: @Composable (PaddingValues) -> Unit
) = AdaptiveScaffold(
    modifier = modifier,
    contentWindowInsets = contentWindowInsets,
    topBar = topBar,
    bottomBar = bottomBar,
    content = content
)

@OptIn(ExperimentalAdaptiveApi::class)
@Composable
private fun TopAppBar(
    title: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    navigationIcon: @Composable () -> Unit = {},
    actions: @Composable RowScope.() -> Unit = {},
    colors: TopAppBarColors = TopAppBarDefaults.topAppBarColors()
) = AdaptiveTopAppBar(
    title = title,
    modifier = modifier,
    navigationIcon = navigationIcon,
    actions = actions,
    adaptation = { material { this.colors = colors } }
)
