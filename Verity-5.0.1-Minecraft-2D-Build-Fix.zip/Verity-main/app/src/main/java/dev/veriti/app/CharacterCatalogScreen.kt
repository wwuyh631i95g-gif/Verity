package dev.veriti.app

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.veriti.app.data.CharacterLore
import dev.veriti.app.data.CustomCharacterLibrary

private val characterNames = listOf(
    "Жёлтый шар", "Розовый персонаж", "Синий воздушный шар", "Коричневые пушистики", "Зелёный стеклянный куб", "Красная пружина",
    "Зелёный куб", "Жёлтый куб", "Красные круглые лица", "Жёлтые шарики", "Оранжевые смайлики", "Голубые пушистые лица",
    "Коричневые круглые лица", "Жёлтые нарисованные лица", "Коричневые кубики", "Чёрный музыкальный персонаж", "Коричневый румяный шар", "Кольцевые змеи",
    "Жёлтые треугольные лица", "Зелёный слизистый куб", "Звезда в очках", "Голубая луна", "Жёлтые круглые лица", "Маленькая фигурка",
    "Чёрный смайлик", "Красная кнопка", "Красная зубастая голова", "Синяя зубастая голова", "Жёлтое лицо", "Жёлтый треугольник",
    "Жёлтая уточка", "Розовый смайлик", "Радужный смайлик", "Белый смайлик", "Синий смайлик", "Чёрный апгрейдер",
    "Розовый персонаж с глазами", "Фиолетовый персонаж", "Красная улыбка", "Жёлтые нижние смайлики", "Курочки", "Зелёный поросёнок",
    "Фиолетовый персонаж в очках", "Голубой персонаж с руками", "Огненный персонаж", "Оранжевая планета", "Красный сердитый персонаж", "Светлый розовый смайлик"
)

private val characterNicknames = listOf(
    "Желтик", "Пинкси", "Облачко", "Пухлик", "Смарагд", "Пружик", "Кубикс", "Золотик", "Краснолик", "Солныш", "Апельсик", "Иней",
    "Камеш", "Дудлик", "Какао", "Нотик", "Румяш", "Колечко", "Трикси", "Слаймик", "Звездар", "Лунар", "Улыбчик", "Крош",
    "Ночик", "Клик", "Зубастик", "Синезуб", "Хмурик", "Треугольчик", "Утёнок", "Магента", "Радужик", "Снежок", "Синик", "Апгрейд",
    "Глазастик", "Вайлет", "Рэдик", "Мимик", "Курочка", "Поросёнок", "Очкарик", "Лапыч", "Плами", "Планетик", "Сердитик", "Розик"
)

private fun spritePath(group: Int, variant: Int) =
    "character_catalog/sprites/${group.toString().padStart(2, '0')}/${group.toString().padStart(2, '0')}_${variant.toString().padStart(2, '0')}.png"

@Composable
private fun CatalogAsset(path: String, modifier: Modifier = Modifier, contentDescription: String? = null) {
    val context = LocalContext.current
    val bitmap = remember(path) {
        if (path.startsWith("file://")) {
            runCatching { CustomCharacterLibrary.loadBitmap(context, path)?.asImageBitmap() }.getOrNull()
        } else {
            runCatching { context.assets.open(path).use { BitmapFactory.decodeStream(it)?.asImageBitmap() } }.getOrNull()
        }
    }
    if (bitmap != null) Image(bitmap, contentDescription, modifier, contentScale = ContentScale.Fit)
    else Box(modifier, contentAlignment = Alignment.Center) { Text("—") }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun CharacterCatalogScreen(
    targetSlot: Int = 0,
    onBack: () -> Unit,
    onSelectCharacter: (String) -> Unit,
    onDeleteCustomCharacter: (String) -> Unit = {}
) {
    val context = LocalContext.current
    var selectedGroup by remember { mutableIntStateOf(0) }
    var selectedVariant by remember { mutableIntStateOf(1) }
    var query by remember { mutableStateOf("") }
    var customCharacters by remember { mutableStateOf(CustomCharacterLibrary.list(context)) }
    var pendingImage by remember { mutableStateOf<Uri?>(null) }
    var newCharacterName by remember { mutableStateOf("") }
    var importError by remember { mutableStateOf<String?>(null) }
    var characterToDelete by remember { mutableStateOf<CustomCharacterLibrary.Entry?>(null) }
    var characterToRename by remember { mutableStateOf<CustomCharacterLibrary.Entry?>(null) }
    var renameText by remember { mutableStateOf("") }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            pendingImage = uri
            newCharacterName = "Мой персонаж ${customCharacters.size + 1}"
            importError = null
        }
    }

    val filtered = remember(query) {
        (1..48).filter {
            characterNames[it - 1].contains(query.trim(), ignoreCase = true) ||
                characterNicknames[it - 1].contains(query.trim(), ignoreCase = true) ||
                it.toString() == query.trim()
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = {
            TopAppBar(
                modifier = Modifier.statusBarsPadding(),
                title = { Text("Каталог · персонаж ${targetSlot + 1}", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Назад") } }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).navigationBarsPadding().padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 18.dp)
        ) {
            item {
                Text(
                    "Выбираешь образ именно для персонажа ${targetSlot + 1}. Встроенные 48 групп нельзя удалить. Можно добавить собственные картинки — они сохраняются внутри Verity и доступны для любого из пяти слотов.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Найти встроенную категорию") },
                    singleLine = true
                )
            }
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Мои персонажи", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text("Добавь свою картинку. Verity сохранит её как отдельного персонажа с прозрачным круглым фоном.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Button(onClick = { imagePicker.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Rounded.AddPhotoAlternate, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Добавить персонажа из фото")
                        }
                        if (customCharacters.isEmpty()) {
                            Text("Пока нет собственных персонажей.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            items(customCharacters, key = { it.uri }) { entry ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.fillMaxWidth().padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CatalogAsset(entry.uri, Modifier.size(64.dp), entry.name)
                        Column(Modifier.weight(1f)) {
                            Text(entry.name, fontWeight = FontWeight.SemiBold)
                            Text("Твой персонаж · статичная картинка", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            TextButton(onClick = { onSelectCharacter(entry.uri) }) { Text("Выбрать") }
                            Row {
                                IconButton(onClick = { characterToRename = entry; renameText = entry.name }) {
                                    Icon(Icons.Rounded.Edit, "Переименовать")
                                }
                                IconButton(onClick = { characterToDelete = entry }) {
                                    Icon(Icons.Rounded.DeleteOutline, "Удалить")
                                }
                            }
                        }
                    }
                }
            }
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Полная исходная таблица", fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        CatalogAsset("character_catalog/source_table.jpg", Modifier.fillMaxWidth().heightIn(max = 390.dp), "Исходная таблица персонажей")
                    }
                }
            }
            items(filtered) { id ->
                Card(onClick = { selectedGroup = id; selectedVariant = 1 }, modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CatalogAsset(spritePath(id, 1), Modifier.size(66.dp), "${characterNames[id - 1]}, вариант 1")
                        Column(Modifier.weight(1f)) {
                            Text("${id.toString().padStart(2, '0')}. ${characterNicknames[id - 1]} · ${characterNames[id - 1]}", fontWeight = FontWeight.SemiBold)
                            Text("12 отдельных изображений · выбрать", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }

    if (pendingImage != null) {
        AlertDialog(
            onDismissRequest = { pendingImage = null },
            title = { Text("Имя нового персонажа") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newCharacterName,
                        onValueChange = { newCharacterName = it.take(32) },
                        label = { Text("Имя") },
                        singleLine = true
                    )
                    importError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val uri = pendingImage
                    if (uri != null) {
                        val entry = CustomCharacterLibrary.importCharacter(context, uri, newCharacterName)
                        if (entry == null) importError = "Не удалось импортировать изображение. Попробуй другую картинку."
                        else {
                            customCharacters = CustomCharacterLibrary.list(context)
                            pendingImage = null
                            importError = null
                        }
                    }
                }) { Text("Сохранить персонажа") }
            },
            dismissButton = { TextButton(onClick = { pendingImage = null }) { Text("Отмена") } }
        )
    }

    characterToRename?.let { entry ->
        AlertDialog(
            onDismissRequest = { characterToRename = null },
            title = { Text("Переименовать персонажа") },
            text = {
                OutlinedTextField(value = renameText, onValueChange = { renameText = it.take(32) }, label = { Text("Имя") }, singleLine = true)
            },
            confirmButton = {
                Button(onClick = {
                    if (CustomCharacterLibrary.rename(context, entry.uri, renameText)) {
                        customCharacters = CustomCharacterLibrary.list(context)
                        characterToRename = null
                    }
                }) { Text("Сохранить") }
            },
            dismissButton = { TextButton(onClick = { characterToRename = null }) { Text("Отмена") } }
        )
    }

    characterToDelete?.let { entry ->
        AlertDialog(
            onDismissRequest = { characterToDelete = null },
            title = { Text("Удалить ${entry.name}?") },
            text = { Text("Удалится только твоя собственная картинка. Встроенные 48 групп персонажей удалить нельзя. Если этот образ назначен в нескольких слотах, они вернутся к стандартному образу.") },
            confirmButton = {
                Button(onClick = {
                    if (CustomCharacterLibrary.delete(context, entry.uri)) {
                        onDeleteCustomCharacter(entry.uri)
                        customCharacters = CustomCharacterLibrary.list(context)
                    }
                    characterToDelete = null
                }) { Text("Удалить") }
            },
            dismissButton = { TextButton(onClick = { characterToDelete = null }) { Text("Отмена") } }
        )
    }

    if (selectedGroup in 1..48) {
        AlertDialog(
            onDismissRequest = { selectedGroup = 0 },
            title = { Text("${characterNicknames[selectedGroup - 1]} · ${characterNames[selectedGroup - 1]}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("В каждом наборе 12 вырезанных кадров. Персонаж использует кадры для 12 настроений (радость, нейтральное, злость, грусть, речь, испуг, любопытство, сонливость, смех, удивление, симпатия и переходные состояния). В исходной таблице эмоции не подписаны, поэтому соответствие приблизительное.", style = MaterialTheme.typography.bodySmall)
                    CharacterLore.get(selectedGroup)?.let { lore ->
                        Text("Предыстория · ${lore.name}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text(lore.story, style = MaterialTheme.typography.bodySmall)
                        Text("Это оригинальная история Verity, а не подтверждённый канон какой-либо игры или мультфильма. В Verity+ она также влияет на манеру общения выбранного персонажа.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(4),
                        modifier = Modifier.fillMaxWidth().height(248.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items((1..12).toList()) { variant ->
                            Card(
                                onClick = { selectedVariant = variant },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (variant == selectedVariant) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                                )
                            ) {
                                Column(Modifier.fillMaxWidth().padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    CatalogAsset(spritePath(selectedGroup, variant), Modifier.size(54.dp), "Вариант $variant")
                                    Text("$variant", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                    Text("Выбран: вариант $selectedVariant", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                }
            },
            confirmButton = {
                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(onClick = {
                        onSelectCharacter("character_catalog/sprites/${selectedGroup.toString().padStart(2, '0')}/")
                        selectedGroup = 0
                    }) { Text("Использовать набор эмоций") }
                    OutlinedButton(onClick = {
                        onSelectCharacter(spritePath(selectedGroup, selectedVariant))
                        selectedGroup = 0
                    }) { Text("Только этот кадр") }
                }
            },
            dismissButton = { TextButton(onClick = { selectedGroup = 0 }) { Text("Отмена") } }
        )
    }
}
