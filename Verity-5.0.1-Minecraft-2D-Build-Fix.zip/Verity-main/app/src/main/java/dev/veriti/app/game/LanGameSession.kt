package dev.veriti.app.game

import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class LanGameState(
    val status: String = "Не подключено",
    val address: String = "",
    val connected: Boolean = false,
    val remoteX: Float = .72f,
    val remoteY: Float = .45f
)

class LanGameSession {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutableState = MutableStateFlow(LanGameState())
    val state: StateFlow<LanGameState> = mutableState.asStateFlow()
    private var server: ServerSocket? = null
    private var socket: Socket? = null
    private var writer: PrintWriter? = null
    private var connectionJob: Job? = null

    fun startHost(hasPlus: Boolean) {
        connectionJob?.cancel()
        resetConnection()
        connectionJob = scope.launch {
            runCatching {
                val address = localIpv4()
                server = ServerSocket(PORT)
                mutableState.value = LanGameState("Ожидаю второго игрока…", address)
                val peer = server!!.accept()
                val input = BufferedReader(InputStreamReader(peer.getInputStream()))
                val output = PrintWriter(peer.getOutputStream(), true)
                val peerPlus = input.readLine() == "HELLO:1"
                if (!hasPlus && !peerPlus) {
                    output.println("DENIED")
                    peer.close()
                    error("Для комнаты нужен Verity+ хотя бы у одного игрока")
                }
                output.println("WELCOME:${if (hasPlus) 1 else 0}")
                attach(peer, input, output)
            }.onFailure { failure ->
                mutableState.value = LanGameState(failure.message ?: "Не удалось создать игру")
                resetConnection(keepState = true)
            }
        }
    }

    fun join(host: String, hasPlus: Boolean) {
        connectionJob?.cancel()
        resetConnection()
        connectionJob = scope.launch {
            runCatching {
                mutableState.value = LanGameState("Подключаюсь…", host)
                val peer = Socket().apply {
                    connect(InetSocketAddress(host.trim().substringBefore(':'), PORT), 8_000)
                }
                val input = BufferedReader(InputStreamReader(peer.getInputStream()))
                val output = PrintWriter(peer.getOutputStream(), true)
                output.println("HELLO:${if (hasPlus) 1 else 0}")
                val response = input.readLine()
                if (response == "DENIED") {
                    peer.close()
                    error("Нужен Verity+ хотя бы у одного игрока")
                }
                if (!response.startsWith("WELCOME:")) error("Несовместимая версия игры")
                attach(peer, input, output)
            }.onFailure { failure ->
                mutableState.value = LanGameState(failure.message ?: "Не удалось подключиться", host)
                resetConnection(keepState = true)
            }
        }
    }

    fun sendPosition(x: Float, y: Float) {
        synchronized(this) { writer?.println("MOVE:${x.coerceIn(0f, 1f)}:${y.coerceIn(0f, 1f)}") }
    }

    private fun attach(peer: Socket, input: BufferedReader, output: PrintWriter) {
        socket = peer
        writer = output
        mutableState.value = mutableState.value.copy(status = "Игрок подключён", connected = true)
        while (!peer.isClosed) {
            val line = input.readLine() ?: break
            if (line.startsWith("MOVE:")) {
                val parts = line.split(':')
                val x = parts.getOrNull(1)?.toFloatOrNull()
                val y = parts.getOrNull(2)?.toFloatOrNull()
                if (x != null && y != null) mutableState.value = mutableState.value.copy(remoteX = x, remoteY = y)
            }
        }
        mutableState.value = mutableState.value.copy(status = "Второй игрок отключился", connected = false)
    }

    private fun localIpv4(): String = NetworkInterface.getNetworkInterfaces().toList()
        .flatMap { it.inetAddresses.toList() }
        .filterIsInstance<Inet4Address>()
        .firstOrNull { !it.isLoopbackAddress && it.isSiteLocalAddress }
        ?.hostAddress ?: "Адрес Wi‑Fi не найден"

    private fun resetConnection(keepState: Boolean = false) {
        runCatching { socket?.close() }
        runCatching { server?.close() }
        socket = null
        server = null
        writer = null
        if (!keepState) mutableState.value = LanGameState()
    }

    fun close() {
        connectionJob?.cancel()
        resetConnection()
        scope.cancel()
    }

    companion object {
        const val PORT = 45678
    }
}
