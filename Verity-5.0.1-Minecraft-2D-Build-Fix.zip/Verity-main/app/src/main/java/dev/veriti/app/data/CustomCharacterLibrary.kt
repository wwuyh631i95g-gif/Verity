package dev.veriti.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Private user character collection. Built-in assets are never indexed or deleted here. */
object CustomCharacterLibrary {
    data class Entry(val name: String, val uri: String, val createdAt: Long)

    private const val INDEX_FILE = "characters.json"
    private const val PREFIX = "user_character_"
    private const val IMAGE_SIDE = 512

    private fun root(context: Context) = File(context.filesDir, "characters").apply { mkdirs() }
    private fun indexFile(context: Context) = File(root(context), INDEX_FILE)

    fun list(context: Context): List<Entry> = runCatching {
        val json = JSONArray(indexFile(context).takeIf { it.exists() }?.readText() ?: "[]")
        buildList {
            for (i in 0 until json.length()) {
                val item = json.optJSONObject(i) ?: continue
                val uri = item.optString("uri")
                val file = checkedOwnedFile(context, uri) ?: continue
                if (file.isFile) add(Entry(item.optString("name", "Мой персонаж"), uri, item.optLong("createdAt")))
            }
        }.sortedByDescending { it.createdAt }
    }.getOrDefault(emptyList())

    /** Imports and center-crops an image into a transparent circular PNG stored privately by the app. */
    fun importCharacter(context: Context, sourceUri: Uri, requestedName: String): Entry? {
        val name = requestedName.trim().take(32).ifBlank { "Мой персонаж" }
        val source = runCatching {
            context.contentResolver.openInputStream(sourceUri)?.use { BitmapFactory.decodeStream(it) }
        }.getOrNull() ?: return null
        if (source.width < 32 || source.height < 32) {
            source.recycle()
            return null
        }

        val side = minOf(source.width, source.height)
        val left = (source.width - side) / 2
        val top = (source.height - side) / 2
        val output = Bitmap.createBitmap(IMAGE_SIDE, IMAGE_SIDE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val clip = Path().apply { addCircle(IMAGE_SIDE / 2f, IMAGE_SIDE / 2f, IMAGE_SIDE / 2f - 2f, Path.Direction.CW) }
        canvas.save()
        canvas.clipPath(clip)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        canvas.drawBitmap(
            source,
            Rect(left, top, left + side, top + side),
            RectF(0f, 0f, IMAGE_SIDE.toFloat(), IMAGE_SIDE.toFloat()),
            paint
        )
        canvas.restore()
        source.recycle()

        val file = File(root(context), "$PREFIX${UUID.randomUUID()}.png")
        val saved = runCatching { file.outputStream().use { output.compress(Bitmap.CompressFormat.PNG, 100, it) } }.getOrDefault(false)
        output.recycle()
        if (!saved) {
            file.delete()
            return null
        }
        val entry = Entry(name, Uri.fromFile(file).toString(), System.currentTimeMillis())
        val updated = list(context).toMutableList().apply { add(entry) }
        return if (writeIndex(context, updated)) entry else {
            file.delete()
            null
        }
    }

    /** Loads only an indexed, app-owned custom character image. */
    fun loadBitmap(context: Context, uri: String): Bitmap? {
        val owned = checkedOwnedFile(context, uri) ?: return null
        if (list(context).none { it.uri == uri } || !owned.isFile) return null
        return runCatching { BitmapFactory.decodeFile(owned.absolutePath) }.getOrNull()
    }

    /** Renames only an item already owned by the private user-character folder. */
    fun rename(context: Context, uri: String, requestedName: String): Boolean {
        val name = requestedName.trim().take(32)
        if (name.isBlank() || checkedOwnedFile(context, uri) == null) return false
        val current = list(context).toMutableList()
        val index = current.indexOfFirst { it.uri == uri }
        if (index < 0) return false
        current[index] = current[index].copy(name = name)
        return writeIndex(context, current)
    }

    /** Deletes only the app's own user_character_*.png file, never packaged characters. */
    fun delete(context: Context, uri: String): Boolean {
        val file = checkedOwnedFile(context, uri) ?: return false
        val current = list(context).filterNot { it.uri == uri }
        if (!writeIndex(context, current)) return false
        return file.delete()
    }

    private fun checkedOwnedFile(context: Context, value: String): File? = runCatching {
        val uri = Uri.parse(value)
        require(uri.scheme == "file")
        val file = File(uri.path ?: error("Missing path")).canonicalFile
        val expectedRoot = root(context).canonicalFile
        require(file.parentFile == expectedRoot && file.name.startsWith(PREFIX) && file.extension.equals("png", true))
        file
    }.getOrNull()

    private fun writeIndex(context: Context, entries: List<Entry>): Boolean = runCatching {
        val json = JSONArray()
        entries.forEach { entry ->
            json.put(JSONObject().put("name", entry.name).put("uri", entry.uri).put("createdAt", entry.createdAt))
        }
        val target = indexFile(context)
        val temporary = File(target.parentFile, "$INDEX_FILE.tmp")
        temporary.writeText(json.toString())
        if (target.exists() && !target.delete()) error("Cannot replace character index")
        if (!temporary.renameTo(target)) error("Cannot save character index")
        true
    }.getOrDefault(false)
}
