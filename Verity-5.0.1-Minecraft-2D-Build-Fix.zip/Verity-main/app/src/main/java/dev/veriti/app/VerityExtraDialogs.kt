package dev.veriti.app

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.veriti.app.data.CustomSkinEntry
import java.util.Date

@Composable
internal fun CustomSkinGalleryDialog(
    skins: List<CustomSkinEntry>,
    selectedUri: String,
    onDismiss: () -> Unit,
    onUse: (String) -> Unit,
    onDelete: (String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Мои персонажи (${skins.size})") },
        text = {
            if (skins.isEmpty()) {
                Text("Пока нет сохранённых собственных скинов. Нарисуй персонажа или импортируй картинку — она появится здесь.")
            } else {
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 440.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(skins, key = { it.uri }) { skin ->
                        val bitmap = remember(skin.uri) {
                            runCatching { BitmapFactory.decodeFile(Uri.parse(skin.uri).path)?.asImageBitmap() }.getOrNull()
                        }
                        Card {
                            Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    if (bitmap != null) Image(bitmap, skin.name, Modifier.size(64.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(skin.name, fontWeight = FontWeight.SemiBold)
                                        Text(if (skin.uri == selectedUri) "Сейчас используется" else "Сохранён в памяти Verity", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = { onUse(skin.uri) }, modifier = Modifier.weight(1f)) { Text("Использовать") }
                                    OutlinedButton(onClick = { onDelete(skin.uri) }, modifier = Modifier.weight(1f)) { Text("Удалить") }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Закрыть") } }
    )
}

private data class DownloadableLocalModel(
    val title: String,
    val description: String,
    val size: String,
    val fileName: String,
    val url: String
)

private val downloadableLocalModels = listOf(
    DownloadableLocalModel(
        "Qwen2.5 0.5B Instruct · Q4_K_M",
        "Меньше и легче для первого теста на телефоне; ответы проще и медленнее облачных моделей.",
        "≈ 491 МБ",
        "qwen2.5-0.5b-instruct-q4_k_m.gguf",
        "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf?download=true"
    ),
    DownloadableLocalModel(
        "Qwen2.5 1.5B Instruct · Q4_K_M",
        "Крупнее и может отвечать лучше, но требует больше памяти и может работать медленно на Honor X8b.",
        "≈ 1,12 ГБ",
        "qwen2.5-1.5b-instruct-q4_k_m.gguf",
        "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf?download=true"
    )
)

private fun queueModelDownload(context: Context, model: DownloadableLocalModel): Long {
    val request = DownloadManager.Request(Uri.parse(model.url))
        .setTitle(model.title)
        .setDescription("Модель для локальной работы Verity")
        .setMimeType("application/octet-stream")
        .setAllowedOverMetered(true)
        .setAllowedOverRoaming(false)
        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "Verity/${model.fileName}")
    return (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
}

@Composable
internal fun OfflineModelsDialog(onDismiss: () -> Unit, onOpenServer: () -> Unit) {
    val context = LocalContext.current
    var status by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Офлайн-нейросеть Verity") },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Сначала один раз скачай файл модели и установи локальный сервер. После загрузки модель может отвечать без интернета, пока сервер запущен.")
                downloadableLocalModels.forEach { model ->
                    Card {
                        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text(model.title, fontWeight = FontWeight.SemiBold)
                            Text("${model.size} · ${model.description}", style = MaterialTheme.typography.bodySmall)
                            OutlinedButton(onClick = {
                                runCatching { queueModelDownload(context, model) }
                                    .onSuccess { status = "Загрузка началась. Файл появится в Downloads/Verity/${model.fileName}." }
                                    .onFailure { status = "Не удалось начать загрузку: ${it.message ?: "ошибка Android"}" }
                            }, modifier = Modifier.fillMaxWidth()) { Text("Скачать модель") }
                        }
                    }
                }
                Text("Как подключить на этом же телефоне", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    "1. Установи приложение LLM AI Server with llama.cpp из Google Play (кнопка ниже).\n" +
                    "2. Открой его и выбери GGUF-файл из Downloads/Verity или скачай модель внутри самого сервера.\n" +
                    "3. Запусти его API Server / OpenAI-compatible API и оставь службу работающей.\n" +
                    "4. Скопируй адрес и порт из интерфейса сервера. В Verity открой Настройки → Модель и API → Custom.\n" +
                    "5. Base URL укажи по формату http://127.0.0.1:ПОРТ/v1 (замени ПОРТ на фактический порт из сервера). API key оставь пустым, если сервер его не требует. Model укажи как в списке моделей сервера.\n" +
                    "6. Сохрани настройки и проверь чат. После того как модель загружена и сервер работает, запросы к локальному адресу не требуют облачного API.",
                    style = MaterialTheme.typography.bodySmall
                )
                Text("Важно: модельный файл не является самостоятельной программой. Без локального движка он не запустится. На Honor X8b начни с 0.5B; 1.5B может быть медленным или не поместиться в доступную память. Скачивание файлов требует интернета и свободного места.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (status != null) Text(status.orEmpty(), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton(onClick = onOpenServer) { Text("Открыть локальный сервер в Google Play") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Закрыть") } }
    )
}
