package dev.veriti.app

import android.net.Uri
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.veriti.app.data.AppSettings
import dev.veriti.app.data.Message
import dev.veriti.app.network.AiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.OutputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

private data class GeneratedProjectFile(val path: String, val content: String, val binaryBase64: Boolean = false)

private const val ANDROID_BUILD_WORKFLOW = """name: Build Android APK
on:
  workflow_dispatch:
  push:
    branches: [ main ]
permissions:
  contents: read
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v6
      - uses: actions/setup-java@v5
        with:
          distribution: temurin
          java-version: '17'
      - uses: gradle/actions/setup-gradle@v6
        with:
          gradle-version: '9.6.1'
      - name: Build debug APK
        run: gradle assembleDebug
      - name: Upload APK
        uses: actions/upload-artifact@v7
        with:
          name: android-debug-apk
          path: '**/build/outputs/apk/debug/*.apk'
          if-no-files-found: error
"""

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun AppProjectBuilderScreen(settings: AppSettings, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var description by remember { mutableStateOf("") }
    var projectName by remember { mutableStateOf("MyAndroidApp") }
    var files by remember { mutableStateOf<List<GeneratedProjectFile>>(emptyList()) }
    var isGenerating by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var pendingZipName by remember { mutableStateOf("android-project.zip") }
    var editingPath by remember { mutableStateOf<String?>(null) }
    var editingContent by remember { mutableStateOf("") }
    var referenceImageBase64 by remember { mutableStateOf<String?>(null) }
    var referenceImageName by remember { mutableStateOf<String?>(null) }
    var imageImportError by remember { mutableStateOf<String?>(null) }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                runCatching {
                    withContext(Dispatchers.IO) {
                        val bitmap = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                            ?: error("Не удалось прочитать изображение")
                        require(bitmap.width > 0 && bitmap.height > 0) { "Пустое изображение" }
                        val scale = minOf(1f, 1280f / maxOf(bitmap.width, bitmap.height))
                        val width = (bitmap.width * scale).toInt().coerceAtLeast(1)
                        val height = (bitmap.height * scale).toInt().coerceAtLeast(1)
                        val resized = if (width == bitmap.width && height == bitmap.height) bitmap else Bitmap.createScaledBitmap(bitmap, width, height, true)
                        try {
                            val output = ByteArrayOutputStream()
                            resized.compress(Bitmap.CompressFormat.JPEG, 72, output)
                            require(output.size() <= 700_000) { "Изображение всё ещё слишком большое. Выбери картинку меньшего размера." }
                            Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
                        } finally {
                            if (resized !== bitmap) resized.recycle()
                            bitmap.recycle()
                        }
                    }
                }.onSuccess { encoded ->
                    referenceImageBase64 = encoded
                    referenceImageName = uri.lastPathSegment?.substringAfterLast('/')?.take(80) ?: "reference.jpg"
                    imageImportError = null
                    status = "Картинка добавлена как визуальный референс проекта."
                }.onFailure { imageImportError = it.message ?: "Не удалось добавить изображение" }
            }
        }
    }

    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri: Uri? ->
        if (uri != null && files.isNotEmpty()) {
            scope.launch {
                runCatching {
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.use { output -> writeProjectZip(output, files) }
                            ?: throw IllegalStateException("Не удалось открыть выбранное место сохранения")
                    }
                }.onSuccess {
                    status = "ZIP проекта сохранён. Это исходники, не готовый APK."
                    error = null
                }.onFailure {
                    error = it.message ?: "Не удалось сохранить ZIP"
                }
            }
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = {
            TopAppBar(
                modifier = Modifier.statusBarsPadding(),
                title = { Text("Создатель приложений", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Назад") } }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).navigationBarsPadding().padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("Опиши приложение обычными словами. Verity попросит выбранную нейросеть создать Android-проект с файлами Gradle, Kotlin и Manifest.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            item {
                OutlinedTextField(
                    value = projectName,
                    onValueChange = { projectName = it.filter { ch -> ch.isLetterOrDigit() || ch == '_' || ch == '-' }.take(36) },
                    label = { Text("Название проекта") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Какое приложение создать?") },
                    minLines = 5,
                    maxLines = 12,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("Картинка для проекта", fontWeight = FontWeight.SemiBold)
                        Text("Добавь фото, рисунок или скриншот как визуальный пример. Оно будет передано модели и вложено в ZIP проекта.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        OutlinedButton(onClick = { imagePicker.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Rounded.AddPhotoAlternate, null); Spacer(Modifier.width(8.dp)); Text(if (referenceImageBase64 == null) "Добавить картинку" else "Заменить картинку")
                        }
                        if (referenceImageName != null) {
                            Text("Добавлено: ${referenceImageName}", style = MaterialTheme.typography.bodySmall)
                            TextButton(onClick = { referenceImageBase64 = null; referenceImageName = null }) { Text("Убрать картинку") }
                        }
                        imageImportError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }
            item {
                Button(
                    onClick = {
                        if (description.trim().length < 15) {
                            error = "Напиши чуть подробнее — хотя бы пару предложений."
                        } else if (settings.apiKey.isBlank() &&
                            !settings.baseUrl.startsWith("http://10.0.2.2") &&
                            !settings.baseUrl.startsWith("http://192.168.") &&
                            !settings.baseUrl.startsWith("http://127.0.0.1") &&
                            !settings.baseUrl.startsWith("http://localhost")) {
                            error = "Сначала подключи API-ключ в Настройках → Модель и API. Для локального сервера на 127.0.0.1 ключ может быть пустым, если сам сервер не требует его."
                        } else {
                            isGenerating = true
                            error = null
                            status = "Генерирую структуру проекта через выбранную модель…"
                            files = emptyList()
                            scope.launch {
                                runCatching {
                                    withContext(Dispatchers.IO) {
                                        val prompt = buildString {
                                            appendLine("Создай запускаемый минимальный Android-проект на Kotlin и Jetpack Compose.")
                                            appendLine("Название: ${projectName.ifBlank { "MyAndroidApp" }}")
                                            appendLine("Описание приложения: ${description.trim()}")
                                            appendLine("Используй compileSdk 37, minSdk 29, targetSdk 35, Java 17, Android Gradle Plugin 9.3.1, Kotlin 2.4.21, Gradle wrapper 9.6.1.")
                                            appendLine("Включи settings.gradle.kts, build.gradle.kts, app/build.gradle.kts, app/src/main/AndroidManifest.xml и app/src/main/java/.../MainActivity.kt. Добавь README.md и нужные ресурсы. Не используй секретные ключи, закрытые API и опасные разрешения.")
                                            if (referenceImageBase64 != null) appendLine("Пользователь приложил картинку-референс. В ZIP она будет включена как app/src/main/res/drawable/verity_reference.jpg. Если это уместно для интерфейса, покажи её через painterResource(R.drawable.verity_reference); не придумывай, будто это готовая 3D-модель.")
                                            appendLine("Ответь ТОЛЬКО одним JSON-объектом без Markdown: {\"projectName\":\"...\",\"files\":[{\"path\":\"settings.gradle.kts\",\"content\":\"полное содержимое файла\"}]}")
                                            appendLine("Не более 18 файлов. Каждый путь относительный от корня проекта. Не используй .., абсолютные пути, бинарные файлы или placeholder-комментарии вместо кода. Код должен быть полным и согласованным между файлами.")
                                        }
                                        val attachments = referenceImageBase64?.let { encoded ->
                                            listOf(dev.veriti.app.data.FileAttachment(referenceImageName ?: "reference.jpg", "image/jpeg", encoded, true))
                                        }.orEmpty()
                                        val result = AiClient().complete(settings, listOf(Message(role = "user", content = prompt, attachments = attachments)))
                                        parseGeneratedProject(result.text)
                                    }
                                }.onSuccess { generated ->
                                    projectName = generated.first.ifBlank { projectName }
                                    files = generated.second.filterNot { it.path == "app/src/main/res/drawable/verity_reference.jpg" } +
                                        listOfNotNull(referenceImageBase64?.let { GeneratedProjectFile("app/src/main/res/drawable/verity_reference.jpg", it, true) })
                                    pendingZipName = "${projectName.ifBlank { "AndroidProject" }}.zip"
                                    status = "Создано файлов: ${files.size}. Проверь список, затем сохрани ZIP. Картинка включена отдельно от кода."
                                }.onFailure {
                                    error = it.message ?: "Не получилось создать проект. Проверь ответ модели и API."
                                    status = null
                                }
                                isGenerating = false
                            }
                        }
                    },
                    enabled = !isGenerating,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (isGenerating) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    else Icon(Icons.Rounded.Code, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (isGenerating) "Создаю проект…" else "Сгенерировать проект")
                }
            }
            error?.let { message -> item { Text(message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) } }
            status?.let { message -> item { Text(message, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium) } }
            if (files.isNotEmpty()) {
                item { Text("Файлы проекта", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                items(files, key = { it.path }) { file ->
                    Card(onClick = { if (!file.binaryBase64) { editingPath = file.path; editingContent = file.content } }) {
                        Column(Modifier.fillMaxWidth().padding(12.dp)) {
                            Text(file.path, fontWeight = FontWeight.SemiBold)
                            Text(if (file.binaryBase64) "Изображение · вложено в ZIP" else "${file.content.length} символов", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                item {
                    Button(onClick = { saveLauncher.launch(pendingZipName) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.Download, null); Spacer(Modifier.width(8.dp)); Text("Скачать ZIP проекта")
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Как получить APK", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("1. Сохрани ZIP и распакуй его.\n2. Создай репозиторий GitHub и загрузи туда содержимое папки проекта.\n3. Открой вкладку Actions и запусти workflow Build Android APK.\n4. После сборки открой завершённый запуск и скачай android-debug-apk в разделе Artifacts.\n5. APK можно установить на Android после проверки источника и разрешений.", style = MaterialTheme.typography.bodySmall)
                        Text("Verity сейчас создаёт и упаковывает исходники. Он не компилирует APK непосредственно внутри телефона: сборка выполняется в GitHub Actions.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        TextButton(onClick = { context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse("https://github.com/"))) }) { Text("Открыть GitHub") }
                    }
                }
            }
        }
    }
    val pathToEdit = editingPath
    if (pathToEdit != null) {
        AlertDialog(
            onDismissRequest = { editingPath = null },
            title = { Text("Редактирование: $pathToEdit") },
            text = {
                OutlinedTextField(
                    value = editingContent,
                    onValueChange = { editingContent = it },
                    modifier = Modifier.fillMaxWidth().height(360.dp),
                    minLines = 12,
                    maxLines = 24
                )
            },
            confirmButton = {
                Button(onClick = {
                    files = files.map { if (it.path == pathToEdit) it.copy(content = editingContent) else it }
                    editingPath = null
                    status = "Изменения в $pathToEdit будут включены в ZIP."
                }) { Text("Сохранить файл") }
            },
            dismissButton = { TextButton(onClick = { editingPath = null }) { Text("Отмена") } }
        )
    }
}

private fun parseGeneratedProject(raw: String): Pair<String, List<GeneratedProjectFile>> {
    val start = raw.indexOf('{')
    val end = raw.lastIndexOf('}')
    require(start >= 0 && end > start) { "Модель не вернула JSON. Попробуй снова или сократи описание." }
    val json = JSONObject(raw.substring(start, end + 1))
    val project = json.optString("projectName", "AndroidProject").filter { it.isLetterOrDigit() || it == '_' || it == '-' }.take(36)
    val array = json.optJSONArray("files") ?: error("В ответе нет списка files")
    require(array.length() in 1..18) { "Ожидалось от 1 до 18 файлов, получено ${array.length()}" }
    val result = LinkedHashMap<String, String>()
    var total = 0
    for (index in 0 until array.length()) {
        val item = array.getJSONObject(index)
        val path = item.optString("path").replace('\\', '/')
        val content = item.optString("content")
        require(path.isNotBlank() && path.length < 180 && !path.startsWith('/') && !path.split('/').any { it == ".." || it.isBlank() }) { "Небезопасный путь файла: $path" }
        require(!path.contains(':') && !path.contains('\u0000')) { "Недопустимое имя файла: $path" }
        require(content.isNotBlank()) { "Файл пустой: $path" }
        total += content.toByteArray(Charsets.UTF_8).size
        require(total <= 1_800_000) { "Проект слишком большой. Сократи описание и сгенерируй меньший проект." }
        result[path] = content
    }
    if (!result.keys.any { it == "README.md" }) {
        result["README.md"] = "# $project\n\nAndroid project generated by Verity. Review dependencies, permissions and code before building.\n"
    }
    if (!result.keys.any { it.startsWith(".github/workflows/") }) {
        result[".github/workflows/android-build.yml"] = ANDROID_BUILD_WORKFLOW
    }
    return project to result.map { GeneratedProjectFile(it.key, it.value) }
}

private fun writeProjectZip(output: OutputStream, files: List<GeneratedProjectFile>) {
    ZipOutputStream(output.buffered()).use { zip ->
        files.forEach { file ->
            val entry = ZipEntry("${file.path}")
            zip.putNextEntry(entry)
            val bytes = if (file.binaryBase64) Base64.decode(file.content, Base64.DEFAULT) else file.content.toByteArray(Charsets.UTF_8)
            zip.write(bytes)
            zip.closeEntry()
        }
    }
}
