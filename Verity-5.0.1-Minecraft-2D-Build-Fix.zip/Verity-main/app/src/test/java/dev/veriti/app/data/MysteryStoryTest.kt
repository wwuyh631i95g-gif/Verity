package dev.veriti.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MysteryStoryTest {
    @Test
    fun storyFollowsThreeDaySequence() {
        val start = 1_000_000L
        assertEquals(null, MysteryStory.reply(AppSettings(), "Привет", start))
        val first = MysteryStory.decorateAnswer(AppSettings(), "Привет!", "happy", start)
        assertTrue(first.text.endsWith("Что-то произойдёт через 3 дня."))
        assertEquals(start, first.settings.mysteryStartedAt)

        val followUp = MysteryStory.decorateAnswer(first.settings, "Ещё ответ", "normal", start + 1_000L)
        assertTrue(followUp.text.endsWith("Что-то произойдёт через 3 дня."))
        val selected = MysteryStory.withEventSelected(first.settings, start + MysteryStory.THREE_DAYS_MS)
        assertTrue(selected.mysteryEvent in 1..2)

        if (selected.mysteryEvent == 1) {
            assertFalse(MysteryStory.shouldHideOverlay(selected, start + MysteryStory.FOUR_DAYS_MS - 1L))
            assertTrue(MysteryStory.shouldHideOverlay(selected, start + MysteryStory.FOUR_DAYS_MS))
        } else {
            assertTrue(MysteryStory.isScary(selected, start + MysteryStory.THREE_DAYS_MS))
            assertTrue(MysteryStory.shouldShakeText(selected, start + MysteryStory.THREE_DAYS_MS))
        }
    }

    @Test
    fun premiumCanDisableStory() {
        val settings = AppSettings(verityPlus = true, mysteryEnabled = false)
        val answer = MysteryStory.decorateAnswer(settings, "Обычный ответ", "happy", 5_000L)
        assertEquals("Обычный ответ", answer.text)
        assertEquals(0L, answer.settings.mysteryStartedAt)
    }
}
